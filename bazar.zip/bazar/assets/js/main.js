jQuery(document).ready(function($){

		$('.stellarnav').stellarNav({
				theme: 'dark',
				breakpoint: 960,
				position: 'right',
				phoneBtn: false,
				locationBtn: false,
                sticky:true,
            
			});
			
		 $('.home-list').owlCarousel({
    		loop:true,
    		dots:false,
    		nav:true,
     		autoplay:true,
            navText:["<i Class='fa fa-angle-left'></i>", 
                "<i Class='fa fa-angle-right'></i>"],
    		responsiveClass: true,
			responsive: {
			  0: {
				items: 1,
			  },
			  480: {
				items: 1,
			  },
			  768: {
				items: 1,
			  },
			  1000: {
				items: 1,
			  }
			}

    	});
    
    
    			
		 $('.products-list-one').owlCarousel({
    		
    		loop:false,
    		dots:false,
            margin:10,
    		nav:true,
     		autoplay:true,
            navText:["<i Class='fa fa-angle-left'></i>", 
                "<i Class='fa fa-angle-right'></i>"],
    		responsiveClass: true,
			responsive: {
			  0: {
				items: 1,
			  },
			  480: {
				items: 2,
			  },
			  768: {
				items: 3,
			  },
			  1000: {
				items: 7,
			  }
			}

    	});
    			
		
        $('.tab-item-list').owlCarousel({
    	    loop:false,
    		dots:false,
            margin:20,
    		nav:true,
     		autoplay:true,
            navText:["<i Class='fa fa-angle-left'></i>", 
                "<i Class='fa fa-angle-right'></i>"],
    		responsiveClass: true,
			responsive: {
			  0: {
				items: 1,
			  },
			  480: {
				items: 2,
			  },
			  768: {
				items: 3,
			  },
			  1000: {
				items: 4,
			  }
			}

    	});  
    
        $('.products-item').owlCarousel({
    	    loop:false,
    		dots:false,
            margin:20,
    		nav:true,
     		autoplay:true,
            navText:["<i Class='fa fa-angle-left'></i>", 
                "<i Class='fa fa-angle-right'></i>"],
    		responsiveClass: true,
			responsive: {
			  0: {
				items: 1,
			  },
			  480: {
				items: 2,
			  },
			  768: {
				items: 3,
			  },
			  1000: {
				items: 3,
			  }
			}

    	});
    
    
      $('.count-list-item').owlCarousel({
    	    loop:false,
    		dots:true,
            margin:20,
    		autoplay:true,
            responsiveClass: true,
			responsive: {
			  0: {
				items: 1,
			  },
			  480: {
				items: 2,
			  },
			  768: {
				items: 1,
			  },
			  1000: {
				items: 1,
			  }
			}

    	});
    
        
    			
		 $('.blog-list').owlCarousel({
    		loop:false,
    		dots:false,
            margin:10,
    		nav:true,
     		autoplay:true,
            navText:["<i Class='fa fa-angle-left'></i>", 
                "<i Class='fa fa-angle-right'></i>"],
    		responsiveClass: true,
			responsive: {
			  0: {
				items: 1,
			  },
			  480: {
				items: 2,
			  },
			  768: {
				items: 1,
			  },
			  1000: {
				items: 1,
			  }
			}

    	});
    
    
		 $('.partner-list').owlCarousel({
    		loop:false,
    		dots:false,
            margin:10,
    		nav:true,
     		autoplay:true,
            navText:["<i Class='fa fa-angle-left'></i>", 
                "<i Class='fa fa-angle-right'></i>"],
    		responsiveClass: true,
			responsive: {
			  0: {
				items: 1,
			  },
			  480: {
				items: 2,
			  },
			  768: {
				items: 3,
			  },
			  1000: {
				items: 8,
			  }
			}

    	});
    		   
    
        $(window).scroll(function(){
		        if ($(this).scrollTop() > 100) {
		            $('.scrollToTop').fadeIn();
		        } else {
		            $('.scrollToTop').fadeOut();
		        }
		    });

		    //Click event to scroll to top
		    $('.scrollToTop').on('click', function(){
		        $('html, body').animate({scrollTop : 0},800);
		        return false;
		    });
    
    new WOW().init();

    
        
    
});	