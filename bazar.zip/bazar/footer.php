<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package bazar
 */

?>

<!--================================ Footer-section-Start ===============================-->
<div class="footer-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-2 col-sm-4 col-xs-6">
                        <div class="menu-title">
                            Help
                        </div>
                        
                        <div class="footer-menu">
                            <ul>
                                <li><a href="">Payments</a></li>
                                <li><a href="">Shipping</a></li>
                                <li><a href="">Cancellation</a></li>
                                <li><a href="">FAQ</a></li>
                                <li><a href="">Sitemap</a></li>
                            </ul>
                        </div>
                        
                    </div>
                    
                    <div class="col-md-2 col-sm-4 col-xs-6">
                        <div class="menu-title">
                           Policy
                        </div>
                        
                        <div class="footer-menu">
                            <ul>
                                <li><a href=""> Return Policy</a></li>
                                <li><a href=""> Terms Of Use</a></li>
                                <li><a href="">Security</a></li>
                                <li><a href="">Privacy</a></li>
                                <li><a href="">Sitemap</a></li>
                            </ul>
                        </div>
                        
                    </div>
                       
                    <div class="col-md-2 col-sm-4 col-xs-5">
                        <div class="menu-title">
                           About
                        </div>
                        
                        <div class="footer-menu">
                            <ul>
                                <li><a href=""> Contact Us</a></li>
                                <li><a href="">  About Us </a></li>
                                <li><a href="">Careers</a></li>
                                <li><a href=""> Flipkart Stories</a></li>
                                <li><a href="">Press</a></li>
                            </ul>
                        </div>
                        
                    </div>
                    
                            
                    <div class="col-md-3 col-sm-6 col-xs-7">
                        <div class="menu-title">
                           Contact Us
                        </div>
                        
                       <div class="footer-wrpp">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/location.png" alt="">
                                <div class="footer-addrss">
                                    60, 29th Street, San Francisco, CA 94110, United States of America
                                </div>
                        </div>
                        
                        <div class="footer-wrpp">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/gmail.png" alt="">
                                <div class="footer-addrss">
                                    (+00) 123-456-789
                                </div>
                        </div>
                         
                        <div class="footer-wrpp">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/online.png" alt="">
                                <div class="footer-addrss">
                                    (+00) 123-456-789
                                </div>
                        </div>
                        
                    </div>  
                           
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="menu-title">
                           Subscribe Now
                        </div>
                        
                        <div class="subscribe-cont">
                            Subscribe to our newsletterget 10% off your first purchase at here for update.
                        </div>
                        <div class="subscribe-from">
                        <input type="text" placeholder="Subscribe Now" name="subcribe">
                        <button type="submit"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/mail.png" alt=""></button>
                        </div>

                    </div>

                </div>
            </div>
        </div>
                        
    <!--================================ Footer-section-End ===============================-->
                        
                        
    <!--================================  Bottom-Footer-section-Start===============================-->
        <div class="bottom-footer">
            <div class="container">
                <div class="col-md-4 col-sm-4">
                    <div class="bottom-footer-menu">
                        <ul>
                            <li><a href="">Specials</a></li>
                            <li><a href="">Affiliates</a></li>
                            <li><a href="">Special Discount</a></li>
                            <li><a href="">Brands</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-4 col-sm-4">
                   <div class="copy">
                          Theme Download From <a href="http://ThemesBazar.com/" target="_blank" title="ThemesBazar.com">ThemesBazar</a> 
                   </div>
                  
                </div>
                 <div class="">
                <div class="col-md-4 col-sm-4 brands-wrpp">
                  
                       
                   
                    <div class="brand-image">
                        <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/brand1.jpg" alt=""></a>
                    </div>
                    
                    <div class="brand-image">
                        <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/brand1.jpg" alt=""></a>
                    </div>
                              
                    <div class="brand-image">
                        <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/brand1.jpg" alt=""></a>
                    </div>
                    
                                     
                    <div class="brand-image">
                        <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/brand1.jpg" alt=""></a>
                    </div>
                    
                                     
                    <div class="brand-image">
                        <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/brand1.jpg" alt=""></a>
                    </div>
                    
                                     
                    <div class="brand-image">
                        <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/brand1.jpg" alt=""></a>
                    </div>
                    
                    </div>
                </div>
                
             <a href="" class="scrollToTop"><i class="fa fa-angle-double-up"></i></a>
             
            </div>
        </div>
                
    <!--================================ Bottom-Footer-section-End ===============================-->
                        

		<?php wp_footer(); ?>
    </body>
</html>
