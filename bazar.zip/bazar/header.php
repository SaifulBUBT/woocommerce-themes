<!DOCTYPE html>
<html <?php language_attributes(); ?>>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		
      <?php wp_head(); ?>  
    </head>
    <body <?php body_class(); ?>>
                  
    <!--==========================
        header section  Start
    ===========================-->               
    <div class="header-section">
        <div class="container">
            <div class="row">
                <div class="col-md-2 col-sm-2 col-xs-12">
                    <div class="logo">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/logo.png" alt="">
                    </div>
                </div>

                 
                  <div class="col-md-5 col-sm-5">
                      <form class="example_1" method="POST">
                            <select name="suffix" class="select">
                                <option value="all">All Category</option>
                                <option value=".in">.in</option>
                                <option value=".co.in">.co.in</option>
                                <option value=".net">.net</option>
                                <option value=".org">.org</option>
                                <option value=".biz">.biz</option>
                                <option value=".info">.info</option>
                                <option value=".mobi">.mobi</option>
                            </select>
                            
                            
                            <input type="text" placeholder="Search Products" name="domain_name">
                            <button type="submit"><i class="fa fa-search"></i></button>
					    </form>
                  </div>
                  
                    <div class="col-md-3 col-sm-5">
                        <div class="row">
                            <div class="col-md-6 col-sm-6 col-xs-6">
                                <div class="icons-content">
                                    <div class="icon-image"> 
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons-img.png" alt="">
                                    </div>

                                    <ul>
                                        <li class="text_1">Free</li>
                                        <li>Shipping</li>
                                    </ul>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-sm-6 col-xs-6">
                                <div class="icons-content">
                                    <div class="icon-image"> 
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons-img2.png" alt="">
                                    </div>
                                    <ul>
                                        <li class="text_1">Contact</li>
                                        <li>01789096555</li>
                                    </ul>
                                </div>
                        
                            </div>
                        </div>
                    </div>

                  <div class="col-md-2 col-sm-6 col-xs-6">
                     <div class="header-btn">
                         <img src="<?php echo get_template_directory_uri(); ?>/assets/img/offer.png" alt="">
                         <a href="">New User Zone</a>
                     </div>
                  </div>                
            </div>
        </div>
    </div>
<!--==========================
    header section  End
===========================--> 

    <!--==========================
        menu section  Start
    ===========================--> 
	   <div class="main-menu">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-9 col-sm-3">
						<div class="stellarnav">
							<ul>
								<li><a href="">Dropdown</a>
									<ul>
											<li><a href="#">How deep?</a>
											<ul>
												<li><a href="#">Deep</a>
													<ul>
														<li><a href="#">Even deeper</a>
															<ul>
																<li><a href="#">Item</a></li>
																<li><a href="#">Item</a></li>
																<li><a href="#">Item</a></li>
															</ul>
														</li>
														<li><a href="#">Item</a></li>
														<li><a href="#">Item</a></li>
														<li><a href="#">Item</a></li>
													</ul>
												</li>
												<li><a href="#">Item</a></li>
												<li><a href="#">Item</a></li>
												<li><a href="#">Item</a></li>
												<li><a href="#">Item</a></li>
											</ul>
										</li>
										<li><a href="#">Item</a>
											<ul>
												<li><a href="#">Item</a></li>
												<li><a href="#">Item</a></li>
												<li><a href="#">Item</a></li>
												<li><a href="#">Item</a></li>
											</ul>
										</li>
										<li><a href="#">Item</a>
											<ul>
												<li><a href="#">Deeper</a>
													<ul>
														<li><a href="#">Item</a></li>
														<li><a href="#">Item</a></li>
														<li><a href="#">Item</a></li>
													</ul>
												</li>
												<li><a href="#">Item</a></li>
												<li><a href="#">Item</a></li>
												<li><a href="#">Item</a></li>
											</ul>
										</li>
										<li><a href="#">Here's a very long item.</a>
											<ul>
												<li><a href="#">Item</a></li>
												<li><a href="#">Item</a></li>
												<li><a href="#">Item</a></li>
												<li><a href="#">Item</a></li>
											</ul>
										</li>
									</ul>
								</li>

								<li><a href="">Item 2</a></li>
								<li><a href="">Item 3</a></li>
								<li><a href="">Item 4</a></li>
								<li><a href="">Item 5</a></li>
								<li><a href="">Item 6</a></li>
								<li><a href="">Item 7</a></li>
								<li class="drop-left"><a href="">Drop Left</a>
									<ul>
										<li><a href="#">How deep?</a>
											<ul>
												<li><a href="#">Deep</a>
													<ul>
														<li><a href="#">Even deeper</a>
															<ul>
																<li><a href="#">Item</a></li>
																<li><a href="#">Item</a></li>
																<li><a href="#">Item</a></li>
															</ul>
														</li>
														<li><a href="#">Item</a></li>
														<li><a href="#">Item</a></li>
														<li><a href="#">Item</a></li>
													</ul>
												</li>
												<li><a href="#">Item</a></li>
												<li><a href="#">Item</a></li>
												<li><a href="#">Item</a></li>
												<li><a href="#">Item</a></li>
											</ul>
										</li>
										<li><a href="#">Item</a></li>
										<li><a href="#">Item</a></li>
										<li><a href="#">Item</a></li>
										<li><a href="#">Item</a></li>
									</ul>
								</li>
							</ul>
						</div><!-- .stellarnav -->

					</div>
					
					<div class="col-md-3 col-sm-9">
					    <div class="row">
					        <div class="col-md-6 col-sm-7">
                               <div class="accout-wrpp">
                                    <a href="" class="sing">
                                        <ul>
                                            <li class="text">Sign In</li>
                                            <li>My Account<i class="fa fa-caret-down"></i></li>
                                        </ul>
                                    </a>
                                    
                                    <div class="account-content">
                                        <ul>
                                            <li><a href="">Wishlist</a></li>
                                            <li><a href="">My Account</a></li>
                                            <li><a href="">Checkout</a></li>
                                            <li><a href="">Compare</a></li>
                                            <li><a href="">User Login</a></li>
                                        </ul>

                                    
                                    </div>
                                   
                               </div>
                               

					        </div>
					        
                            <div class="col-md-6 col-sm-5">
                                <div class="cards-content">
                                    <div class="cart">
                                        <i class="fa fa-shopping-cart"></i>
                                    </div>

                                    <a href="" class="sing">
                                        <ul>
                                            <li class="text">My Card</li>
                                        </ul>
                                    </a>
                                </div>       
                            </div>
					        
					        
					        
					    </div>
					</div>
					
				</div>
			</div>
		</div>	

        <!--==========================
            menu section  End
        ===========================--> 