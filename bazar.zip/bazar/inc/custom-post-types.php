<?php 
function bazar_register_my_cpts_slide() {

	/**
	 * Post Type: Slides.
	 */

	$labels = [
		"name" => __( "Slides", "bazar" ),
		"singular_name" => __( "Slide", "bazar" ),
		"menu_name" => __( "Slider", "bazar" ),
		"all_items" => __( "All Slides", "bazar" ),
		"add_new" => __( "Add New Slide", "bazar" ),
		"add_new_item" => __( "Add New Slide", "bazar" ),
		"edit_item" => __( "Edit Slide", "bazar" ),
		"new_item" => __( "New Slide", "bazar" ),
		"view_item" => __( "View Slide", "bazar" ),
		"view_items" => __( "View Slides", "bazar" ),
		"search_items" => __( "Search Slide", "bazar" ),
		"not_found" => __( "Slides Not Found", "bazar" ),
		"set_featured_image" => __( "Set Slide Image", "bazar" ),
		"remove_featured_image" => __( "Remove Slide Image", "bazar" ),
		"name_admin_bar" => __( "Slide", "bazar" ),
	];

	$args = [
		"label" => __( "Slides", "bazar" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"show_in_rest" => false,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => true,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"delete_with_user" => false,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => [ "slug" => "slide", "with_front" => true ],
		"query_var" => true,
		"menu_icon" => "dashicons-grid-view",
		"supports" => [ "title", "editor", "thumbnail" ],
		"taxonomies" => [ "category" ],
	];

	register_post_type( "slide", $args );
}

add_action( 'init', 'bazar_register_my_cpts_slide' );

