<?php get_header(); ?>
	   
	   
        <!--========================== Home section  Start===========================--> 
        <div class="home-section">
            <div class="row">
                <div class="col-md-12">
                    <div class="home-list owl-carousel">
                    <?php 
							$mainSslide = new WP_Query(array(
								'post_type' => 'slide',
								'posts_per_page' => -1,
								'orderby'     => 'DESC',
							));
							if($mainSslide->have_posts()):
							while($mainSslide->have_posts()) : $mainSslide->the_post(); ?>	
								<?php $slideImg = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'main-slider' ); 
						?>
	
                            <div class="item">
                                <div class="gallery_image">
                                    <img src="<?php echo $slideImg[0]; ?>" />        
                                </div>
                            </div>

						<?php 
							endwhile;
							wp_reset_query();
						else: ?>
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/Main-banner-01.jpg" alt="image">

						<?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
	   
        <!--========================== Home section  End ===========================--> 
	   
    <!--==========================section two  Start===========================-->   
    <div class="section-two wow fadeInUp" data-wow-duration="1s" data-wow-delay=".9s">
        <div class="container">
            <div class="delivery-wrpp">
                <div class="row">
                    <div class="col-md-3 col-sm-3 col-xs-12">
                        <div class="delivery-content border">
                            <div class="delivery-big-img"> 
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/delivery.png" alt="">
                            </div>

                            <ul>
                                <li>Free World Delivery</li>
                                <li class="d-item">Orders Over $100</li>
                      
                            </ul>
                        </div>
                    </div>
                    
                    <div class="col-md-3 col-sm-3 col-xs-12">
                        <div class="delivery-content border">
                            <div class="delivery-image"> 
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/money-bag.png" alt="">
                            </div>

                            <ul>
                                <li>   Money Back Guarantee</li>
                                <li class="d-item">with a 30 day</li>
                      
                            </ul>
                        </div>
                    </div>
                                    
                    <div class="col-md-3 col-sm-3 col-xs-12">
                        <div class="delivery-content border">
                            <div class="delivery-image"> 
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/online.png" alt="">
                            </div>

                            <ul>
                                <li>with a 30 day</li>
                                <li class="d-item">Hours: 8AM -11PM</li>
                      
                            </ul>
                        </div>
                    </div>
                    
                    <div class="col-md-3 col-sm-3 col-xs-12">
                        <div class="delivery-content">
                            <div class="delivery-image"> 
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/piggy.png" alt="">
                            </div>

                            <ul>
                                <li>Hours: 8AM -11PM</li>
                                <li class="d-item">Enter Now</li>
                      
                            </ul>
                        </div>
                    </div>
                    
                    
                </div>
            </div>
        </div>
    </div>
    <!--==========================section two  End ===========================--> 
   
	<!--========================== section three  Start ===========================--> 
	<div class="section-three wow fadeInUp" data-wow-duration="1s" data-wow-delay=".9s">
	    <div class="container">
            <div class="bg-height">
                <div class="row">
                    <div class="col-md-12">
                        <div class="product-section-two">
                            Shop By DepartmentChoose 
                            <strong>What You Looking For</strong>

                        </div>
                    </div>
	            </div>
	            
	            
	            <div class="row">
	                <div class="col-md-12">
	                    <div class="products-list-one  owl-carousel">
	                        <div class="porduct-list-one-wrpp">
	                            <div class="porducts-one-image">
	                                <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p1.jpg" alt=""></a>
	                            </div>
	                            <div class="porduct-one-title">
	                                <a href="">Electronic</a>
	                            </div>
	                        </div>
	                        
                            <div class="porduct-list-one-wrpp">
	                            <div class="porducts-one-image">
	                               <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p2.jpg" alt=""></a> 
	                            </div>
	                            
	                             <div class="porduct-one-title">
	                                <a href="">Electronic</a>
	                            </div>
	                        </div>
                            
                            <div class="porduct-list-one-wrpp">
	                            <div class="porducts-one-image">
	                               <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p3.jpg" alt=""></a> 
	                            </div>
	                            
	                             <div class="porduct-one-title">
	                                <a href="">Electronic</a>
	                            </div>
	                            
	                        </div>
	                        
                            <div class="porduct-list-one-wrpp">
	                            <div class="porducts-one-image">
	                               <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p4.jpg" alt=""></a> 
	                            </div>
	                            
	                             <div class="porduct-one-title">
	                                <a href="">Electronic</a>
	                            </div>
	                        </div>
	                       
	                       <div class="porduct-list-one-wrpp">
	                            <div class="porducts-one-image">
	                                <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p1.jpg" alt=""></a>
	                            </div>
	                            <div class="porduct-one-title">
	                                <a href="">Electronic</a>
	                            </div>
	                        </div>
	                        
                            <div class="porduct-list-one-wrpp">
	                            <div class="porducts-one-image">
	                                 <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p2.jpg" alt=""></a>   
	                            </div>
	                            
	                             <div class="porduct-one-title">
	                                <a href="">Electronic</a>
	                            </div>
	                        </div>
                            
                            <div class="porduct-list-one-wrpp">
	                            <div class="porducts-one-image">
	                               <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p3.jpg" alt=""></a> 
	                            </div>
	                            
	                             <div class="porduct-one-title">
	                                <a href="">Electronic</a>
	                            </div>
	                            
	                        </div>
	                        
                            <div class="porduct-list-one-wrpp">
	                            <div class="porducts-one-image">
	                              <a href=""> <img src="<?php echo get_template_directory_uri(); ?>/assets/img/p4.jpg" alt=""></a> 
	                            </div>
	                            
	                             <div class="porduct-one-title">
	                                <a href="">Electronic</a>
	                            </div>
	                        </div>
	                        
	                    </div>
	                </div>
	            </div>
	            
	        </div>
	    </div>
	</div>      
	   
    <!--==========================section three End===========================--> 
	   
    <!--========================== section four Start ===========================--> 
	<div class="section-four wow fadeInUp" data-wow-duration="1s" data-wow-delay=".9s">
	    <div class="container">
	        <div class="row">
	            <div class="col-md-4 col-sm-4">
                    <div class="porduct-cat-wrpp">
                        <div class="porduct-cat-image">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/Sub-banner-01.jpg" alt="">
                        </div>
                        
                        <div class="poducts-cat-content">
                            <div class="pro-title">
                                Footwear Sale
                            </div>

                            <div class="por-sub-title">
                                Festival Season Is Here
                            </div>

                            <div class="pro-bnt">
                                <a href="">Shop Now</a>
                            </div>
                            
                            <div class="por-sub-three">
                               No EMI | Exchange Offer
                            </div>
                        </div>    
                    </div>
                
	                
	            </div>
                   
                <div class="col-md-4 col-sm-4">
                    <div class="porduct-cat-wrpp">
                        <div class="porduct-cat-image">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/Sub-banner-02.jpg" alt="">
                        </div>
                        
                        <div class="poducts-cat-content">
                            <div class="pro-title">
                                Upto 70% Flate
                            </div>

                            <div class="por-sub-title">
                                Festival Season Is Here
                            </div>

                            <div class="pro-bnt">
                                <a href="">Shop Now</a>
                            </div>
                            
                            <div class="por-sub-three">
                               No EMI | Exchange Offer
                            </div>
                        </div>    
                    </div>
                </div>
                
                <div class="col-md-4 col-sm-4">
                    <div class="porduct-cat-wrpp">
                        <div class="porduct-cat-image">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/Sub-banner-03.jpg" alt="">
                        </div>
                        
                        <div class="poducts-cat-content">
                            <div class="pro-title">
                                Women Shirts
                            </div>

                            <div class="por-sub-title">
                                Festival Season Is Here
                            </div>

                            <div class="pro-bnt">
                                <a href="">Shop Now</a>
                            </div>
                            
                            <div class="por-sub-three">
                               No EMI | Exchange Offer
                            </div>
                        </div>    
                    </div>
                </div>
                
                
                
	        </div>
	    </div>
	</div>   
	           
    <!--========================== section four End ===========================--> 
	   

    <!--==========================section five Start ===========================--> 
	   
    <div class="section-five wow fadeInUp" data-wow-duration="1s" data-wow-delay=".9s">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="custom-tab manu-tav">
                       <div class="t-title">
                            New Arrival Item
                       </div>
                        <ul class="tab-list">
                            <li class="active"><a data-toggle="tab" href="#custom-tab-1">Featured</a></li>
                            <li><a data-toggle="tab" href="#custom-tab-2" href="">Best Seller</a></li>
                            <li><a data-toggle="tab" href="#custom-tab-3" href="">Special Product</a></li>

                        </ul>  

                        <div class="tab-content">
                            <div id="custom-tab-1"  class="tab-pane fade in active">
                                <div class="tab-item-list owl-carousel">
                                    <div class="tav-wrpper">
                                       <div class="tab-image">
                                         <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p5.jpg" alt=""></a>  
                                       </div>

                                       <div class="sell">
                                           -16%
                                       </div>
                                       <div class="tab-icons">
                                           <i class="fa fa-star" aria-hidden="true"></i>
                                           <i class="fa fa-star" aria-hidden="true"></i>
                                           <i class="fa fa-star" aria-hidden="true"></i>
                                           <i class="fa fa-star" aria-hidden="true"></i>
                                       </div>

                                       <div class="tabs-cont">
                                           <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                                       </div>

                                      <div class="tabs-price">
                                           $150.00 <span>   $180.00</span>
                                       </div>

                                        <div class="add-to-card">
                                            <ul>
                                                <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>

                                                <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>

                                                <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>

                                                <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                            </ul>
                                        </div>
                                   </div>

                                       <div class="tav-wrpper">
                                           <div class="tab-image">
                                             <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p6.jpg" alt=""></a>  
                                           </div>
                                           
                                           <div class="sell">
                                               -16%
                                           </div>
                                           <div class="tab-icons">
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                           </div>
                                           
                                           <div class="tabs-cont">
                                               <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                                           </div>
                                                
                                          <div class="tabs-price">
                                               $150.00 <span>   $180.00</span>
                                           </div>
                                       
                                            <div class="add-to-card">
                                                <ul>
                                                    <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>
                                                    
                                                    <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>
                                                        
                                                    <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>
                                                          
                                                    <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                                </ul>
                                            </div>
                                       </div>
                                       
                                       <div class="tav-wrpper">
                                           <div class="tab-image">
                                             <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p7.jpg" alt=""></a>  
                                           </div>
                                           
                                           <div class="sell">
                                               -16%
                                           </div>
                                           <div class="tab-icons">
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                           </div>
                                           
                                           <div class="tabs-cont">
                                               <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                                           </div>
                                                
                                          <div class="tabs-price">
                                               $150.00 <span>   $180.00</span>
                                           </div>
                                       
                                            <div class="add-to-card">
                                                <ul>
                                                    <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>
                                                    
                                                    <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>
                                                        
                                                    <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>
                                                          
                                                    <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                                </ul>
                                            </div>
                                       </div>
                                       
                                        <div class="tav-wrpper">
                                           <div class="tab-image">
                                             <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p8.jpg" alt=""></a>  
                                           </div>
                                           
                                           <div class="sell">
                                               -16%
                                           </div>
                                           <div class="tab-icons">
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                           </div>
                                           
                                           <div class="tabs-cont">
                                               <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                                           </div>
                                                
                                          <div class="tabs-price">
                                               $150.00 <span>   $180.00</span>
                                           </div>
                                       
                                            <div class="add-to-card">
                                                <ul>
                                                    <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>
                                                    
                                                    <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>
                                                        
                                                    <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>
                                                          
                                                    <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                       
                                        <div class="tav-wrpper">
                                           <div class="tab-image">
                                             <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p9.jpg" alt=""></a>  
                                           </div>
                                           
                                           <div class="sell">
                                               -16%
                                           </div>
                                           <div class="tab-icons">
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                           </div>
                                           
                                           <div class="tabs-cont">
                                               <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                                           </div>
                                                
                                          <div class="tabs-price">
                                               $150.00 <span>   $180.00</span>
                                           </div>
                                       
                                            <div class="add-to-card">
                                                <ul>
                                                    <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>
                                                    
                                                    <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>
                                                        
                                                    <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>
                                                          
                                                    <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                       
                                       
                                       
                                   </div>
                                    
                            </div>

                            <div id="custom-tab-2"  class="tab-pane fade in ">
                                <div class="tab-item-list owl-carousel">
                                    <div class="tav-wrpper">
                                       <div class="tab-image">
                                         <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p5.jpg" alt=""></a>  
                                       </div>

                                       <div class="sell">
                                           -16%
                                       </div>
                                       <div class="tab-icons">
                                           <i class="fa fa-star" aria-hidden="true"></i>
                                           <i class="fa fa-star" aria-hidden="true"></i>
                                           <i class="fa fa-star" aria-hidden="true"></i>
                                           <i class="fa fa-star" aria-hidden="true"></i>
                                       </div>

                                       <div class="tabs-cont">
                                           <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                                       </div>

                                      <div class="tabs-price">
                                           $150.00 <span>   $180.00</span>
                                       </div>

                                        <div class="add-to-card">
                                            <ul>
                                                <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>

                                                <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>

                                                <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>

                                                <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                            </ul>
                                        </div>
                                   </div>

                                       <div class="tav-wrpper">
                                           <div class="tab-image">
                                             <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p6.jpg" alt=""></a>  
                                           </div>
                                           
                                           <div class="sell">
                                               -16%
                                           </div>
                                           <div class="tab-icons">
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                           </div>
                                           
                                           <div class="tabs-cont">
                                               <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                                           </div>
                                                
                                          <div class="tabs-price">
                                               $150.00 <span>   $180.00</span>
                                           </div>
                                       
                                            <div class="add-to-card">
                                                <ul>
                                                    <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>
                                                    
                                                    <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>
                                                        
                                                    <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>
                                                          
                                                    <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                                </ul>
                                            </div>
                                       </div>
                                       
                                       <div class="tav-wrpper">
                                           <div class="tab-image">
                                             <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p7.jpg" alt=""></a>  
                                           </div>
                                           
                                           <div class="sell">
                                               -16%
                                           </div>
                                           <div class="tab-icons">
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                           </div>
                                           
                                           <div class="tabs-cont">
                                               <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                                           </div>
                                                
                                          <div class="tabs-price">
                                               $150.00 <span>   $180.00</span>
                                           </div>
                                       
                                            <div class="add-to-card">
                                                <ul>
                                                    <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>
                                                    
                                                    <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>
                                                        
                                                    <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>
                                                          
                                                    <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                                </ul>
                                            </div>
                                       </div>
                                       
                                        <div class="tav-wrpper">
                                           <div class="tab-image">
                                             <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p10.jpg" alt=""></a>  
                                           </div>
                                           
                                           <div class="sell">
                                               -16%
                                           </div>
                                           <div class="tab-icons">
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                           </div>
                                           
                                           <div class="tabs-cont">
                                               <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                                           </div>
                                                
                                          <div class="tabs-price">
                                               $150.00 <span>   $180.00</span>
                                           </div>
                                       
                                            <div class="add-to-card">
                                                <ul>
                                                    <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>
                                                    
                                                    <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>
                                                        
                                                    <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>
                                                          
                                                    <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                       
                                        <div class="tav-wrpper">
                                           <div class="tab-image">
                                             <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p11.jpg" alt=""></a>  
                                           </div>
                                           
                                           <div class="sell">
                                               -16%
                                           </div>
                                           <div class="tab-icons">
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                           </div>
                                           
                                           <div class="tabs-cont">
                                               <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                                           </div>
                                                
                                          <div class="tabs-price">
                                               $150.00 <span>   $180.00</span>
                                           </div>
                                       
                                            <div class="add-to-card">
                                                <ul>
                                                    <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>
                                                    
                                                    <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>
                                                        
                                                    <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>
                                                          
                                                    <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>

                                   </div>                                    
                            </div>

                            <div id="custom-tab-3"  class="tab-pane fade in ">
                                <div class="tab-item-list owl-carousel">
                                    <div class="tav-wrpper">
                                       <div class="tab-image">
                                         <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p11.jpg" alt=""></a>  
                                       </div>

                                       <div class="sell">
                                           -16%
                                       </div>
                                       <div class="tab-icons">
                                           <i class="fa fa-star" aria-hidden="true"></i>
                                           <i class="fa fa-star" aria-hidden="true"></i>
                                           <i class="fa fa-star" aria-hidden="true"></i>
                                           <i class="fa fa-star" aria-hidden="true"></i>
                                       </div>

                                       <div class="tabs-cont">
                                           <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                                       </div>

                                      <div class="tabs-price">
                                           $150.00 <span>   $180.00</span>
                                       </div>

                                        <div class="add-to-card">
                                            <ul>
                                                <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>

                                                <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>

                                                <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>

                                                <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                            </ul>
                                        </div>
                                   </div>

                                       <div class="tav-wrpper">
                                           <div class="tab-image">
                                             <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p10.jpg" alt=""></a>  
                                           </div>
                                           
                                           <div class="sell">
                                               -16%
                                           </div>
                                           <div class="tab-icons">
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                           </div>
                                           
                                           <div class="tabs-cont">
                                               <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                                           </div>
                                                
                                          <div class="tabs-price">
                                               $150.00 <span>   $180.00</span>
                                           </div>
                                       
                                            <div class="add-to-card">
                                                <ul>
                                                    <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>
                                                    
                                                    <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>
                                                        
                                                    <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>
                                                          
                                                    <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                                </ul>
                                            </div>
                                       </div>
                                       
                                       <div class="tav-wrpper">
                                           <div class="tab-image">
                                             <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p7.jpg" alt=""></a>  
                                           </div>
                                           
                                           <div class="sell">
                                               -16%
                                           </div>
                                           <div class="tab-icons">
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                           </div>
                                           
                                           <div class="tabs-cont">
                                               <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                                           </div>
                                                
                                          <div class="tabs-price">
                                               $150.00 <span>   $180.00</span>
                                           </div>
                                       
                                            <div class="add-to-card">
                                                <ul>
                                                    <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>
                                                    
                                                    <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>
                                                        
                                                    <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>
                                                          
                                                    <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                                </ul>
                                            </div>
                                       </div>
                                       
                                        <div class="tav-wrpper">
                                           <div class="tab-image">
                                             <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p10.jpg" alt=""></a>  
                                           </div>
                                           
                                           <div class="sell">
                                               -16%
                                           </div>
                                           <div class="tab-icons">
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                           </div>
                                           
                                           <div class="tabs-cont">
                                               <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                                           </div>
                                                
                                          <div class="tabs-price">
                                               $150.00 <span>   $180.00</span>
                                           </div>
                                       
                                            <div class="add-to-card">
                                                <ul>
                                                    <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>
                                                    
                                                    <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>
                                                        
                                                    <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>
                                                          
                                                    <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                       
                                        <div class="tav-wrpper">
                                           <div class="tab-image">
                                             <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p11.jpg" alt=""></a>  
                                           </div>
                                           
                                           <div class="sell">
                                               -16%
                                           </div>
                                           <div class="tab-icons">
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                           </div>
                                           
                                           <div class="tabs-cont">
                                               <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                                           </div>
                                                
                                          <div class="tabs-price">
                                               $150.00 <span>   $180.00</span>
                                           </div>
                                       
                                            <div class="add-to-card">
                                                <ul>
                                                    <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>
                                                    
                                                    <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>
                                                        
                                                    <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>
                                                          
                                                    <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                       
                                       
                                       
                                   </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--==========================   section five End ===========================--> 
	   
    <!--========================== Add section one  Start ===========================--> 
	<div class="add-section-one wow fadeInUp" data-wow-duration="1s" data-wow-delay=".9s">
	    <div class="container">
	        <div class="row">
	            <div class="col-md-12">
	                <div class="add-section-one-wrpp">
	                    <div class="add-section-one-image">
	                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/Offer-banner.01.jpg" alt="">
	                    </div>
	                    
	                    <div class="add-content">
	                       <div class="add-section-one-title">
	                            Men's Collection
	                       </div>
	              
                            <div class="add-section-one-subt">
                                Original Brand Sale 20% Off
                            </div>

                            <div class="add-section-one-cont">
                               Perfact Quality Brand Sport Shoes
                            </div>

                            <div class="add-section-one-btn">
                             <a href="">Discover Now</a>
                            </div>
	                    
	                    </div>

	                </div>
	            </div>
	        </div>
	    </div>
	</div>   

    <!--========================== Add section one  End ===========================--> 
	   
    <!--========================== section Six  Start ===========================--> 
    <div class="section-six wow fadeInUp" data-wow-duration="1s" data-wow-delay=".9s">
        <div class="container">
           <div class="count-section-title">
               Deal Of the Day
           </div>
            <div class="row">
                <div class="count-hover">
                    <div class="col-md-6 col-sm-6">
                        <div class="row">
                            <div class="col-md-5 col-sm-5">
                                <div class="count-list-item owl-carousel">
                                   <div class="count-wrpp">
                                       <div class="count-image">
                                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/p5.jpg" alt="">
                                       </div>
                                       <div class="count-sell">
                                           -50%
                                       </div>
                                   </div>
                                    
                                    <div class="count-wrpp">
                                       <div class="count-image">
                                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/p5.jpg" alt="">
                                       </div>
                                       <div class="count-sell">
                                           -50%
                                       </div>
                                    </div>
                                     
                                    <div class="count-wrpp">
                                       <div class="count-image">
                                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/p5.jpg" alt="">
                                       </div>
                                       <div class="count-sell">
                                           -50%
                                       </div>
                                    </div>
                                     
                                    <div class="count-wrpp">
                                       <div class="count-image">
                                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/p5.jpg" alt="">
                                       </div>
                                       <div class="count-sell">
                                           -50%
                                       </div>
                                    </div>
                                   
                                </div>
                                
                                
                                
                            </div>
                            
                            <div class="col-md-7 col-sm-7">
                                <div class="counter-title">
                                  <a href="">quis nostrud exercitation ullamco laboris nisi ut aliquip</a> 
                                </div>
                                
                                <div class="tab-icons">
                                   <i class="fa fa-star" aria-hidden="true"></i>
                                   <i class="fa fa-star" aria-hidden="true"></i>
                                   <i class="fa fa-star" aria-hidden="true"></i>
                                   <i class="fa fa-star" aria-hidden="true"></i>
                                </div>
                                
                                <div class="count-price">
                                   $150.00 <span>   $180.00</span>
                                </div>          
                                          
                                           
                                <div class="counter-contant">
                                    Nam tristique porta ligula, vel viverra sem eleifend nec. Nulla sed purus augue, eu euismod tellus. Nam mattis.
                                </div>
                                
                            
                                <div class="add-to-count">
                                    <ul>
                                        <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>

                                        <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>

                                        <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>

                                        <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                    </ul>
                                </div>

                                
                            </div>
                        </div>
                    </div>
                </div>
                <div class="count-hover">
                    <div class="col-md-6 col-sm-6">
                        <div class="row">
                            <div class="col-md-5 col-sm-5">
                                <div class="count-list-item owl-carousel">
                                   <div class="count-wrpp">
                                       <div class="count-image">
                                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/p5.jpg" alt="">
                                       </div>
                                       <div class="count-sell">
                                           -50%
                                       </div>
                                   </div>
                                    
                                    <div class="count-wrpp">
                                       <div class="count-image">
                                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/p5.jpg" alt="">
                                       </div>
                                       <div class="count-sell">
                                           -50%
                                       </div>
                                    </div>
                                     
                                    <div class="count-wrpp">
                                       <div class="count-image">
                                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/p5.jpg" alt="">
                                       </div>
                                       <div class="count-sell">
                                           -50%
                                       </div>
                                    </div>
                                     
                                    <div class="count-wrpp">
                                       <div class="count-image">
                                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/p5.jpg" alt="">
                                       </div>
                                       <div class="count-sell">
                                           -50%
                                       </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-7 col-sm-7">
                                <div class="counter-title">
                                  <a href="">quis nostrud exercitation ullamco laboris nisi ut aliquip</a> 
                                </div>
                                
                                <div class="tab-icons">
                                   <i class="fa fa-star" aria-hidden="true"></i>
                                   <i class="fa fa-star" aria-hidden="true"></i>
                                   <i class="fa fa-star" aria-hidden="true"></i>
                                   <i class="fa fa-star" aria-hidden="true"></i>
                                </div>
                                
                                <div class="count-price">
                                   $150.00 <span>   $180.00</span>
                                </div>          
                                          
                                           
                                <div class="counter-contant">
                                    Nam tristique porta ligula, vel viverra sem eleifend nec. Nulla sed purus augue, eu euismod tellus. Nam mattis.
                                </div>
                                
                                <div class="add-to-count">
                                    <ul>
                                        <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>

                                        <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>

                                        <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>

                                        <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                    </ul>
                                </div>
                                
                                
                            </div>
                        </div>
                    </div>
                
               </div>
            </div>
        </div>
    </div>
   	   
    <!--========================== section Six  End ===========================--> 
	   
                       
    <!--========================== Add section Two  Start ===========================--> 
        <div class="add-section-two wow fadeInUp" data-wow-duration="1s" data-wow-delay=".9s">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-sm-8">
                        <div class="add-section-two-wrpp">
                                <div class="add-section-two-image">
                                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/Sub-banner-04.jpg" alt="">
                                </div>

                                <div class="add-content-two">
                                   <div class="add-section-two-title">
                                        Top Deals Fashion
                                   </div>


                                    <div class="add-section-two-cont">
                                     Charades, Trivial Pursuit, Hopscotch<br>
                                     And More....
                                    </div>

                                    <div class="add-section-two-btn">
                                     <a href="">Discover Now</a>
                                    </div>

                                </div>



                            </div>
                    </div>
                    <div class="col-md-4 col-sm-4">
                        <div class="add-section-two-image">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/Sub-banner-05.jpg" alt="">
                        </div>
                        <div class="add-content-two">
                           <div class="add-section-two-title">
                                Top Deals Fashion
                           </div>


                            <div class="add-section-two-cont">
                             Laptop, Computer, Audio, Video Game
        Downloads and More...
                            </div>

                            <div class="add-section-two-btn">
                             <a href="">Discover Now</a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
 
    <!--========================== Add section Two  End ===========================--> 

    <!--========================== section Seven  Start ===========================--> 
	   
    <div class="section-seven wow fadeInUp" data-wow-duration="1s" data-wow-delay=".9s">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-3">
                    <div class="porducts-add-wrpp">
                        <div class="products-add-image">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/Pro-banner-01.png" alt="">
                        </div>
                        <div class="products-add-content">
                            <div class="porducts-add-titl">
                                New clothes
                            </div> 
                            <div class="p-add-cont">
                               Lorem ipsum dolor consectetu adipis cing elit.
                            </div>
                            <div class="p-add-btn">
                                <a href="">View All</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-9 col-sm-9">
                    <div class="products-item owl-carousel">
                        <div class="tav-wrpper">
                           <div class="tab-image">
                             <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p11.jpg" alt=""></a>  
                           </div>

                           <div class="sell">
                               -16%
                           </div>
                           <div class="tab-icons">
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                           </div>

                           <div class="tabs-cont">
                               <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                           </div>

                          <div class="tabs-price">
                               $150.00 <span>   $180.00</span>
                           </div>

                            <div class="add-to-card">
                                <ul>
                                    <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                       </div>

                       <div class="tav-wrpper">
                           <div class="tab-image">
                             <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p10.jpg" alt=""></a>  
                           </div>

                           <div class="sell">
                               -16%
                           </div>
                           <div class="tab-icons">
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                           </div>

                           <div class="tabs-cont">
                               <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                           </div>

                          <div class="tabs-price">
                               $150.00 <span>   $180.00</span>
                           </div>

                            <div class="add-to-card">
                                <ul>
                                    <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                       </div>
                                       
                       <div class="tav-wrpper">
                           <div class="tab-image">
                             <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p7.jpg" alt=""></a>  
                           </div>

                           <div class="sell">
                               -16%
                           </div>
                           <div class="tab-icons">
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                           </div>

                           <div class="tabs-cont">
                               <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                           </div>

                          <div class="tabs-price">
                               $150.00 <span>   $180.00</span>
                           </div>

                            <div class="add-to-card">
                                <ul>
                                    <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                       </div>

                        <div class="tav-wrpper">
                           <div class="tab-image">
                             <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p10.jpg" alt=""></a>  
                           </div>

                           <div class="sell">
                               -16%
                           </div>
                           <div class="tab-icons">
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                           </div>

                           <div class="tabs-cont">
                               <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                           </div>

                          <div class="tabs-price">
                               $150.00 <span>   $180.00</span>
                           </div>

                            <div class="add-to-card">
                                <ul>
                                    <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                        </div>
                                       
                        <div class="tav-wrpper">
                           <div class="tab-image">
                             <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p11.jpg" alt=""></a>  
                           </div>

                           <div class="sell">
                               -16%
                           </div>
                           <div class="tab-icons">
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                           </div>

                           <div class="tabs-cont">
                               <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                           </div>

                          <div class="tabs-price">
                               $150.00 <span>   $180.00</span>
                           </div>

                            <div class="add-to-card">
                                <ul>
                                    <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                        </div>
                                       
                                       
                                       
                    </div>
                </div>
            </div>
        </div>
    </div>
        
    <!--==========================section Seven  End===========================--> 
	                        
    <!--========================== section Eight  Start ===========================--> 
	   
    <div class="section-eight wow fadeInUp" data-wow-duration="1s" data-wow-delay=".9s">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-3">
                    <div class="porducts-add-wrpp">
                        <div class="products-add-image">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/Pro-banner-02.png" alt="">
                        </div>
                        <div class="products-add-content">
                            <div class="porducts-add-titl">
                                New clothes
                            </div> 
                            <div class="p-add-cont">
                               Lorem ipsum dolor consectetu adipis cing elit.
                            </div>
                            <div class="p-add-btn">
                                <a href="">View All</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-9 col-sm-9">
                    <div class="products-item owl-carousel">
                        <div class="tav-wrpper">
                           <div class="tab-image">
                             <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p11.jpg" alt=""></a>  
                           </div>

                           <div class="sell">
                               -16%
                           </div>
                           <div class="tab-icons">
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                           </div>

                           <div class="tabs-cont">
                               <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                           </div>

                          <div class="tabs-price">
                               $150.00 <span>   $180.00</span>
                           </div>

                            <div class="add-to-card">
                                <ul>
                                    <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                       </div>

                       <div class="tav-wrpper">
                           <div class="tab-image">
                             <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p10.jpg" alt=""></a>  
                           </div>

                           <div class="sell">
                               -16%
                           </div>
                           <div class="tab-icons">
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                           </div>

                           <div class="tabs-cont">
                               <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                           </div>

                          <div class="tabs-price">
                               $150.00 <span>   $180.00</span>
                           </div>

                            <div class="add-to-card">
                                <ul>
                                    <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                       </div>
                                       
                       <div class="tav-wrpper">
                           <div class="tab-image">
                             <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p7.jpg" alt=""></a>  
                           </div>

                           <div class="sell">
                               -16%
                           </div>
                           <div class="tab-icons">
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                           </div>

                           <div class="tabs-cont">
                               <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                           </div>

                          <div class="tabs-price">
                               $150.00 <span>   $180.00</span>
                           </div>

                            <div class="add-to-card">
                                <ul>
                                    <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                       </div>

                        <div class="tav-wrpper">
                           <div class="tab-image">
                             <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p10.jpg" alt=""></a>  
                           </div>

                           <div class="sell">
                               -16%
                           </div>
                           <div class="tab-icons">
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                           </div>

                           <div class="tabs-cont">
                               <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                           </div>

                          <div class="tabs-price">
                               $150.00 <span>   $180.00</span>
                           </div>

                            <div class="add-to-card">
                                <ul>
                                    <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                        </div>
                                       
                        <div class="tav-wrpper">
                           <div class="tab-image">
                             <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p11.jpg" alt=""></a>  
                           </div>

                           <div class="sell">
                               -16%
                           </div>
                           <div class="tab-icons">
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                           </div>

                           <div class="tabs-cont">
                               <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                           </div>

                          <div class="tabs-price">
                               $150.00 <span>   $180.00</span>
                           </div>

                            <div class="add-to-card">
                                <ul>
                                    <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                        </div>             
                    </div>
                </div>
            </div>
        </div>
    </div>
         
    <!--==========================section Eight  End ===========================--> 
	   
    
    <!--========================== section nine  Start ===========================--> 
	   
    <div class="section-nine  wow fadeInUp" data-wow-duration="1s" data-wow-delay=".9s">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-3">
                    <div class="porducts-add-wrpp">
                        <div class="products-add-image">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/Pro-banner-03.png" alt="">
                        </div>
                        <div class="products-add-content">
                            <div class="porducts-add-titl">
                                New clothes
                            </div> 
                            <div class="p-add-cont">
                               Lorem ipsum dolor consectetu adipis cing elit.
                            </div>
                            <div class="p-add-btn">
                                <a href="">View All</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-9 col-sm-9">
                    <div class="products-item owl-carousel">
                        <div class="tav-wrpper">
                           <div class="tab-image">
                             <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p11.jpg" alt=""></a>  
                           </div>

                           <div class="sell">
                               -16%
                           </div>
                           <div class="tab-icons">
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                           </div>

                           <div class="tabs-cont">
                               <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                           </div>

                          <div class="tabs-price">
                               $150.00 <span>   $180.00</span>
                           </div>

                            <div class="add-to-card">
                                <ul>
                                    <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                       </div>

                       <div class="tav-wrpper">
                           <div class="tab-image">
                             <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p10.jpg" alt=""></a>  
                           </div>

                           <div class="sell">
                               -16%
                           </div>
                           <div class="tab-icons">
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                           </div>

                           <div class="tabs-cont">
                               <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                           </div>

                          <div class="tabs-price">
                               $150.00 <span>   $180.00</span>
                           </div>

                            <div class="add-to-card">
                                <ul>
                                    <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                       </div>
                                       
                       <div class="tav-wrpper">
                           <div class="tab-image">
                             <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p7.jpg" alt=""></a>  
                           </div>

                           <div class="sell">
                               -16%
                           </div>
                           <div class="tab-icons">
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                           </div>

                           <div class="tabs-cont">
                               <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                           </div>

                          <div class="tabs-price">
                               $150.00 <span>   $180.00</span>
                           </div>

                            <div class="add-to-card">
                                <ul>
                                    <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                       </div>

                        <div class="tav-wrpper">
                           <div class="tab-image">
                             <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p10.jpg" alt=""></a>  
                           </div>

                           <div class="sell">
                               -16%
                           </div>
                           <div class="tab-icons">
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                           </div>

                           <div class="tabs-cont">
                               <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                           </div>

                          <div class="tabs-price">
                               $150.00 <span>   $180.00</span>
                           </div>

                            <div class="add-to-card">
                                <ul>
                                    <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                        </div>
                                       
                        <div class="tav-wrpper">
                           <div class="tab-image">
                             <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p11.jpg" alt=""></a>  
                           </div>

                           <div class="sell">
                               -16%
                           </div>
                           <div class="tab-icons">
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                           </div>

                           <div class="tabs-cont">
                               <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                           </div>

                          <div class="tabs-price">
                               $150.00 <span>   $180.00</span>
                           </div>

                            <div class="add-to-card">
                                <ul>
                                    <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                        </div>            
                                       
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--========================== section Nine  End ===========================--> 

    <!--========================== Add section Three  Start===========================--> 
        <div class="add-section-two wow fadeInUp" data-wow-duration="1s" data-wow-delay=".9s">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-sm-6">
                        <div class="add-section-two-wrpp">
                            <div class="add-section-two-image">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/Cms-banner-01.jpg" alt="">
                            </div>

                            <div class="add-content-two">
                               <div class="add-section-two-title">
                                    Sale 27% Flate
                               </div>


                                <div class="add-section-two-cont">
                                 Charades, Trivial Pursuit, Hopscotch<br>
                                    And More....
                                </div>

                                <div class="add-section-two-btn">
                                 <a href="">Discover Now</a>
                                </div>

                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6 col-sm-6">
                        <div class="add-section-two-image">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/Cms-banner-02.jpg" alt="">
                        </div>
                        <div class="add-content-two">
                           <div class="add-section-two-title">
                                Top Deals Fashion
                           </div>


                            <div class="add-section-two-cont">
                             Laptop, Computer, Audio, Video Game
        Downloads and More...
                            </div>

                            <div class="add-section-two-btn">
                             <a href="">Discover Now</a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    <!--========================== Add section Three  End ===========================--> 
	   
    
    <!--========================== section Ten  Start ===========================--> 
	   
    <div class="section-ten wow fadeInUp" data-wow-duration="1s" data-wow-delay=".9s">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="tab-item-list owl-carousel">
                        <div class="tav-wrpper">
                           <div class="tab-image">
                             <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p11.jpg" alt=""></a>  
                           </div>

                           <div class="sell">
                               -16%
                           </div>
                           <div class="tab-icons">
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                           </div>

                           <div class="tabs-cont">
                               <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                           </div>

                          <div class="tabs-price">
                               $150.00 <span>   $180.00</span>
                           </div>

                            <div class="add-to-card">
                                <ul>
                                    <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                       </div>

                       <div class="tav-wrpper">
                           <div class="tab-image">
                             <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p10.jpg" alt=""></a>  
                           </div>

                           <div class="sell">
                               -16%
                           </div>
                           <div class="tab-icons">
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                           </div>

                           <div class="tabs-cont">
                               <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                           </div>

                          <div class="tabs-price">
                               $150.00 <span>   $180.00</span>
                           </div>

                            <div class="add-to-card">
                                <ul>
                                    <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                       </div>
                                       
                       <div class="tav-wrpper">
                           <div class="tab-image">
                             <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p7.jpg" alt=""></a>  
                           </div>

                           <div class="sell">
                               -16%
                           </div>
                           <div class="tab-icons">
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                           </div>

                           <div class="tabs-cont">
                               <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                           </div>

                          <div class="tabs-price">
                               $150.00 <span>   $180.00</span>
                           </div>

                            <div class="add-to-card">
                                <ul>
                                    <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                       </div>

                        <div class="tav-wrpper">
                           <div class="tab-image">
                             <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p10.jpg" alt=""></a>  
                           </div>

                           <div class="sell">
                               -16%
                           </div>
                           <div class="tab-icons">
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                           </div>

                           <div class="tabs-cont">
                               <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                           </div>

                          <div class="tabs-price">
                               $150.00 <span>   $180.00</span>
                           </div>

                            <div class="add-to-card">
                                <ul>
                                    <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                        </div>
                                       
                        <div class="tav-wrpper">
                           <div class="tab-image">
                             <a href=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/p11.jpg" alt=""></a>  
                           </div>

                           <div class="sell">
                               -16%
                           </div>
                           <div class="tab-icons">
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                               <i class="fa fa-star" aria-hidden="true"></i>
                           </div>

                           <div class="tabs-cont">
                               <a href="">consectetur, adipisci velit sed quia non numquam eius modi</a>
                           </div>

                          <div class="tabs-price">
                               $150.00 <span>   $180.00</span>
                           </div>

                            <div class="add-to-card">
                                <ul>
                                    <li><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a></li>

                                    <li><a href=""><i class="fa fa-clone" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--========================== section Ten  End ===========================--> 
	 
    <!--========================== Add & blog section Start ===========================--> 
        <div class="blog-section wow fadeInUp" data-wow-duration="1s" data-wow-delay=".9s">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-sm-6">
                        <div class="add-section-two-image">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/Cms-banner-03.jpg" alt="">
                        </div>
                        <div class="add-content-two">
                           <div class="add-section-two-title">
                                Top Deals Fashion
                           </div>


                            <div class="add-section-two-cont">
                             Laptop, Computer, Audio, Video Game
        Downloads and More...
                            </div>

                            <div class="add-section-two-btn">
                             <a href="">Discover Now</a>
                            </div>

                        </div>
                    </div>
                    
                    <div class="col-md-6 col-sm-6">
                       <div class="blog-title">
                           From The Blog
                       </div>
                        <div class="blog-list owl-carousel">
                            <div class="row">
                                <div class="col-md-6 col-sm-6">
                                    <div class="blog-image">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/magnam-1.jpg" alt="">
                                    </div>                                
                                </div>       
                                
                                <div class="col-md-6 col-sm-6">
                                    <div class="blog-item-wrpp">
                                        <div class="blog-item-title">
                                           <a href=""> Moment For Shooting</a>
                                        </div>
                                        
                                        <div class="blog-item-date">
                                            13th September, 2019
                                        </div>
                                            
                                        <div class="blog-item-content">
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore 
                                        </div>
                                                                            
                                    </div>
                                </div>

                            </div>

                            <div class="row">
                                <div class="col-md-6 col-sm-6">
                                    <div class="blog-image">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/magnam-1.jpg" alt="">
                                    </div>                                
                                </div>       
                                
                                <div class="col-md-6 col-sm-6">
                                    <div class="blog-item-wrpp">
                                        <div class="blog-item-title">
                                            <a href=""> Moment For Shooting</a>
                                        </div>
                                        
                                        <div class="blog-item-date">
                                            14th September, 2019
                                        </div>
                                            
                                        <div class="blog-item-content">
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore 
                                        </div>
                                                                            
                                    </div>
                                </div>
                            </div>
                            
                            
                                
                            <div class="row">
                                <div class="col-md-6 col-sm-6">
                                    <div class="blog-image">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/magnam-1.jpg" alt="">
                                    </div>                                
                                </div>       
                                
                                <div class="col-md-6 col-sm-6">
                                    <div class="blog-item-wrpp">
                                        <div class="blog-item-title">
                                            <a href=""> Moment For Shooting</a>
                                        </div>
                                        
                                        <div class="blog-item-date">
                                          15th September, 2019
                                        </div>
                                            
                                        <div class="blog-item-content">
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore 
                                        </div>
                                                                            
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
             
                </div>
            </div>
        </div>

    <!--========================== Add & blog section End ===========================--> 
        
    <!--================================ section-Eleven-start ===============================-->
        <section class="Partner-section wow fadeInUp" data-wow-duration="1s" data-wow-delay=".9s">
           <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="partner-list owl-carousel">
                            <div class="Partner-item">
                                <a href=""> <img src="<?php echo get_template_directory_uri(); ?>/assets/img/brand1.jpg"></a>
                            </div>
                            <div class="Partner-item">
                               <a href=""> <img src="<?php echo get_template_directory_uri(); ?>/assets/img/brand2.jpg"></a>
                            </div>
                            <div class="Partner-item">
                                <a href=""> <img src="<?php echo get_template_directory_uri(); ?>/assets/img/brand3.jpg"></a>
                            </div>
                            <div class="Partner-item">
                                <a href=""> <img src="<?php echo get_template_directory_uri(); ?>/assets/img/brand1.jpg"></a>
                            </div>
                            <div class="Partner-item">
                                 <a href=""> <img src="<?php echo get_template_directory_uri(); ?>/assets/img/brand3.jpg"></a>
                            </div>
                            <div class="Partner-item">
                                <a href=""> <img src="<?php echo get_template_directory_uri(); ?>/assets/img/brand2.jpg"></a>
                            </div>
                            
                            <div class="Partner-item">
                                 <a href=""> <img src="<?php echo get_template_directory_uri(); ?>/assets/img/brand1.jpg"></a>
                            </div>
                                    
                            <div class="Partner-item">
                                 <a href=""> <img src="<?php echo get_template_directory_uri(); ?>/assets/img/brand2.jpg"></a>
                            </div>
                            
                            <div class="Partner-item">
                                <a href=""> <img src="<?php echo get_template_directory_uri(); ?>/assets/img/brand3.jpg"></a>
                            </div>
                            
                         </div>
                     </div>
                </div>
            </div>
       </section> 
                        
        <!--================================  section-Eleven-End ===============================-->
              
    <?php get_footer(); ?>