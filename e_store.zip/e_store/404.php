<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package e_store
 */

get_header();
?>



	<div class="body-content outer-top-bd">
		<div class="container">
			<div class="x-page inner-bottom-sm">
				<div class="row">
					<div class="col-md-12 x-text text-center">
					<h1 class="page-title"><?php esc_html_e( '404', 'e_store' ); ?></h1>

						<p><?php esc_html_e( 'It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'e_store' ); ?></p>
							<?php //get_search_form(); ?>

						<a href="<?php  echo home_url('/');?>"><i class="fa fa-home"></i> <?php esc_html_e( 'Go To Homepage', 'e_store' ); ?></a>
						</div>
					</div><!-- /.row -->
			</div><!-- /.sigin-in-->
		</div><!-- /.container -->
	</div><!-- /.body-content -->

<?php
get_footer();
