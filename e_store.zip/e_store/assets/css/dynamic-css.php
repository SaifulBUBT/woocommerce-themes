<?php  global $themesbazar; ?>

<style>
    body {
        background-color: <?php echo $themesbazar['body-bg']; ?>;
        font-size: 16px;
	
    }
</style>