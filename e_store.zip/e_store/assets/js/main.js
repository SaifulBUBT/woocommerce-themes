;(function ($) {
	"use strict";

    jQuery(document).ready(function(){



	$(window).scroll(function(){
	        if ($(this).scrollTop() > 100) {
	            $('.scrollToTop').fadeIn();
	        } else {
	            $('.scrollToTop').fadeOut();
	        }
	    });

	    //Click event to scroll to top
	    $('.scrollToTop').on('click', function(){
	        $('html, body').animate({scrollTop : 0},800);
	        return false;
	    });

	$('ul.dropdown-menu [data-toggle=dropdown]').on('click', function(event) {
			event.preventDefault(); 
			event.stopPropagation(); 
			$(this).parent().siblings().removeClass('open');
			$(this).parent().toggleClass('open');
		});


	$(".homepage_slides").owlCarousel({
    		items: 1,
    		nav: true,
    		dots: true,
    		loop: true,
    		autoplay: true,
            navText: ["<i class='fa fa-arrow-left'</i>", "<i class='fa fa-arrow-right'</i>"],
    	});



    $(".special_product_sec").owlCarousel({
    		items: 2,
    		nav: true,
    		dots: false,
			loop: true,
			margin: 10,
    		autoplay: true,
            navText: ["<i Class='fa fa-long-arrow-left'></i>", 
					  "<i Class='fa fa-long-arrow-right'></i>"],
			responsiveClass: true,
			responsive: {
				0:{
				items: 1,
				},
				375:{
					items: 1,
					},
				480:{
				items: 2,
				},
				768:{
				items:1,
				},
				800:{
				items: 1,
				}
			}		  
    	});	

    $(".carasule_product").owlCarousel({
			items: 4,
		    dots: true,
			autoplay: true,
			margin: 15,
			loop: true,
			nav: true,
			navText: [
				"<i class='fa fa-angle-left'></i>",
				"<i class='fa fa-angle-right'></i>"
			],
		    responsiveClass: true,
		    responsive: {
		        0:{
		          items: 2,
				},
				375:{
					items: 2,
				  },
		        480:{
		          items: 2,
		        },
		        768:{
		          items:3,
		        },
		        800:{
		          items: 4,
		        }
		    }
		});

    $(".Latest_news_section").owlCarousel({
		    dots: true,
			autoplay: true,
			margin: 15,
			loop: true,
			nav: true,
			navText: [
				"<i class='fa fa-long-arrow-left'></i>",
				"<i class='fa fa-long-arrow-right'></i>"
			],
		    responsiveClass: true,
		    responsive: {
		        0:{
		          items: 1,
		        },
		        480:{
		          items: 2,
		        },
		        768:{
		          items:2,
		        },
		        800:{
		          items: 3,
		        }
		    }
		});

    $(".Video_section").owlCarousel({
		    dots: true,
			autoplay: true,
			margin: 15,
			loop: true,
			nav: true,
			navText: [
				"<i class='fa fa-long-arrow-left'></i>",
				"<i class='fa fa-long-arrow-right'></i>"
			],
		    responsiveClass: true,
		    responsive: {
		        0:{
		          items: 1,
		        },
		        480:{
		          items: 2,
		        },
		        768:{
		          items:3,
		        },
		        800:{
		          items: 5,
		        }
		    }
		});

	
	
       new WOW().init(); 



    });




})(jQuery);