<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package e_store
 */

?>
<?php  global $themesbazar; ?>

<section class="footer_section wow fadeInUp" data-wow-delay="300ms">
		<div class="container">
			
			<div class="footer_border">
				<div class="row">
					<div class="col-md-3 col-sm-3">
						<div class="footer_logo">
							<?php
							$e_store_footer_logo_url =  $themesbazar['footer-logo']['url'];
							if( ! empty($e_store_footer_logo_url)) {
								?>
								<a href="<?php echo home_url( '/' ) ?>"><img src="<?php echo $e_store_footer_logo_url; ?>"/></a>
								<?php } else{ ?>
								<a href="<?php echo home_url( '/' ); ?>"><img src="<?php  echo get_template_directory_uri();?>/assets/images/logo.gif"/></a>	
								<?php } 
							?>
						</div>
						
						<div class="footer_address">
							<?php if (($themesbazar['contact-address'])) :?>
								<h4 class="contcat_info"> <i class="fa fa-map-marker"></i> 
									<?php echo $themesbazar['contact-address']; ?>
								</h4 >
							<?php endif; ?>

							<?php if (($themesbazar['contact-email-address'])) :?>
								<h4 class="contcat_info"> <i class="fa fa-envelope-o"></i> 
									<?php echo $themesbazar['contact-email-address']; ?>
								</h4>  
							<?php endif; ?>

							<?php if (($themesbazar['contact-phone-no'])) :?>
								<h4 class="contcat_info"> <i class="fa fa-phone"></i> 
									<?php echo $themesbazar['contact-phone-no']; ?>
								</h4> 
							<?php endif; ?>

						</div>
					</div>

					<div class="col-md-3 col-sm-3">
						<div class="footer_menu_title">
							<h4><?php echo $themesbazar['footer-menu-1-title']; ?></h4>
						</div>
						<div class="footer_menu">
							<?php 
								wp_nav_menu( array(
									'theme_location' => 'footer-one',
				
								));
							?>
						</div>
					</div>
					<div class="col-md-3 col-sm-3">
						<div class="footer_menu_title">
						<h4><?php echo $themesbazar['footer-menu-2-title']; ?></h4>

						</div>
						<div class="footer_menu">
							<?php 
								wp_nav_menu( array(
									'theme_location' => 'footer-two',
				
								));
							?>
						</div>
					</div>
					<div class="col-md-3 col-sm-3">
						<div class="footer_menu_title">
							<h4><?php esc_html_e( 'Our Like Page', 'e_store' ); ?></h4>
						</div>
							<script>(function(d, s, id) {
							var js, fjs = d.getElementsByTagName(s)[0];
							if (d.getElementById(id)) return;
							js = d.createElement(s); js.id = id;
							js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5";
							fjs.parentNode.insertBefore(js, fjs);
							}(document, 'script', 'facebook-jssdk'));</script>
						<div class="fb-page" data-href="<?php echo $themesbazar['facebook-like-page']['face-url']; ?>" data-width="<?php echo $themesbazar['facebook-like-page-width']?>" data-height="<?php echo $themesbazar['facebook-like-page-height']?>" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"></div>

					</div>
				</div>
			</div>


			<div class="row">
				<div class="social_pament_sec">
					<div class="col-md-7 col-sm-7">
						<div class="footer_social">
							<?php //print_r($themesbazar['ftr-social-link']); ?>

							<ul>
								<?php if(!empty($themesbazar['ftr-social-link']['facebook-url'])): ?>
									<li><a href="<?php echo esc_url($themesbazar['ftr-social-link']['facebook-url']); ?>" target="_blank"  class="facebook"> <i class="fa fa-facebook"></i> Facebook</a></li>
								<?php endif; ?>

								<?php if(!empty($themesbazar['ftr-social-link']['twitter-url'])): ?>
									<li><a href="<?php echo esc_url($themesbazar['ftr-social-link']['twitter-url']); ?>" target="_blank" class="twitter"> <i class="fa fa-twitter"></i> Twitter</a></li>
								<?php endif; ?>

								<?php if(!empty($themesbazar['ftr-social-link']['linkedin-url'])): ?>
								<li><a href="<?php echo esc_url($themesbazar['ftr-social-link']['linkedin-url']); ?>" target="_blank" class="linkedin"> <i class="fa fa-linkedin"></i> Linkedin </a></li>
								<?php endif; ?>

								<?php if(!empty($themesbazar['ftr-social-link']['youtube-url'])): ?>
								<li><a href="<?php echo esc_url($themesbazar['ftr-social-link']['youtube-url']); ?>" target="_blank" class="youtube"> <i class="fa fa-youtube"></i> Youtube </a></li>
								<?php endif; ?>

								<?php if(!empty($themesbazar['ftr-social-link']['googleplus-url'])): ?>
								<li><a href="<?php echo esc_url($themesbazar['ftr-social-link']['googleplus-url']); ?>" target="_blank" class="google-plus"> <i class="fa fa-google-plus"></i> Google Plus</a></li>
								<?php endif; ?>

							</ul>
						</div>
					</div>
					<div class="col-md-5 col-sm-5">
						<div class="row">

						<?php 
							$payment_logos = $themesbazar['payment-method-logo'];
							$logos = explode(',',$payment_logos);
							foreach($logos as $logo){
								?>

								<div class="col-md-2 col-sm-4 col-xs-4">
									<div class="payment_matod">
										<img src="<?php echo wp_get_attachment_image_src($logo, array('150','100'))[0]; ?>"/>
									</div>
								</div>
								<?php
							}
						?>

					
						</div>
					</div>
				</div> 
			</div> 

		</div>
	</section>


	<!--============ Bottom Footer Section  =============-->

	<section class="btm-footer-section">
		<div class="container">
			<div class="row">
				<div class="col-sm-6 col-md-6">
					<div class="copy">
						<p><?php echo $themesbazar['copyright']; ?></p>
					</div>
				</div>
				<div class="col-sm-6 col-md-6">
					<div class="design">
						Design and Devoloped By <a href="http://themesbazar.com/" target="_blank" title="Mobile :   +8801732-667364"> ThemesBazar.Com</a>
					</div>
				</div>
			</div>

			<!------------- go to top start -------------->

			<a href="" class="scrollToTop"><i class="fa fa-angle-up"></i></a>

			<!------------- go to top close ------------>

		</div>  
	</section>


	<?php wp_footer(); ?>
</body>
</html>