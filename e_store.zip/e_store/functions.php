<?php
/**
 * e_store functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package e_store
 */

if ( ! function_exists( 'e_store_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function e_store_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on e_store, use a find and replace
		 * to change 'e_store' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'e_store', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus( array(
			'main-menu' => esc_html__( 'Main menu', 'e_store' ),
			'top-menu' => esc_html__( 'Top menu', 'e_store' ),
			'side-bar-menu' => esc_html__( 'Sidebar menu', 'e_store' ),
			'footer-one' => __('Footer Menu One','e_store'),
			'footer-two' => __('Footer Menu Two','e_store'),
			
		) );

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

		/*
		 * Woocommerce support
		 */
		add_theme_support( 'woocommerce' );

		// Set up the WordPress core custom background feature.
		add_theme_support( 'custom-background', apply_filters( 'e_store_custom_background_args', array(
			'default-color' => 'ffffff',
			'default-image' => '',
		) ) );

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support( 'custom-logo', array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		) );
	}
endif;
add_action( 'after_setup_theme', 'e_store_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function e_store_content_width() {
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters( 'e_store_content_width', 640 );
}
add_action( 'after_setup_theme', 'e_store_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function e_store_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'e_store' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'e_store' ),
		'before_widget' => '<div class="sidebar-widget product-tag wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">
		',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="section-title">',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
		'name'          => esc_html__( 'Shop Sidebar', 'e_store' ),
		'id'            => 'shop-sidebar',
		'description'   => esc_html__( 'Add widgets here.', 'e_store' ),
		'before_widget' => '<div class="sidebar-widget product-tag wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">
		',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="section-title">',
		'after_title'   => '</h3>',
	) );
            
}
add_action( 'widgets_init', 'e_store_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function e_store_scripts() {
	wp_enqueue_style('bootstrap-css', get_theme_file_uri('/assets/css/bootstrap.min.css'));
    wp_enqueue_style('menu-css', get_theme_file_uri('/assets/css/menu.css'), array(), time());
    wp_enqueue_style('font-awesome-css', get_theme_file_uri('/assets/css/font-awesome.min.css'));
	wp_enqueue_style('owl-carousel-css', get_theme_file_uri('/assets/css/owl.carousel.css'));
	wp_enqueue_style( 'owl.transitions', get_template_directory_uri().'/assets/css/owl.transitions.css', array(), '1.0' );
	wp_enqueue_style('animate-css', get_theme_file_uri('/assets/css/animate.css'));
	wp_enqueue_style( 'rateit', get_template_directory_uri().'/assets/css/rateit.css', array(), '1.0' );


	wp_enqueue_style( 'main', get_template_directory_uri().'/assets/css/wtheme.css', array(), time() );
	wp_enqueue_style( 'blue', get_template_directory_uri().'/assets/css/blue.css', array(), '1.0' );
	wp_enqueue_style('main-css', get_theme_file_uri('/assets/main.css'), null, time());
	wp_enqueue_style('woocommerce-css', get_theme_file_uri('/assets/css/woocommerce.css'), null, time());
	wp_enqueue_style('responsive-css', get_theme_file_uri('/assets/css/responsive.css'), null, time());

	wp_enqueue_style( 'e_store-style', get_stylesheet_uri(), null, time() );


	wp_enqueue_script( 'e_store-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20151215', true );

	wp_enqueue_script( 'e_store-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20151215', true );

	wp_enqueue_script('bootstrap-js', get_theme_file_uri('/assets/js/bootstrap.min.js'), array('jquery'), '1.0', true);
	wp_enqueue_script('owl-carousel-js', get_theme_file_uri('/assets/js/owl.carousel.min.js'), array('jquery'), '1.0', true);
	wp_enqueue_script( 'echo-js', get_template_directory_uri() . '/assets/js/echo.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'jquery-easing', get_template_directory_uri() . '/assets/js/jquery.easing-1.3.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'jquery-rateit', get_template_directory_uri() . '/assets/js/jquery.rateit.min.js', array(), '1.0.0', true );
	wp_enqueue_script('wow-js', get_theme_file_uri('/assets/js/wow.js'), array('jquery'), '1.0', true);
	wp_enqueue_script('scripts', get_theme_file_uri('/assets/js/scripts.js'), array('jquery'), '1.0', time(), true);
	wp_enqueue_script('main', get_theme_file_uri('/assets/js/main.js'), array('jquery'), '1.0', time(), true);

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'e_store_scripts' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}
/**
 * bootstrap nav walker
 */
if ( ! file_exists( get_template_directory() . '/lib/class-wp-bootstrap-navwalker.php' ) ) {
    // File does not exist... return an error.
    return new WP_Error( 'class-wp-bootstrap-navwalker-missing', __( 'It appears the class-wp-bootstrap-navwalker.php file may be missing.', 'wp-bootstrap-navwalker' ) );
} else {
    // File exists... require it.
    require_once get_template_directory() . '/lib/class-wp-bootstrap-navwalker.php';
}

/*****
 * Bredcrumbs
 */
require_once get_theme_file_path('/inc/breadcrumbs.php');

/*****
 * Custom post types
 */
require_once get_theme_file_path('/inc/custom-post-types.php');

/**
 * Tgm plugin activatiom
 */
require_once get_theme_file_path('/inc/tgm.php');

/**
 * CMB2 metabox field crete
 */
require_once get_theme_file_path('/metabox/init.php');
require_once get_theme_file_path('/metabox/functions.php');




/**
 * Implement Redux Framework
 */
require_once get_template_directory() . '/lib/redux-framework/ReduxCore/framework.php';
require_once get_template_directory() . '/lib/redux-framework/ReduxCore/templates/panel/config.php';
require_once get_template_directory() . '/lib/redux-framework/sample/config.php';

require_once get_template_directory() . '/include/menu.php';
require_once get_template_directory() . '/include/wp-bootstrap-navwalker.php';
//require_once get_template_directory() . '/include/widget.php';


/****
 * Highlight search result
 * * */
function e_store_highlight_search_results($text){
    if(is_search()){
        $pattern = '/('. join('|', explode(' ', get_search_query())).')/i';
        $text = preg_replace($pattern, '<span class="search-highlight">\0</span>', $text);
    }
    return $text;
}
add_filter('the_content', 'e_store_highlight_search_results');
add_filter('the_excerpt', 'e_store_highlight_search_results');
add_filter('the_title', 'e_store_highlight_search_results');



/****
 * Code for woocommerce
 * *** */

remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20);
remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );
remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );
remove_action( 'woocommerce_after_shop_loop', 'woocommerce_pagination', 10 );


/***
 * Shop page columns no
 * ** */
function e_store_loop_shop_column($nc)
{
    return 3;
}
add_filter('loop_shop_columns', 'e_store_loop_shop_column');

/***
 * create pagination function
 */
if (!function_exists('woo_e_store_pagination')) :
    function woo_e_store_pagination()
    {
        global $wp_query;

        if ($wp_query->max_num_pages <= 1) return;

        $big = 999999999; // need an unlikely integer

        $pages = paginate_links(array(
            'base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
            'format' => '?paged=%#%',
            'current' => max(1, get_query_var('paged')),
            'total' => $wp_query->max_num_pages,
            'mid_size' => 1,
            'prev_next' => true,
            'prev_text'    => __('<i class="fa fa-angle-left"></i>'),
            'next_text'    => __('<i class="fa fa-angle-right"></i>'),
            'type'         => 'array'
        ));

        if (is_array($pages)) {
            $paged = (get_query_var('paged') == 0) ? 1 : get_query_var('paged');
            echo '<div class="pagination-container"><ul class="list-inline list-unstyled">';
            foreach ($pages as $page) {
                echo "<li>$page</li>";
            }
            echo '</ul></div>';
        }
    }
endif;


/****
 * WooCommerce shop page show per page drop down
 * */
function e_store_woocommerce_catalog_page_ordering() {
	?>
	<div class="lbl-cnt">
	<?php echo '<span class="lbl">Show</span>' ?>
	<form action="" method="POST" name="results" class="fld inline">
	<select name="woocommerce-sort-by-columns" id="woocommerce-sort-by-columns" class="sortby" onchange="this.form.submit()">
	<?php
	//Get products on page reload
	if  (isset($_POST['woocommerce-sort-by-columns']) && (($_COOKIE['shop_pageResults'] <> $_POST['woocommerce-sort-by-columns']))) {
	$numberOfProductsPerPage = $_POST['woocommerce-sort-by-columns'];
	} else {
	$numberOfProductsPerPage = $_COOKIE['shop_pageResults'];
	}
	//  This is where you can change the amounts per page that the user will use  feel free to change the numbers and text as you want, in my case we had 4 products per row so I chose to have multiples of four for the user to select.
	$shopCatalog_orderby = apply_filters('woocommerce_sortby_page', array(
	//Add as many of these as you like, -1 shows all products per page
	//  ''       => __('Results per page', 'woocommerce'),
	'12' 		=> __('12', 'e_store'),
	'15' 		=> __('15', 'e_store'),
	'18' 		=> __('18', 'e_store'),
	'30' 		=> __('30', 'e_store'),
	'40' 		=> __('40', 'e_store'),
	'50' 		=> __('50', 'e_store'),
	'-1' 		=> __('All', 'e_store'),
	));
	foreach ( $shopCatalog_orderby as $sort_id => $sort_name )
	echo '<option value="' . $sort_id . '" ' . selected( $numberOfProductsPerPage, $sort_id, true ) . ' >' . $sort_name . '</option>';
	?>
	</select>
	</form>
	</div>
	<?php
	}

	// now we set our cookie if we need to
function dl_sort_by_page($count) {
	if (isset($_COOKIE['shop_pageResults'])) { // if normal page load with cookie
	$count = $_COOKIE['shop_pageResults'];
	}
	if (isset($_POST['woocommerce-sort-by-columns'])) { //if form submitted
	setcookie('shop_pageResults', $_POST['woocommerce-sort-by-columns'], time()+1209600, '/', 'www.your-domain-goes-here.com', false); //this will fail if any part of page has been output- hope this works!
	$count = $_POST['woocommerce-sort-by-columns'];
	}
	// else normal page load and no cookie
	return $count;
	}
	add_filter('loop_shop_per_page','dl_sort_by_page');

/****
 * End WooCommerce shop page show per page drop down
 * */


 // WooCommerce custom catalog ordering 
function e_store_custom_woocommerce_catalog_orderby( $sortby ) {
	$sortby['menu_order'] = 'Position';
	$sortby['price'] = 'Price:Lowest first';
	$sortby['price-desc'] = 'Price:HIghest first';
	unset($sortby['popularity']);
	unset($sortby['date']);
	unset($sortby['rating']);
	
	return $sortby;
}
add_filter( 'woocommerce_catalog_orderby', 'e_store_custom_woocommerce_catalog_orderby' );


// Remove list/grid view plugin default option

function e_store_listgrid_plugin_option(){
	global $WC_List_Grid;
	remove_action( 'woocommerce_before_shop_loop', array( $WC_List_Grid, 'gridlist_toggle_button' ), 30); 
 }
 add_action('woocommerce_archive_description','e_store_listgrid_plugin_option');


 /****
  * Single product page
  */
  remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price' ,10 );
  add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price' ,25 );


  /**
   *  Customized checkout fields
   * ** */

// Our hooked in function - $fields is passed via the filter!
function e_store_custom_override_checkout_fields( $fields ) {
     $fields['billing']['billing_first_name']['input_class'] = array('form-control unicase-form-control text-input');
     $fields['billing']['billing_last_name']['input_class'] = array('form-control unicase-form-control text-input');
     $fields['billing']['billing_company']['input_class'] = array('form-control unicase-form-control text-input');
     $fields['billing']['billing_address_1']['input_class'] = array('form-control unicase-form-control text-input');
     $fields['billing']['billing_address_2']['input_class'] = array('form-control unicase-form-control text-input');
     $fields['billing']['billing_city']['input_class'] = array('form-control unicase-form-control text-input');
     $fields['billing']['billing_postcode']['input_class'] = array('form-control unicase-form-control text-input');
     $fields['billing']['billing_phone']['input_class'] = array('form-control unicase-form-control text-input');
     $fields['billing']['billing_email']['input_class'] = array('form-control unicase-form-control text-input');
	
	 $fields['shipping']['shipping_first_name']['input_class'] = array('form-control unicase-form-control text-input');
     $fields['shipping']['shipping_last_name']['input_class'] = array('form-control unicase-form-control text-input');
     $fields['shipping']['shipping_company']['input_class'] = array('form-control unicase-form-control text-input');
     $fields['shipping']['shipping_address_1']['input_class'] = array('form-control unicase-form-control text-input');
     $fields['shipping']['shipping_address_2']['input_class'] = array('form-control unicase-form-control text-input');
     $fields['shipping']['shipping_city']['input_class'] = array('form-control unicase-form-control text-input');
     $fields['shipping']['shipping_postcode']['input_class'] = array('form-control unicase-form-control text-input');

	
	 return $fields;
}
add_filter( 'woocommerce_checkout_fields' , 'e_store_custom_override_checkout_fields' );



