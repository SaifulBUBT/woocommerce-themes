<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package e_store
 */

?>
<?php  global $themesbazar; ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<?php wp_head(); ?>	

	<?php
	/**
	 * Dynamic CSS
	 */
		require_once get_theme_file_path('/assets/css/dynamic-css.php');
	?>
	
</head>
<body <?php body_class(); ?>>

<!--============ Top Header Section =============-->

<section class="top_header_sec">
	<div class="container">
		<div class="row">
			<div class="col-md-3 col-sm-4">
				<div class="top_header_text">
					<?php
						$contact_no = $themesbazar['e_store_phone_no'];
						if(! empty($contact_no)){
					?>
					<i class="fa fa-tty"></i>  <?php esc_html_e( 'Hot Line :-', 'e_store' ); ?> <?php echo $contact_no; ?>
						<?php } else{ ?>
					<i class="fa fa-tty"></i> <?php esc_html_e( 'Hot Line :- 01910333888', 'e_store' ); ?>
						<?php } ?>
						
				</div>
			</div>
			<div class="col-md-9 col-sm-8">
				<?php 
					wp_nav_menu( array(
						'theme_location' => 'top-menu',
	
						'container' => 'div',
						'container_class' => 'top_header_menu'
					));
				?>
				<!-- 				
				<div class="top_header_menu">
					<ul>
						<li> <a href="#">জাতীয়</a></li>
						<li> <a href="#">জাতীয়</a></li>
						<li> <a href="#">জাতীয়</a></li>
						<li> <a href="#">জাতীয়</a></li>
					</ul>
				</div> -->

			</div>
		</div>  
	</div>
</section>

<!--============  Header Section =============-->

<section class="header_sec">
	<div class="container">
		<div class="row">
			<div class="col-md-3 col-sm-3">
				<div class="header_logo">

					<?php
						$e_store_logo_url =  $themesbazar['e_store_logo_upload']['url'];
					 	if( ! empty($e_store_logo_url)) {
					  ?>
					<a href="<?php echo home_url( '/' ) ?>"><img src="<?php echo $e_store_logo_url; ?>"/></a>
					<?php } else{ ?>
					<a href="<?php echo home_url( '/' ) ?>"><img src="<?php  echo get_template_directory_uri();?>/assets/images/logo.gif"/></a>	
					<?php } ?>
				</div>
			</div>
			<div class="col-md-7 col-sm-6">
				<div class="search-box">

					<form class="example" method="get" action="<?php echo home_url( '/' ); ?>">
						<input type="text"  maxlength="64" placeholder="<?php echo $themesbazar['e_store_search_placeholder'] ;?>" value="<?php the_search_query(); ?>" name="s" />
						<button type="submit"><?php echo $themesbazar['e_store_search']?></button>
                    </form>

				</div>
			</div>
			<div class="col-md-2 col-sm-3">


			</div>
		</div>  
	</div>
</section>

<!--============  Menu Section =============-->

<section class="menu_section">
	<div class="container">
		<div id="menu-area" class="menu_area">
			<div class="menu_bottom">
				<div class="row">
					<div class="col-md-12 col-sm-12">
						<nav role="navigation" class="navbar navbar-default mainmenu">
					<!-- Brand and toggle get grouped for better mobile display -->
							<div class="navbar-header">
								<button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle">
									<span class="sr-only">Toggle navigation</span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
								</button>
							</div>
							<!-- Collection of nav links and other content for toggling -->

								<?php 
									wp_nav_menu( array(
										'theme_location' => 'main-menu',
										'container'		=> 'div',
										'container_class' => 'collapse navbar-collapse',
										'container_id'    => 'navbarCollapse',
										'menu_class'      => 'nav navbar-nav',
										'depth'           => 2,
										'fallback_cb' => 'default_main_menu',
										'walker'          => new WP_Bootstrap_Navwalker()
									));
								?>
							<!-- <div id="navbarCollapse" class="collapse navbar-collapse">
						
								<ul class="nav navbar-nav">
									<li><a href="#">Home</a></li>
										<li class="dropdown">
											<a href="#" class="dropdown-toggle" data-toggle="dropdown">Home <b class="caret"></b></a>
										<ul class="dropdown-menu">
											<li><a href="#">Home</a></li>
											<li><a href="#">Home</a></li>
										</ul>
										</li>
									<li><a href="#">Home</a></li>
									<li class="dropdown">
										<a href="#" class="dropdown-toggle" data-toggle="dropdown">Home<b class="caret"></b></a>
										<ul class="dropdown-menu">
											<li><a href="#">Home</a></li>
										</ul>
									</li>
									<li><a href="#">Home</a></li>
									<li><a href="#">Home</a></li>
								
									
									<li><a href="#" target="_blank">Home</a></li>
									<li><a href="#" target="_blank">Home</a></li>
									<li class="dropdown">
										<a href="#" class="dropdown-toggle" data-toggle="dropdown">Home<b class="caret"></b></a>
										<ul class="dropdown-menu">
											<li><a href="#">Home</a></li>
											<li><a href="#">Home</a></li>
											
											<li class="divider"></li>
											<li><a href="#" rel="nofollow">Home</a></li>
											<li><a href="#">Home</a></li>                           
										</ul>
									</li>
								</ul> 
							</div>-->
						</nav>
					</div> 
				</div> 
							
			</div><!-- /.header_bottom -->

		</div>
	</div>
</section>