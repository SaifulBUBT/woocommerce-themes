<?php 
function cptui_register_my_cpts() {

	/**
	 * Post Type: Banner Slider.
	 */

	$labels = [
		"name" => __( "Banner Slider", "e_store" ),
		"singular_name" => __( "Banner Slide", "e_store" ),
		"all_items" => __( "All Slides", "e_store" ),
		"add_new_item" => __( "Add New Slide", "e_store" ),
		"edit_item" => __( "Edit Slide", "e_store" ),
		"new_item" => __( "New Slide", "e_store" ),
		"view_item" => __( "View Slide", "e_store" ),
		"view_items" => __( "View Slides", "e_store" ),
		"search_items" => __( "Search Slide", "e_store" ),
		"not_found" => __( "No Slide Found", "e_store" ),
		"set_featured_image" => __( "Set Slide Image", "e_store" ),
		"remove_featured_image" => __( "Remove Slide Image", "e_store" ),
	];

	$args = [
		"label" => __( "Banner Slider", "e_store" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"delete_with_user" => false,
		"show_in_rest" => false,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => true,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"delete_with_user" => false,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => [ "slug" => "banner_slide", "with_front" => true ],
		"query_var" => true,
		"menu_icon" => "dashicons-screenoptions",
		"supports" => [ "title", "editor", "thumbnail" ],
		"taxonomies" => [ "category" ],
	];

	register_post_type( "banner_slide", $args );

	/**
	 * Post Type: Turorials.
	 */

	$labels = [
		"name" => __( "Turorials", "e_store" ),
		"singular_name" => __( "Turorial", "e_store" ),
		"add_new" => __( "Add New Tutorial", "e_store" ),
		"add_new_item" => __( "Add New Tutorial", "e_store" ),
		"edit_item" => __( "Edit Tutorial", "e_store" ),
		"new_item" => __( "New Tutorial", "e_store" ),
		"view_item" => __( "View Tutorial", "e_store" ),
		"view_items" => __( "View Tutorials", "e_store" ),
		"search_items" => __( "Search Tutorials", "e_store" ),
		"not_found" => __( "No Tutorials Found", "e_store" ),
		"archives" => __( "Tutorial Archives", "e_store" ),
	];

	$args = [
		"label" => __( "Turorials", "e_store" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"delete_with_user" => false,
		"show_in_rest" => false,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => true,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"delete_with_user" => false,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => [ "slug" => "tutorials", "with_front" => true ],
		"query_var" => true,
		"menu_icon" => "dashicons-playlist-video",
		"supports" => [ "title" ],
		"taxonomies" => [ "category" ],
	];

	register_post_type( "tutorials", $args );
}

add_action( 'init', 'cptui_register_my_cpts' );
