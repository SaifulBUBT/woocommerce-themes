		<?php global $themesbazar; ?>		


		
		<!---------bottom footer  option--------->

				<div class="row">
					<div class="root">
						<div class="col-md-6 col-sm-6 root_01">
							 <?php echo $themesbazar['copyright']?>
						</div>
						<div class="col-md-6 col-sm-6 root_02">
							<?php root(); ?>
						</div>
					</div>	
				</div>
		
		
				<!--------------- go to top start----------------->

                <div class="scrollToTop"><i class="fa fa-arrow-circle-up"></i></div>

            	<!--------------- go to top close----------------->

		</section>
				