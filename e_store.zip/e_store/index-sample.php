<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package e_store
 */

get_header();
?>

<div class="body-content outer-top-xs">
	<div class="container">
		<div class="row">
			<div class="blog-page">
				<div class="col-md-9">

					<?php
					while ( have_posts() ) :
						the_post(); ?>

                        <div class="blog-post  wow fadeInUp">
							<?php e_store_post_thumbnail(); ?>			
							<h1><a href="<?php the_permalink( ); ?>"><?php the_title() ?></a></h1>
							<span class="author"><?php the_author(); ?></span>
							<span class="review"><?php
  comments_popup_link( 'No comments yet', '1 comment', '% comments', 'comments-link', 'Comments are off for this post');
?></span>
							<span class="date-time"><?php the_time('F j, Y') ?></span>
								<?php the_excerpt(  ); ?>
                                <a href="<?php the_permalink( ); ?>" class="btn btn-upper btn-primary read-more"><?php esc_html_e( 'read more', 'e_store' ); ?></a>

                        </div>
                        
				    <?php
                        endwhile; // End of the loop.
                        wp_reset_postdata( );
					?>

				</div>
				<div class="col-md-3 sidebar">
					<?php get_sidebar(); ?>
				</div>
			</div>
		</div>
	</div>
</div>

<?php
get_footer();
