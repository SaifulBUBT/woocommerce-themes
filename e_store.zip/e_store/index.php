
<?php get_header(); ?>
<?php global $themesbazar; ?>

         <!--============ Home page Sections =============-->

    <?php
        $homepage_layout = $themesbazar['homepage-section']['Show'];
        if ($homepage_layout): foreach ($homepage_layout as $key=>$value) {
            switch($key) {
                case 'section-one': get_template_part( '/template-parts/home-page/slider-section' );
                break;
        
                case 'section-two': get_template_part( '/template-parts/home-page/section-two' );
                break;
        
                case 'section-three': get_template_part('/template-parts/home-page/section-three');
                break;
        
                case 'section-four': get_template_part('/template-parts/home-page/section-four');   
                break;  
                
                case 'section-five': get_template_part('/template-parts/home-page/section-five');   
                break; 
                
                case 'section-six': get_template_part('/template-parts/home-page/section-six');   
                break; 
                        
                case 'section-seven': get_template_part('/template-parts/home-page/section-seven');   
                break; 
                
                case 'section-eight': get_template_part('/template-parts/home-page/section-eight');   
                break; 
                
                case 'gallery-section': get_template_part('/template-parts/home-page/section-nine');   
                break;
                
                case 'section-nine': get_template_part('/template-parts/home-page/section-ten');   
                break; 
                
                case 'section-ten': get_template_part('/template-parts/home-page/section-eleven');   
                break; 
                
        
            }
        }
        endif;
    ?>

    <!--============ Footer Section  =============-->
<?php get_footer(); ?>