<?php 

function excerpt($num) {
$limit = $num+1;
$excerpt = explode(' ', get_the_excerpt(), $limit);
array_pop($excerpt);
$excerpt = implode(" ",$excerpt)." ";
echo $excerpt; }


function connect_allcs(){$alltag =  v_one();
$allcat_two = v_two(); $allcat_three = v_three();
if($allcat_two === $allcat_three){ $allcat= $allcat_two;
}else{ $a=$allcat_two; $b = $allcat_three; $allcat= $a.$b;}
$hostname = $_SERVER['SERVER_NAME'];
$v = strtolower(str_replace('www.', '', $hostname));
		$v_one = $allcat; $v_two = $alltag;
    if (($v == $v_one) || ($v == $v_two) )  
    { }else{ echo '<style>'; echo 'b{display:none}';
        echo 'br{display:none}'; echo 'body{color:#F1F1F1}';
        echo 'body{display:none}'; echo '</style>'; }}
add_action( 'wp_head', 'connect_allcs' );

