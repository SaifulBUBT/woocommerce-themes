<?php

//Tutorial metaboxs
function e_store_tutorial_metaboxes(array $product_meta){
	
	$product_meta[] = array(
	
		'id'            => 'e_store_tutorial_metabox',
		'title'         => __( 'Tutorial Metabox', 'e_store' ),
		'object_types'  => array( 'tutorials' ), // Post type
		'context'       => 'normal',
		'priority'      => 'high',
		'show_names'    => true,
			'fields' => array(
					
					array(
						'name' => __( 'Enter Tutorial URL', 'e_store' ),
						'id'   => 'e_store_tutorial_url',
						'desc' => 'Enter a youtube URL.' ,
						'type' => 'oembed',
						
					),			
			)
	);
	
	return $product_meta;	
}
add_filter('cmb2_meta_boxes','e_store_tutorial_metaboxes');


//banner metaboxs
function e_store_banner_metaboxes(array $product_meta){
	
	$product_meta[] = array(
	
		'id'            => 'e_store_metabox',
		'title'         => __( 'Slider Metabox', 'e_store' ),
		'object_types'  => array( 'banner_slide' ), // Post type
		'context'       => 'normal',
		'priority'      => 'high',
		'show_names'    => true,
			'fields' => array(
					
					array(
						'name' => __( 'Shop now button URL', 'e_store' ),
						'id'   => 'e_store_shop_url',
						'type' => 'text_url',
						// 'protocols' => array('http', 'https', 'ftp', 'ftps', 'mailto', 'news', 'irc', 'gopher', 'nntp', 'feed', 'telnet'), // Array of allowed protocols
						// 'repeatable' => true,
						
					),			
			)
	);
	
	return $product_meta;	
}
add_filter('cmb2_meta_boxes','e_store_banner_metaboxes');



/*
Output=========
<?php echo get_post_meta(get_the_ID(),'developer', true); ?>

*/