


<?php 


	
if(is_shop() || is_product() || is_product_category()){
	$e_store_sidebar = 'shop-sidebar';
	?>
	<!--  TOP NAVIGATION  -->
	<div class="side-menu animate-dropdown outer-bottom-xs">
		<div class="head"><i class="icon fa fa-align-justify fa-fw"></i> <?php esc_html_e( 'Categories', 'e_store' ); ?></div>
		<nav class="yamm megamenu-horizontal" role="navigation">
		<?php /* Primary navigation */
		wp_nav_menu( array(
			'theme_location' => 'side-bar-menu',
			'menu_class'    => 'nav navbar-nav',
			'fallback_cb' => 'default_main_menu',
			'walker' => new wp_bootstrap_navwalker())
				);
			?>
		</nav>
	</div>

	<?php
} else{
	$e_store_sidebar = 'sidebar-1';

}

if ( ! is_active_sidebar( $e_store_sidebar ) ) {
	return;
}
?>

<aside id="secondary" class="widget-area">
	<?php dynamic_sidebar( $e_store_sidebar ); ?>
</aside><!-- #secondary -->


			
			
			
	