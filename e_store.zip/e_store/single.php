<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package e_store
 */

get_header();
?>
<div class="breadcrumb">
	<div class="container">
		<div class="breadcrumb-inner">
			<!-- <ul class="list-inline list-unstyled">
				<li><a href="#">Home</a></li>
				<li class='active'>Blog Details</li>
			</ul> -->
			<?php get_e_store_breadcrumb(); ?>
		</div><!-- /.breadcrumb-inner -->
	</div><!-- /.container -->
</div><!-- /.breadcrumb -->



<div class="body-content">
	<div class="container">
		<div class="row">
			<div class="blog-page">
				<div class="col-md-9">

					<?php
					while ( have_posts() ) :
						the_post(); ?>

						<div class="blog-post wow fadeInUp">
							<?php e_store_post_thumbnail(); ?>			
							<h1><?php the_title() ?></h1>
							<span class="author"><?php the_author(); ?></span>
							<span class="review"><?php
  comments_popup_link( 'No comments yet', '1 comment', '% comments', 'comments-link', 'Comments are off for this post');
?></span>
							<span class="date-time"><?php the_time('F j, Y') ?></span>
								<?php the_content(); ?>
							<div class="social-media">
								<span><?php esc_html_e( 'share post:', 'e_store' ); ?></span>
								<a href="#"><i class="fa fa-facebook"></i></a>
								<a href="#"><i class="fa fa-twitter"></i></a>
								<a href="#"><i class="fa fa-linkedin"></i></a>
								<a href="#"><i class="fa fa-rss"></i></a>
								<a href="#" class="hidden-xs"><i class="fa fa-pinterest"></i></a>
							</div>
						</div>

						<?php	the_post_navigation();

						// If comments are open or we have at least one comment, load up the comment template.
						if ( comments_open() || get_comments_number() ) :
							comments_template();
						endif;

					endwhile; // End of the loop.
					wp_reset_postdata( );
					?>

				</div>
				<div class="col-md-3 sidebar">
					<?php get_sidebar(); ?>
				</div>
			</div>
		</div>
	</div>
</div>

<?php
get_footer();
