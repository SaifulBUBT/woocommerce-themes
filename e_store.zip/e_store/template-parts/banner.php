 <div class="homepage_slides">

<?php 
    $slidelist = new WP_Query(array(
        'post_type' => 'banner_slide',
        'post_per_page' => -1
    ));
?>

<?php while($slidelist->have_posts()): $slidelist->the_post(); ?>

    <div class="single_homepage_slides">
        <div class="row">
            <div class="col-md-12">
               <div class="home_silde_image">
               </div>
               <?php the_post_thumbnail(); ?>
               <div class="centered">
                    <h4><?php the_title(); ?></h4>
                    <div class="home_btn">
                        <?php $shop_url = get_post_meta(get_the_ID(),'e_store_shop_url', true);
                            
                        ?>
                        <a href="<?php echo (esc_url($shop_url)); ?>"> Shop Now</a>
                    </div>
                </div> 
        

            </div>
        </div>
        
    </div>

    <?php
        endwhile;
        wp_reset_postdata( );
    ?>



</div>