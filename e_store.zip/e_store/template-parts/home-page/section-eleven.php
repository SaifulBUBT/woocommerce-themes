<!--============ Section Eleven =============-->

<section class="section_eleven wow fadeInUp" data-wow-delay="300ms">
    <div class="container background">

        <div class="row">
            <div class="col-md-12">
            
                
                <div class="video_cat_title">
                  <h3 class="section-title">Tutorials</h3>  

                </div>

                <div class="Video_section">
                    
       
                <?php 
                    $tutorial_list = new WP_Query(array(
                        'post_type' => 'tutorials',
                        'post_per_page' => -1
                    ));
                ?>
                 <?php while($tutorial_list->have_posts()): $tutorial_list->the_post(); ?>

                    <div class="Video_item">

                        <?php $url =  esc_url(get_post_meta( get_the_ID(), 'e_store_tutorial_url', 1 ));
                           // echo $url;
                        ?>
                          <?php  echo wp_oembed_get( $url );  ?>                     
                        <h4 class="Video_title">
                            <?php the_title(); ?>
                        </h4>

                    </div>
                    <?php
                        endwhile;
                        wp_reset_postdata( );
                    ?>


    
           
                    
                    

                
                </div>
            </div>
            
        </div>

    </div>
</section>
