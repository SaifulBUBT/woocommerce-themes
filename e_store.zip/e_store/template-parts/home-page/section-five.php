<!--============ Section Five =============-->
<?php  global $themesbazar; ?>

<section class="section_five wow fadeInUp" data-wow-delay="300ms">
    <div class="container background">
        <div class="row">
            <div class="col-md-4 col-sm-4">
                <?php
                    $id = (!empty($themesbazar['product_slider_and_display_one'])) ? $themesbazar['product_slider_and_display_one'] : 'empty';
        
                    if($id != 'empty'):
                ?>
                    <div class="special_product_cat_title">
                        <?php
                            if( $term = get_term_by( 'id', $id, 'product_cat' ) ){
                            $pcategory_name = $term->name;}
                            $pcategory_name_link = get_category_link($id);
                            $no_of_products= $themesbazar['no_of_product_slider_and_display_one'];
                        ?>

                        <h3 class="section-title"> <a href="<?php echo esc_url($pcategory_name_link); ?>"><?php echo $pcategory_name;?></a></h3>  
                    </div>
                    <div class="special_product_sec">
                    
                        <?php
                            $args = array( 'post_type' => 'product', 'posts_per_page' => $no_of_products, 'product_cat' => $pcategory_name, 'orderby' => 'DESC' );
                            $loop = new WP_Query( $args );
                            while ( $loop->have_posts() ) : $loop->the_post(); global $product; 
                        ?>

                        <div class="special_item">
                            <div class="special_item_image">
                            <?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?>
                            </div>
                            <h4 class="special_item_title"> <a href="<?php the_permalink( ); ?>"> <?php the_title(); ?> </a></h4>
                            
                                <h4 class="carasule_product_price"> <?php echo $product->get_price_html(); ?> </h4>
                            
                        </div>

                        <?php endwhile; wp_reset_query(); ?>

                    </div>
                <?php 
                else:
                    echo '<h4 class="product-slider-one">Please select a product category from Theme-options => Home Page Settings =>  Product Display Section One for displaying product slider</h4>';
                endif; 
                ?>

            </div>

            <div class="col-md-8 col-sm-8">
                <?php
                    $id = (!empty($themesbazar['product_display_one'])) ? $themesbazar['product_display_one'] : 'empty';
        
                    if($id != 'empty'):
                ?>
                    <div class="new_product_cat">
                    <?php
                            if( $term = get_term_by( 'id', $id, 'product_cat' ) ){
                            $pcategory_name = $term->name;}
                            $pcategory_name_link = get_category_link($id);
                            $no_of_products= $themesbazar['no_of_product_display_one'];
                            $no_of_columns = $themesbazar['no_of_column_display_one'];
                        ?>

                        <h3 class="section-title"> <a href="<?php echo esc_url($pcategory_name_link); ?>"><?php echo $pcategory_name;?></a></h3>  
                    
                    </div>

                    <div class="new_product_sec">
                        <div class="row">
        
                            <?php
                                $args = array( 'post_type' => 'product', 'posts_per_page' => '4', 'product_cat' => $pcategory_name, 'orderby' => 'DESC' );
                                $loop = new WP_Query( $args );
                                while ( $loop->have_posts() ) : $loop->the_post(); global $product; 
                            ?>
                            <div class="col-md-<?php echo $no_of_columns; ?> col-sm-4 col-xs-6">
                                <div class="new_product">
                                    <div class="new_product_image">
                                        <?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?>
                                    </div>
                                    <h4 class="new_product_title"> <a href="<?php the_permalink(); ?>"> <?php the_title(); ?> </a></h4>
                                
                                        <h4 class="new_product_price"> <?php echo $product->get_price_html(); ?> </h4>
                                
                                    </div>
                                </div>
                        
                            <?php endwhile; wp_reset_query(); ?>
                            </div>
                    </div>

                    
                    <div class="new_product_sec">
                        <div class="row">
        
                            <?php
                                $args = array( 'post_type' => 'product', 'posts_per_page' => '4', 'product_cat' => $pcategory_name, 'orderby' => 'menu_order' , 'order' => 'ASC' );
                                $loop = new WP_Query( $args );
                                while ( $loop->have_posts() ) : $loop->the_post(); global $product; 
                            ?>
                            <div class="col-md-<?php echo $no_of_columns; ?> col-sm-4 col-xs-6">
                                <div class="new_product">
                                    <div class="new_product_image">
                                        <?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?>
                                    </div>
                                    <h4 class="new_product_title"> <a href="<?php the_permalink(); ?>"> <?php the_title(); ?> </a></h4>
                                
                                        <h4 class="new_product_price"> <?php echo $product->get_price_html(); ?> </h4>
                                
                                    </div>
                                </div>
                        
                            <?php endwhile; wp_reset_query(); ?>
                            </div>
                    </div>
                <?php 
                else:
                    echo '<h4 class="product-slider-one">Please select a product category from Theme-options => Home Page Settings =>  Product Display Section One for displaying product slider</h4>';
                endif; 
                ?>

            </div>
        </div>
    </div>
    
</section>