<!--============ Section Four =============-->
<?php  global $themesbazar; ?>
<section class="section_four wow fadeInUp" data-wow-delay="300ms">
    <div class="container">
        
        <div class="row">
            <div class="col-md-12">
                <div class="custom-tab manu-tavn">

                    <?php
                        $product_ids = (!empty($themesbazar['product_display_tab_one'])) ? $themesbazar['product_display_tab_one'] : 'empty';      
                        if($product_ids != 'empty'):
                    ?>
                        <ul class="tab_list">
                            <!-- <li class="active"><a data-toggle="tab" href="#custom-tab-1">all</a></li>
                            <li><a data-toggle="tab" href="#custom-tab-2">Breakfast</a></li>
                            <li><a data-toggle="tab" href="#custom-tab-3" href="">Lunch</a></li>
                            <li><a data-toggle="tab" href="#custom-tab-4" href="">Dinner</a></li> -->

                            <?php 
                            // $product_ids = $themesbazar['product_display_tab_one'];

                                $count = 0;
                                foreach($product_ids as $product_id)
                                {
                                    $term = get_term_by( 'id', $product_id, 'product_cat' );
                                    $pcategory_name = $term->name;
                                    $pcategory_slug = $term->slug;
                                    //  $pcategory_name_link = get_category_link($product_id);

                                    $active = '';
                                    if($count == 0){
                                        $active = 'active';
                                    }

                                    echo '<li class="'.$active.'"><a data-toggle="tab" href="#'.$pcategory_slug.'">'.$pcategory_name.'</a></li>';
                            
                                    $count++;
                                }
                            ?>
                        </ul>  

                        <div class="tab-content">

                            <?php 
                                $counter = 0;
                                foreach($product_ids as $product_id){
                                    $term = get_term_by( 'id', $product_id, 'product_cat' );
                                    $pcategory_name = $term->name;
                                    $pcategory_slug = $term->slug;
                                    // $pcategory_name_link = get_category_link($product_id);
                                    $no_of_tab_products= $themesbazar['no_of_tab_product_one'];

                                $active = '';
                                if($counter == 0){
                                    $active = 'in active';
                                }

                            ?>
                            <div id="<?php echo $pcategory_slug; ?>" class="tab-pane fade <?php echo $active; ?>">

                                <div class="row">
                                    <?php
                                        $args = array( 'post_type' => 'product', 'posts_per_page' => $no_of_tab_products, 'product_cat' => $pcategory_name, 'orderby' => 'DESC' );
                                        $loop = new WP_Query( $args );
                                        while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>

                                        <div class="col-md-3 col-sm-4">
                                            <div class="tab_product">
                                            <?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?>
                                                <h4 class="tab_product_title"> <a href="<?php the_permalink( ); ?>"><?php the_title(); ?> </a></h4>
                                                <h4 class="tab_product_price"> <?php echo $product->get_price_html(); ?> </h4>
                                            </div>
                                        </div>
                                    <?php endwhile; wp_reset_query(); ?>

                                </div>
                            </div>

                            <?php $counter++; } ?>
                        </div>

                    <?php
                    else:
                        echo '<h4 class="product-slider-one">Please select a product category from Theme-options => Home Page Settings =>  Product Tab Section One for displaying Product Tab Section</h4>';
                    endif; 
                    ?>


                </div>
            </div>
        </div>
    </div>
</section>
