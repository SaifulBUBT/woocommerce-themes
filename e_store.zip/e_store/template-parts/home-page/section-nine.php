<!--============ Section Nine =============-->

<section class="section_nine wow fadeInUp" data-wow-delay="300ms">
    <div class="container background">
        
        <div class="row">
            <div class="col-md-12 col-sm-12">

                <div class="carasule_product_cat">
                    catagory 02
                    <span><a href="#">সবখবর <i class="fa fa-angle-double-right"></i></a></span>
                </div>

                <div class="carasule_product">
                    
                    <div class="carasule_product_item">
                        <img src="<?php  echo get_template_directory_uri();?>/assets/images/1.png" alt="image">
                        <h4 class="carasule_product_title"> <a href="">Car Electronics & Accessories </a></h4>
                        <h4 class="carasule_product_price"> $1000 </h4>
                    </div>

                    <div class="carasule_product_item">
                        <img src="<?php  echo get_template_directory_uri();?>/assets/images/1.png" alt="image">
                        <h4 class="carasule_product_title"> <a href="">Car Electronics & Accessories </a></h4>
                        <h4 class="carasule_product_price"> $1000 </h4>
                    </div>

                    <div class="carasule_product_item">
                        <img src="<?php  echo get_template_directory_uri();?>/assets/images/1.png" alt="image">
                        <h4 class="carasule_product_title"> <a href="">Car Electronics & Accessories </a></h4>
                        <h4 class="carasule_product_price"> $1000 </h4>
                    </div>

                    <div class="carasule_product_item">
                        <img src="<?php  echo get_template_directory_uri();?>/assets/images/1.png" alt="image">
                        <h4 class="carasule_product_title"> <a href="">Car Electronics & Accessories </a></h4>
                        <h4 class="carasule_product_price"> $1000 </h4>
                    </div>

                    <div class="carasule_product_item">
                        <img src="<?php  echo get_template_directory_uri();?>/assets/images/1.png" alt="image">
                        <h4 class="carasule_product_title"> <a href="">Car Electronics & Accessories </a></h4>
                        <h4 class="carasule_product_price"> $1000 </h4>
                    </div>

                    <div class="carasule_product_item">
                        <img src="<?php  echo get_template_directory_uri();?>/assets/images/1.png" alt="image">
                        <h4 class="carasule_product_title"> <a href="">Car Electronics & Accessories </a></h4>
                        <h4 class="carasule_product_price"> $1000 </h4>
                    </div>

                </div>
            </div>   
        </div>

    </div>
</section>