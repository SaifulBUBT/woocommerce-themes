<!--============ Section Ten =============-->

<section class="section_ten wow fadeInUp" data-wow-delay="300ms">
    <div class="container background">

        <div class="row">
            <div class="col-md-12">
            
                
                <div class="news_cat_title">
                    <h3 class="section-title">Latest Posts</h3>  
                </div>

                <div class="Latest_news_section">

                <?php 
                    $latest_post = new WP_Query(array(
                        'post_type' => 'post',
                        'post_per_page' => -1
                    ));
                ?>
                    
                    <?php while ($latest_post->have_posts( )): $latest_post->the_post( ); ?>
                        <div class="Latest_New_item">
                            <div class="Latest_news_image">
                                <?php the_post_thumbnail( ); ?>
                            </div>
                            <h4 class="news_upload_time"> <?php the_time('F j, Y') ?></h4>
                            <h4 class="news_title"><a href="<?php the_permalink( ); ?>"><?php the_title(); ?></a></h4>
                            <div class="news_content">
                                <?php the_excerpt( ); ?>
                            </div>
                            <div class="redmore_btn">
                                <a href="<?php the_permalink( ); ?>">Continue reading</a>
                            </div>
                        </div>
                    
                    <?php endwhile; wp_reset_query( ); ?>
                
                </div>
            </div>
            
        </div>

    </div>
</section>
