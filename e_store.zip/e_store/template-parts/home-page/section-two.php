<!--============ Section Two =============-->
<?php  global $themesbazar; ?>
<section class="section_two wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s">
    <div class="container background">

        <div class="row">
            <!------=======homepage category section one=====---->
            <div class="col-md-4 col-sm-4">
                <div class="homepage_product_menu">
                    <?php if($themesbazar['product_category_section1_image']['url']) :?>
                         <img src="<?php echo $themesbazar['product_category_section1_image']['url']; ?>" alt="image">
                       <?php else: ?>
                            <img src="<?php echo get_template_directory_uri(  ); ?>/assets/images/2.jpg" />
                     <?php endif; ?>        

                    <h4> <?php echo $themesbazar['category_section_one_title']; ?> </h4>

                    <ul>
                        <?php
                        $homepage_p_categories = (!empty($themesbazar['homepage_product_category_section1'])) ? $themesbazar['homepage_product_category_section1'] : 'empty';

                        if($homepage_p_categories != 'empty'){
                            foreach($homepage_p_categories as $home_product_cat){
                                $term = get_term_by( 'id', $home_product_cat, 'product_cat' );
                            
                            //print_r($term);
                                $home_pcat_name = $term->name;
                                $home_pcategory_name_link = get_category_link($home_product_cat);
    
                    
                            $args = array( 'post_type' => 'product', 'posts_per_page' => 1, 'orderby' => 'DESC' );
                            $loop = new WP_Query( $args );
                            while ( $loop->have_posts() ) : $loop->the_post(); global $product;
                            ?>
                            <li><a href="<?php echo $home_pcategory_name_link; ?>"><?php echo $home_pcat_name; ?></a></li>

                            <?php 
                            endwhile; 
                            wp_reset_query(); 
                             } 
                        } else{
                                echo '<p>Select categories from Theme Options => Category Display Section</p>';
                            }
                        ?>
                    </ul> 

                </div>
            </div>

            <div class="col-md-4 col-sm-4">
                 <div class="homepage_product_menu">
                     <?php if($themesbazar['product_category_section2_image']['url']) :?>
                         <img src="<?php echo $themesbazar['product_category_section2_image']['url']; ?>" alt="image">
                       <?php else: ?>
                            <img src="<?php echo get_template_directory_uri(  ); ?>/assets/images/2.jpg" />
                     <?php endif; ?>  

                    <h4> <?php echo $themesbazar['category_section_two_title']; ?> </h4>

                    <ul>
                        <?php
                        $homepage_p_categories = (!empty($themesbazar['homepage_product_category_section2'])) ? $themesbazar['homepage_product_category_section2'] : 'empty';

                        if($homepage_p_categories != 'empty'){

                            foreach($homepage_p_categories as $home_product_cat){
                                $term = get_term_by( 'id', $home_product_cat, 'product_cat' );
                            
                            //print_r($term);
                                $home_pcat_name = $term->name;
                                $home_pcategory_name_link = get_category_link($home_product_cat);
    
                    
                            $args = array( 'post_type' => 'product', 'posts_per_page' => 1, 'orderby' => 'DESC' );
                            $loop = new WP_Query( $args );
                            while ( $loop->have_posts() ) : $loop->the_post(); global $product;
                            ?>
                            <li><a href="<?php echo $home_pcategory_name_link; ?>"><?php echo $home_pcat_name; ?></a></li>

                         <?php 
                            endwhile; 
                            wp_reset_query(); 
                                } 
                        } else{
                            echo '<p>Select categories from Theme Options => Category Display Section</p>';
                        }
                        ?>
                    </ul> 

                </div>
            </div>

            <div class="col-md-4 col-sm-4">
              <div class="homepage_product_menu">
              
                    <?php if($themesbazar['product_category_section3_image']['url']) :?>
                         <img src="<?php echo $themesbazar['product_category_section3_image']['url']; ?>" alt="image">
                       <?php else: ?>
                            <img src="<?php echo get_template_directory_uri(  ); ?>/assets/images/2.jpg" />
                     <?php endif; ?>  

                    <h4> <?php echo $themesbazar['category_section_three_title']; ?> </h4>

                    <ul>
                     <?php
                        $homepage_p_categories = (!empty($themesbazar['homepage_product_category_section3'])) ? $themesbazar['homepage_product_category_section3'] : 'empty';

                        if($homepage_p_categories != 'empty'){

                            foreach($homepage_p_categories as $home_product_cat){
                                $term = get_term_by( 'id', $home_product_cat, 'product_cat' );
                            
                            //print_r($term);
                                $home_pcat_name = $term->name;
                                $home_pcategory_name_link = get_category_link($home_product_cat);
    
                    
                            $args = array( 'post_type' => 'product', 'posts_per_page' => 1, 'orderby' => 'DESC' );
                            $loop = new WP_Query( $args );
                            while ( $loop->have_posts() ) : $loop->the_post(); global $product;
                            ?>
                            <li><a href="<?php echo $home_pcategory_name_link; ?>"><?php echo $home_pcat_name; ?></a></li>

                        <?php 
                            endwhile; 
                            wp_reset_query(); 
                            } 

                        } else{
                            echo '<p>Select categories from Theme Options => Category Display Section</p>';
                        }
                        ?>
                    </ul> 

                </div>
            </div>

        </div>

        <div class="row">
            
            <div class="col-md-4 col-sm-4">
                <div class="homepage_product_menu">
                     <?php if($themesbazar['product_category_section4_image']['url']) :?>
                         <img src="<?php echo $themesbazar['product_category_section4_image']['url']; ?>" alt="image">
                       <?php else: ?>
                            <img src="<?php echo get_template_directory_uri(  ); ?>/assets/images/2.jpg" />
                     <?php endif; ?>  

                    <h4> <?php echo $themesbazar['category_section_four_title']; ?> </h4>

                    <ul>
                     <?php
                        $homepage_p_categories = (!empty($themesbazar['homepage_product_category_section4'])) ? $themesbazar['homepage_product_category_section4'] : 'empty';

                        if($homepage_p_categories != 'empty'){
                            foreach($homepage_p_categories as $home_product_cat){
                                $term = get_term_by( 'id', $home_product_cat, 'product_cat' );
                            
                            //print_r($term);
                                $home_pcat_name = $term->name;
                                $home_pcategory_name_link = get_category_link($home_product_cat);
    
                    
                            $args = array( 'post_type' => 'product', 'posts_per_page' => 1, 'orderby' => 'DESC' );
                            $loop = new WP_Query( $args );
                            while ( $loop->have_posts() ) : $loop->the_post(); global $product;
                            ?>
                            <li><a href="<?php echo $home_pcategory_name_link; ?>"><?php echo $home_pcat_name; ?></a></li>

                        <?php 
                            endwhile; 
                            wp_reset_query(); 
                                } 
                        } else{
                            echo '<p>Select categories from Theme Options => Category Display Section</p>';
                        }
                        ?>
                    </ul> 

                </div>
            </div>

            <div class="col-md-4 col-sm-4">
                 <div class="homepage_product_menu">
                     <?php if($themesbazar['product_category_section5_image']['url']) :?>
                         <img src="<?php echo $themesbazar['product_category_section5_image']['url']; ?>" alt="image">
                       <?php else: ?>
                            <img src="<?php echo get_template_directory_uri(  ); ?>/assets/images/2.jpg" />
                     <?php endif; ?>  

                    <h4> <?php echo $themesbazar['category_section_five_title']; ?> </h4>

                    <ul>
                        <?php
                        $homepage_p_categories = (!empty($themesbazar['homepage_product_category_section5'])) ? $themesbazar['homepage_product_category_section5'] : 'empty';

                        if($homepage_p_categories != 'empty'){

                            foreach($homepage_p_categories as $home_product_cat){
                                $term = get_term_by( 'id', $home_product_cat, 'product_cat' );
                            
                            //print_r($term);
                                $home_pcat_name = $term->name;
                                $home_pcategory_name_link = get_category_link($home_product_cat);
    
                    
                            $args = array( 'post_type' => 'product', 'posts_per_page' => 1, 'orderby' => 'DESC' );
                            $loop = new WP_Query( $args );
                            while ( $loop->have_posts() ) : $loop->the_post(); global $product;
                            ?>
                            <li><a href="<?php echo $home_pcategory_name_link; ?>"><?php echo $home_pcat_name; ?></a></li>

                        <?php 
                            endwhile; 
                            wp_reset_query(); 
                            } 
                        } else{
                            echo '<p>Select categories from Theme Options => Category Display Section</p>';
                        }
                        ?>
                    </ul> 

                </div>
            </div>
            <div class="col-md-4 col-sm-4">
                 <div class="homepage_product_menu">

                    <?php if($themesbazar['product_category_section6_image']['url']) :?>
                         <img src="<?php echo $themesbazar['product_category_section6_image']['url']; ?>" alt="image">
                       <?php else: ?>
                            <img src="<?php echo get_template_directory_uri(  ); ?>/assets/images/2.jpg" />
                     <?php endif; ?>  

                    <h4> <?php echo $themesbazar['category_section_six_title']; ?> </h4>

                    <ul>
                     <?php
                        $homepage_p_categories = (!empty($themesbazar['homepage_product_category_section6'])) ? $themesbazar['homepage_product_category_section6'] : 'empty';

                        if($homepage_p_categories != 'empty'){

                            //print_r($homepage_p_categories);
                            // $cat_array_size =  sizeof($homepage_p_categories);
                            // echo $cat_array_size;

                            // if(isset($homepage_p_categories) ){
                            //     echo 'array is not empty';
                            // } else{
                            //     echo 'array is empty';
                            // }

                            // if(is_array($homepage_p_categories)){
                            //     echo 'yes';
                            // } else{
                            //     echo 'no';
                            // }

                            foreach($homepage_p_categories as $home_product_cat){
                                $term = get_term_by( 'id', $home_product_cat, 'product_cat' );
                            
                            //print_r($term);
                                $home_pcat_name = $term->name;
                                $home_pcategory_name_link = get_category_link($home_product_cat);
    
                    
                            $args = array( 'post_type' => 'product', 'posts_per_page' => 1, 'orderby' => 'DESC' );
                            $loop = new WP_Query( $args );
                            while ( $loop->have_posts() ) : $loop->the_post(); global $product;
                            ?>
                            <li><a href="<?php echo $home_pcategory_name_link; ?>"><?php echo $home_pcat_name; ?></a></li>

                        <?php 
                            endwhile; 
                            wp_reset_query(); 
                            } 
                        } else{
                            echo '<p>Select categories from Theme Options => Category Display Section</p>';
                        }
                        
                        ?>
                    </ul> 

                </div>
            </div>

        </div>

    </div>
</section>