
<?php  global $themesbazar; ?>
<section class="slider_section wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s">
    <div class="container background">
        <div class="row">

            <div class="col-md-9 col-sm-8">
                 <?php 
                    $slidelist = new WP_Query(array(
                        'post_type' => 'banner_slide',
                        'post_per_page' => -1
                    ));
                ?>
                <?php   if($slidelist->have_posts()): ?>

                <div class="homepage_slides">

                     <?php while($slidelist->have_posts()): $slidelist->the_post(); ?>

                    <div class="single_homepage_slides">
                        <div class="row">
                            <div class="col-md-12">
                            <div class="home_silde_image">
                            </div>
                            <?php the_post_thumbnail(); ?>
                                 <div class="centered">
                                    <h4><?php the_title(); ?></h4>
                                    <div class="home_btn">
                                        <?php $shop_url = get_post_meta(get_the_ID(),'e_store_shop_url', true);
                                            
                                        ?>
                                        <a href="<?php echo (esc_url($shop_url)); ?>"> <?php esc_html_e( 'Shop Now', 'e_store' ); ?></a>
                                    </div>
                                </div> 
                        

                            </div>
                        </div>
                        
                    </div>

                    <?php
                        endwhile;
                        wp_reset_postdata( );

                    ?>
                </div>  
                    <?php else: ?>
                             <img src="<?php echo get_template_directory_uri( ); ?>/assets/images/image4.jpg" />
                     <?php endif; ?>

                </div>

            <div class="col-md-3 col-sm-4">

                <?php
                    $p_categories = (!empty($themesbazar['slider_sidebar_product_category'])) ? $themesbazar['slider_sidebar_product_category'] : 'empty';
                       
                        if($p_categories != 'empty'){ 

                        foreach($p_categories as $product_cat){
                        $term = get_term_by( 'id', $product_cat, 'product_cat' );
                    
                       //print_r($term);
                        $pcat_name = $term->name;
                        $pcat_slug = $term->slug;
                         $pcategory_name_link = get_category_link($product_cat);
                        // $pcat_id = $term->term_id;

                 ?>

                            <?php
                            $args = array( 'post_type' => 'product', 'posts_per_page' => 1, 'orderby' => 'DESC' );
                            $loop = new WP_Query( $args );
                    
                            while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>

                            <div class="excusive_product">
                                <?php
                                    $pcat_thumbnail_id = get_term_meta( $term->term_id, 'thumbnail_id', true );
                                    $pcat_thumb_url = wp_get_attachment_url( $pcat_thumbnail_id );
                                
                                ?>
                            <a href="<?php echo $pcategory_name_link; ?>"> <img src="<?php  echo $pcat_thumb_url; ?>" alt=""> </a>
                                <div class="excusive_product_heading">
                                    <a href="<?php echo $pcategory_name_link; ?>"><?php echo $pcat_name; ?> </a>
                                    <h4 class="more_product">
                                        <a href="<?php echo $pcategory_name_link; ?>"> <?php esc_html_e( 'shop now ', 'e_store' ); ?><i class="fa fa-angle-double-right"></i></a>
                                    </h4>
                                </div>                           
                            </div>
                            <?php
                            endwhile; wp_reset_query();
                        
                            ?>
                        <?php } ?>
                            
                      <?php  } else{
                            echo '<h4 class="category-missing-message">Please select categories from Theme Options => Homepage Settings => Main Slider/Banner Section</h4>';
                        }
                        ?>
  
            </div>

        </div>  
    </div>
</section>