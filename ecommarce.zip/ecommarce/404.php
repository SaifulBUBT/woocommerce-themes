
<?php
show_category_list();
?>

    <div class="breadcrumb">
      <div class="container">
        <div class="breadcrumb-inner">
          <ul class="list-inline list-unstyled">
            <li><a href="<?php echo bloginfo('url')?>">Home</a></li>
            <li class='active'><?php the_title()?></li>
          </ul>
        </div>
        <!-- /.breadcrumb-inner -->
      </div>
      <!-- /.container -->
    </div>
    <!-- /.breadcrumb -->
    <div class="body-content">
      <div class="container">
        <div class="row">
          <div class="blog-page">
            <div class="col-md-9">

			
			 <div align="center">
       <h2>Ooops... Error 404 </h2>
       <h3>Sorry, but the page you are looking for doesn't exist. </h3>
       <h4>You can go to the <a href="<?php bloginfo('url'); ?>"><button>Homepage</button> </a></h4>
   </div> 
			
				  
            </div>
			
			<?php get_template_part('right-sideber');?>
            
          </div>
        </div>
       	
      </div>
    </div>
<?php get_footer();?>