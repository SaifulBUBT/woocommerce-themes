<?php  global $themesbazar; ?>

<style>
    body {
    background-color: <?php echo $themesbazar['body-bg']; ?>;
    }
    .top-bar {
        background-color: <?php echo $themesbazar['top-menu-bg']; ?>;

    }
    .top-bar .cnt-account ul > li a {
        color: <?php echo $themesbazar['top-menu-font-color']; ?>;
    }
    .main-header {
        background: <?php echo $themesbazar['header-bg']; ?>;
    }
    .main-header .top-search-holder .search-area .search-button {
        background-color: <?php echo $themesbazar['search-button-bg']; ?>;
        border: 1px solid <?php echo $themesbazar['search-button-border-color']; ?>;
    } 
    .header-style-1 .header-nav {
        background:<?php echo $themesbazar['menu-background']; ?>;
    }
    .header-style-1 .header-nav .navbar-default .navbar-collapse .navbar-nav > li > a {
        font-size: <?php echo $themesbazar['menu-font']['font-size']; ?>;
        font-weight: <?php echo $themesbazar['menu-font']['font-weight']; ?>;
        color: <?php echo $themesbazar['menu-font']['color']; ?>;
        font-family: <?php echo $themesbazar['menu-font']['font-family']; ?>;
    }
    .navbar-nav .open a{
        background:<?php echo $themesbazar['submenu-background']; ?>!important;
        color:<?php echo $themesbazar['submenu-color']; ?>!important;
    }
    .sidebar .side-menu .head {
        color: <?php echo $themesbazar['sidebar-category-title-color']; ?>;
        background-color: <?php echo $themesbazar['sidebar-category-title-background']; ?>;
       

    }
    .footer .footer-bottom {
        background: <?php echo $themesbazar['footer-color']; ?>;
    }
    .footer .footer-bottom .module-heading {
        color: <?php echo $themesbazar['footer-text-color']; ?>;  
    }
    .toggle-footer {
        color: <?php echo $themesbazar['footer-text-color']; ?>;  

    }
    .footer .footer-bottom .module-body ul li a {
        color: <?php echo $themesbazar['footer-text-color']; ?>;  

    }
    .copyright-bar {
        background: <?php echo $themesbazar['footer-color_02']; ?>; 
    }

 </style>