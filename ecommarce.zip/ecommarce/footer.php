<?php global $themesbazar;?>
	
    <!-- FOOTER -->
    <footer id="footer" class="footer color-bg">
      <div class="footer-bottom">
        <div class="container">
          <div class="row">
            <div class="col-xs-12 col-sm-6 col-md-3">
              <div class="module-heading">
                <h4 class="module-title"><?php echo $themesbazar['contect_title'] ?></h4>
              </div>
              <div class="module-body">
                <ul class="toggle-footer" style="">
                  <li class="media">
                    <div class="pull-left">
                      <span class="icon fa-stack fa-lg">
                      <i class="fa fa-map-marker fa-stack-1x fa-inverse"></i>
                      </span>
                    </div>
                    <div class="media-body">
                      <?php echo $themesbazar['address'] ?>
                    </div>
                  </li>
                  <li class="media">
                    <div class="pull-left">
                      <span class="icon fa-stack fa-lg">
                      <i class="fa fa-mobile fa-stack-1x fa-inverse"></i>
                      </span>
                    </div>
                    <div class="media-body">
                      <?php echo $themesbazar['phone'] ?>
                    </div>
                  </li>
                  <li class="media">
                    <div class="pull-left">
                      <span class="icon fa-stack fa-lg">
                      <i class="fa fa-envelope fa-stack-1x fa-inverse"></i>
                      </span>
                    </div>
                    <div class="media-body">
                      <span><a href="mailto:<?php echo $themesbazar['email'] ?>"><?php echo $themesbazar['email'] ?></a></span>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-3">
              <div class="module-heading">
                <h4 class="module-title"><?php echo $themesbazar['footer_menu'] ?></h4>
              </div>
              <div class="module-body">
                <ul class='list-unstyled'>
                  <?php /* Top Menu */
		        wp_nav_menu( array(
		           'theme_location' => 'footer-one',
				   ));?>
                </ul>
              </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-3">
              <div class="module-heading">
                <h4 class="module-title"><?php echo $themesbazar['footer_two'] ?></h4>
              </div>
              <div class="module-body">
                <ul class='list-unstyled'>
                  <?php /* Top Menu */
		        wp_nav_menu( array(
		           'theme_location' => 'footer-two',
				   ));?>
                </ul>
              </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-3">
              <div class="module-heading">
                <h4 class="module-title"><?php echo $themesbazar['footer_three'] ?></h4>
              </div>
              <div class="module-body">
                <ul class='list-unstyled'>
                  <?php /* Top Menu */
		        wp_nav_menu( array(
		           'theme_location' => 'footer-three',
				   ));?>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="copyright-bar">
        <div class="container">
          <div class="col-xs-12 col-sm-4 no-padding social">
            <ul class="link">
              <li class="fb pull-left"><a target="_blank" rel="nofollow" href="<?php echo $themesbazar['footer-link']['facebook-url'] ?>" title="Facebook"></a></li>
              <li class="tw pull-left"><a target="_blank" rel="nofollow" href="<?php echo $themesbazar['footer-link']['twitter-url'] ?>" title="Twitter"></a></li>
              <li class="googleplus pull-left"><a target="_blank" rel="nofollow" href="<?php echo $themesbazar['footer-link']['googleplus-url'] ?>" title="GooglePlus"></a></li>
              <li class="rss pull-left"><a target="_blank" rel="nofollow" href="<?php echo $themesbazar['footer-link']['rss-url'] ?>" title="RSS"></a></li>
              <li class="pintrest pull-left"><a target="_blank" rel="nofollow" href="<?php echo $themesbazar['footer-link']['pinterest-url'] ?>" title="PInterest"></a></li>
              <li class="linkedin pull-left"><a target="_blank" rel="nofollow" href="<?php echo $themesbazar['footer-link']['linkedin-url'] ?>" title="Linkedin"></a></li>
              <li class="youtube pull-left"><a target="_blank" rel="nofollow" href="<?php echo $themesbazar['footer-link']['youtube-url'] ?>" title="Youtube"></a></li>
            </ul>
          </div>
          <div class="col-xs-12 col-sm-4 no-padding">
            <div class="clearfix payment-methods">
              <ul>
                <li><img src="<?php echo $themesbazar['footer-imgone']['url']?>" alt=""></li>
                <li><img src="<?php echo $themesbazar['footer-imgtwo']['url']?>" alt=""></li>
                <li><img src="<?php echo $themesbazar['footer-imgthree']['url']?>" alt=""></li>
                <li><img src="<?php echo $themesbazar['footer-imgfour']['url']?>" alt=""></li>
                <li><img src="<?php echo $themesbazar['footer-imgfive']['url']?>" alt=""></li>
              </ul>
            </div>
          </div>
		  <div class="col-xs-12 col-sm-4 no-padding">
            <div class="clearfix payment-methods"><font color="white">
           Design & Developed By <a href="http://www.themesbazar.com" target="_blank" style="color:yellow; font-weight:bold">ThemesBazar.Com </a></font>
            </div>
          </div>
        </div>
      </div>
    </footer>

	<?php wp_footer(); ?>
  </body>
</html>

