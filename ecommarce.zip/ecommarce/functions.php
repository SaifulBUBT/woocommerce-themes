<?php

//*** Support Title Tag 
add_theme_support( 'title-tag' );

/* --------------Post Thumbnails Add-------------- */
    
add_theme_support( 'post-thumbnails');
set_post_thumbnail_size( 600, 337, true );
add_image_size( 'single-thumbnail', 600, 337, true );

include('lib/tgm/example.php');


//*** Enqueue FlipMart Scripts
function flipmart_enqueue_scripts(){
	
	wp_enqueue_style( 'bootstrap', get_template_directory_uri().'/assets/css/bootstrap.min.css', array(), '3.2.0' );
		
	wp_enqueue_style( 'main', get_template_directory_uri().'/assets/css/main.css', array(), time() );
	
	
	wp_enqueue_style( 'blue', get_template_directory_uri().'/assets/css/blue.css', array(), time() );
	wp_enqueue_style( 'stellarnav', get_template_directory_uri().'/assets/css/stellarnav.css', array(), time() );
	
	wp_enqueue_style( 'owl.carousel', get_template_directory_uri().'/assets/css/owl.carousel.css', array(), '1.0' );
	
	wp_enqueue_style( 'owl.transitions', get_template_directory_uri().'/assets/css/owl.transitions.css', array(), '1.0' );
	
	wp_enqueue_style('google-roboto-font', '//fonts.googleapis.com/css?family=Roboto:300,400,500,700');
    wp_enqueue_style('google-open-sens-font', '//fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,600,600italic,700,700italic,800');
    wp_enqueue_style('google-montserrat-font', '//fonts.googleapis.com/css?family=Montserrat:400,700');
	
	wp_enqueue_style( 'justified-gallery', get_template_directory_uri().'/assets/css/justifiedGallery.css', array(), time() );
	
	wp_enqueue_style( 'animate.min', get_template_directory_uri().'/assets/css/animate.min.css', array(), '1.0' );
	
	wp_enqueue_style( 'rateit', get_template_directory_uri().'/assets/css/rateit.css', array(), '1.0' );
	
	wp_enqueue_style( 'bootstrap-select.min', get_template_directory_uri().'/assets/css/bootstrap-select.min.css', array(), '1.0' );
	
	wp_enqueue_style( 'font-awesome', get_template_directory_uri().'/assets/css/font-awesome.css', array(), '1.0' );
	wp_enqueue_style( 'woocommerce', get_template_directory_uri().'/assets/css/woocommerce.css', array(), time() );
	
	// Theme stylesheet.
	wp_enqueue_style( 'style', get_stylesheet_uri() );
	wp_enqueue_style( 'responsive', get_template_directory_uri().'/assets/css/responsive.css', array(), time() );

	
	// WP Latest JQuery
	wp_enqueue_script( 'jquery' );
	
	wp_enqueue_script( 'bootstrap.min', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array(), '1.0.0', true );
	
	wp_enqueue_script( 'bootstrap-hover-dropdown.min', get_template_directory_uri() . '/assets/js/bootstrap-hover-dropdown.min.js', array(), '1.0.0', true );
	
	wp_enqueue_script( 'owl.carousel.min', get_template_directory_uri() . '/assets/js/owl.carousel.min.js', array(), '1.0.0', true );
	
	wp_enqueue_script( 'echo.min', get_template_directory_uri() . '/assets/js/echo.min.js', array(), '1.0.0', true );
	
	wp_enqueue_script( 'jquery.easing', get_template_directory_uri() . '/assets/js/jquery.easing-1.3.min.js', array(), '1.0.0', true );
	
	wp_enqueue_script( 'bootstrap-slider.min', get_template_directory_uri() . '/assets/js/bootstrap-slider.min.js', array(), '1.0.0', true );
	
	wp_enqueue_script( 'jquery.rateit.min', get_template_directory_uri() . '/assets/js/jquery.rateit.min.js', array(), '1.0.0', true );
	
	wp_enqueue_script( 'justified-gallery-js', get_template_directory_uri() . '/assets/js/jquery.justifiedGallery.js', array('jquery'), time(), true );
	
	wp_enqueue_script( 'lightbox.min', get_template_directory_uri() . '/assets/js/lightbox.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'stellarnav-js', get_template_directory_uri() . '/assets/js/stellarnav.min.js', array(), '1.0.0', true );

	wp_enqueue_script( 'bootstrap-select.min', get_template_directory_uri() . '/assets/js/bootstrap-select.min.js', array(), '1.0.0', true );
	
	wp_enqueue_script( 'wow.min', get_template_directory_uri() . '/assets/js/wow.min.js', array(), '1.0.0', true );
	
	wp_enqueue_script( 'scripts', get_template_directory_uri() . '/assets/js/scripts.js', array(), time(), true );
	

}

add_action('wp_enqueue_scripts','flipmart_enqueue_scripts');


function ecommerce_load_custom_wp_admin_style() {
	wp_enqueue_style( 'admin-dashboard', get_template_directory_uri().'/assets/css/dashboard.css', array(), time() );

}
add_action( 'admin_enqueue_scripts', 'ecommerce_load_custom_wp_admin_style' );



// WooCommerce Theme Support 

add_action( 'after_setup_theme', 'woocommerce_support' );
function woocommerce_support() {
    add_theme_support( 'woocommerce' );
}



// FlipMart sidebar register
add_action( 'widgets_init', 'theme_slug_widgets_init' );
function theme_slug_widgets_init() {
    register_sidebar( array(
        'name' => __( 'Left Sidebar Top', 'eshop' ),
        'id' => 'left_sidebar_top',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'eshop' ),
        'before_widget' => '<div class="sidebar-widget wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="section-title">',
		'after_title'   => '</h3>',
    ) );
	register_sidebar( array(
        'name' => __( 'Left Sidebar Bottom', 'eshop' ),
        'id' => 'left_sidebar_bottom',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'eshop' ),
        'before_widget' => '<div class="sidebar-widget wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="section-title">',
		'after_title'   => '</h3>',
    ) );
	
	register_sidebar( array(
        'name' => __( 'Right Sidebar', 'eshop' ),
        'id' => 'right_sidebar',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'eshop' ),
        'before_widget' => '<div class="sidebar-widget wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="section-title">',
		'after_title'   => '</h3>',
    ) );
	
	
	register_sidebar( array(
        'name' => __( 'Widgets Aria One', 'eshop' ),
        'id' => 'widget_01',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'eshop' ),
        'before_widget' => '<div class="sidebar-widget wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="section-title">',
		'after_title'   => '</h3>',
    ) );
	register_sidebar( array(
        'name' => __( 'Widgets Aria Two', 'eshop' ),
        'id' => 'widget_02',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'eshop' ),
        'before_widget' => '<div class="sidebar-widget wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="section-title">',
		'after_title'   => '</h3>',
    ) );
	register_sidebar( array(
        'name' => __( 'Widgets Aria Three', 'eshop' ),
        'id' => 'widget_03',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'eshop' ),
        'before_widget' => '<div class="sidebar-widget wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="section-title">',
		'after_title'   => '</h3>',
    ) );
	register_sidebar( array(
        'name' => __( 'Widgets Aria Four', 'eshop' ),
        'id' => 'widget_04',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'eshop' ),
        'before_widget' => '<div class="sidebar-widget wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="section-title">',
		'after_title'   => '</h3>',
    ) );
	register_sidebar( array(
        'name' => __( 'Widgets Aria Five', 'eshop' ),
        'id' => 'widget_05',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'eshop' ),
        'before_widget' => '<div class="sidebar-widget wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="section-title">',
		'after_title'   => '</h3>',
    ) );
	register_sidebar( array(
        'name' => __( 'Widgets Aria Six', 'eshop' ),
        'id' => 'widget_06',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'eshop' ),
        'before_widget' => '<div class="sidebar-widget wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="section-title">',
		'after_title'   => '</h3>',
    ) );
	register_sidebar( array(
        'name' => __( 'Widgets Aria Seven', 'eshop' ),
        'id' => 'widget_07',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'eshop' ),
        'before_widget' => '<div class="sidebar-widget wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="section-title">',
		'after_title'   => '</h3>',
    ) );
	register_sidebar( array(
        'name' => __( 'Widgets Aria Eight', 'eshop' ),
        'id' => 'widget_08',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'eshop' ),
        'before_widget' => '<div class="sidebar-widget wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="section-title">',
		'after_title'   => '</h3>',
    ) );
	register_sidebar( array(
        'name' => __( 'Widgets Aria Nine', 'eshop' ),
        'id' => 'widget_09',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'eshop' ),
        'before_widget' => '<div class="sidebar-widget wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="section-title">',
		'after_title'   => '</h3>',
    ) );
	register_sidebar( array(
        'name' => __( 'Widgets Aria Ten', 'eshop' ),
        'id' => 'widget_10',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'eshop' ),
        'before_widget' => '<div class="sidebar-widget wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="section-title">',
		'after_title'   => '</h3>',
    ) );
	
}

/* --------------Photo Gallary Customs Post Register----------------- */

if(function_exists('register_post_type')) {
		register_post_type('slides', array(
			'labels' => array(
				'name' => __('slide', 'ecommerce'),
				'menu_name' => __('Slides', 'ecommerce'),
				'add_new' => __('Add New Slide', 'ecommerce'),
				'add_new_item' => __('Add New Slide', 'ecommerce'),
			),
			'public' => true,
			'menu_icon' => 'dashicons-format-gallery',
			'supports' => array('title','editor','thumbnail')
		   ));
	    }
		
/* --------------Testimonial Customs Post Register----------------- */

if(function_exists('register_post_type')) {
		register_post_type('testimonial', array(
			'labels' => array(
				'name' => __('testimonial', 'ecommerce'),
				'menu_name' => __('Testimonial', 'ecommerce'),
				'add_new' => __('Add New Testimonial', 'ecommerce'),
				'add_new_item' => __('Add New Testimonial', 'ecommerce'),
			),
			'public' => true,
			'menu_icon' => 'dashicons-format-gallery',
			'supports' => array('title','editor','thumbnail')
		   ));
	    }
		
function excerpt($num) {
$limit = $num+1;
$excerpt = explode(' ', get_the_excerpt(), $limit);
array_pop($excerpt);
$excerpt = implode(" ",$excerpt)." <a href='" .get_permalink($post->ID) ." ' class='".readmore."'></a>";
echo $excerpt; }


include('lib/ReduxCore/framework.php');
include('lib/sample/config.php');
include('include/menu.php');
include('include/wp-bootstrap-navwalker.php');

/*function themes_woocommerce_cart_link(){
	global $woocommerce;
	$total = $woocommerce->cart->total;
	$items = $woocommerce->get_cart();

}

 function header_add_cart_fragment($fragments){
 	global $woocommerce;
 	ob_start();
 	woocommerce_cart_link();
 	$fragments['.cb-basket'] = ob_get_clean();
 	return $fragments;
 }
 add_filter('woocommerce_add_to_cart_fragments','header_add_cart_fragment');*/
 
 
 
 
/****
 * Code for woocommerce
 * *** */

remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20);
remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );
remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );
remove_action( 'woocommerce_after_shop_loop', 'woocommerce_pagination', 10 );


/***
 * Shop page columns no
 * ** */
function e_store_loop_shop_column($nc)
{
    return 3;
}
add_filter('loop_shop_columns', 'e_store_loop_shop_column');

/***
 * create pagination function
 */
if (!function_exists('woo_e_store_pagination')) :
    function woo_e_store_pagination()
    {
        global $wp_query;

        if ($wp_query->max_num_pages <= 1) return;

        $big = 999999999; // need an unlikely integer

        $pages = paginate_links(array(
            'base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
            'format' => '?paged=%#%',
            'current' => max(1, get_query_var('paged')),
            'total' => $wp_query->max_num_pages,
            'mid_size' => 1,
            'prev_next' => true,
            'prev_text'    => __('<i class="fa fa-angle-left"></i>'),
            'next_text'    => __('<i class="fa fa-angle-right"></i>'),
            'type'         => 'array'
        ));

        if (is_array($pages)) {
            $paged = (get_query_var('paged') == 0) ? 1 : get_query_var('paged');
            echo '<div class="pagination-container"><ul class="list-inline list-unstyled">';
            foreach ($pages as $page) {
                echo "<li>$page</li>";
            }
            echo '</ul></div>';
        }
    }
endif;


/****
 * WooCommerce shop page show per page drop down
 * */
function e_store_woocommerce_catalog_page_ordering() {
	?>
	<div class="lbl-cnt">
	<?php echo '<span class="lbl">Show</span>' ?>
	<form action="" method="POST" name="results" class="fld inline">
	<select name="woocommerce-sort-by-columns" id="woocommerce-sort-by-columns" class="sortby" onchange="this.form.submit()">
	<?php
	//Get products on page reload
	if  (isset($_POST['woocommerce-sort-by-columns']) && (($_COOKIE['shop_pageResults'] <> $_POST['woocommerce-sort-by-columns']))) {
	$numberOfProductsPerPage = $_POST['woocommerce-sort-by-columns'];
	} else {
	$numberOfProductsPerPage = $_COOKIE['shop_pageResults'];
	}
	//  This is where you can change the amounts per page that the user will use  feel free to change the numbers and text as you want, in my case we had 4 products per row so I chose to have multiples of four for the user to select.
	$shopCatalog_orderby = apply_filters('woocommerce_sortby_page', array(
	//Add as many of these as you like, -1 shows all products per page
	//  ''       => __('Results per page', 'woocommerce'),
	'12' 		=> __('12', 'e_store'),
	'15' 		=> __('15', 'e_store'),
	'18' 		=> __('18', 'e_store'),
	'30' 		=> __('30', 'e_store'),
	'40' 		=> __('40', 'e_store'),
	'50' 		=> __('50', 'e_store'),
	'-1' 		=> __('All', 'e_store'),
	));
	foreach ( $shopCatalog_orderby as $sort_id => $sort_name )
	echo '<option value="' . $sort_id . '" ' . selected( $numberOfProductsPerPage, $sort_id, true ) . ' >' . $sort_name . '</option>';
	?>
	</select>
	</form>
	</div>
	<?php
	}

	// now we set our cookie if we need to
function dl_sort_by_page($count) {
	if (isset($_COOKIE['shop_pageResults'])) { // if normal page load with cookie
	$count = $_COOKIE['shop_pageResults'];
	}
	if (isset($_POST['woocommerce-sort-by-columns'])) { //if form submitted
	setcookie('shop_pageResults', $_POST['woocommerce-sort-by-columns'], time()+1209600, '/', 'www.your-domain-goes-here.com', false); //this will fail if any part of page has been output- hope this works!
	$count = $_POST['woocommerce-sort-by-columns'];
	}
	// else normal page load and no cookie
	return $count;
	}
	add_filter('loop_shop_per_page','dl_sort_by_page');

/****
 * End WooCommerce shop page show per page drop down
 * */


 // WooCommerce custom catalog ordering 
function e_store_custom_woocommerce_catalog_orderby( $sortby ) {
	$sortby['menu_order'] = 'Position';
	$sortby['price'] = 'Price:Lowest first';
	$sortby['price-desc'] = 'Price:HIghest first';
	unset($sortby['popularity']);
	unset($sortby['date']);
	unset($sortby['rating']);
	
	return $sortby;
}
add_filter( 'woocommerce_catalog_orderby', 'e_store_custom_woocommerce_catalog_orderby' );


// Remove list/grid view plugin default option

function e_store_listgrid_plugin_option(){
	global $WC_List_Grid;
	remove_action( 'woocommerce_before_shop_loop', array( $WC_List_Grid, 'gridlist_toggle_button' ), 30); 
 }
 add_action('woocommerce_archive_description','e_store_listgrid_plugin_option');


 /****
  * Single product page
  */
  remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price' ,10 );
  add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price' ,25 );


  /**
   *  Customized checkout fields
   * ** */

// Our hooked in function - $fields is passed via the filter!
function e_store_custom_override_checkout_fields( $fields ) {
     $fields['billing']['billing_first_name']['input_class'] = array('form-control unicase-form-control text-input');
     $fields['billing']['billing_last_name']['input_class'] = array('form-control unicase-form-control text-input');
     $fields['billing']['billing_company']['input_class'] = array('form-control unicase-form-control text-input');
     $fields['billing']['billing_address_1']['input_class'] = array('form-control unicase-form-control text-input');
     $fields['billing']['billing_address_2']['input_class'] = array('form-control unicase-form-control text-input');
     $fields['billing']['billing_city']['input_class'] = array('form-control unicase-form-control text-input');
     $fields['billing']['billing_postcode']['input_class'] = array('form-control unicase-form-control text-input');
     $fields['billing']['billing_phone']['input_class'] = array('form-control unicase-form-control text-input');
     $fields['billing']['billing_email']['input_class'] = array('form-control unicase-form-control text-input');
	
	 $fields['shipping']['shipping_first_name']['input_class'] = array('form-control unicase-form-control text-input');
     $fields['shipping']['shipping_last_name']['input_class'] = array('form-control unicase-form-control text-input');
     $fields['shipping']['shipping_company']['input_class'] = array('form-control unicase-form-control text-input');
     $fields['shipping']['shipping_address_1']['input_class'] = array('form-control unicase-form-control text-input');
     $fields['shipping']['shipping_address_2']['input_class'] = array('form-control unicase-form-control text-input');
     $fields['shipping']['shipping_city']['input_class'] = array('form-control unicase-form-control text-input');
     $fields['shipping']['shipping_postcode']['input_class'] = array('form-control unicase-form-control text-input');

	
	 return $fields;
}
add_filter( 'woocommerce_checkout_fields' , 'e_store_custom_override_checkout_fields' );

