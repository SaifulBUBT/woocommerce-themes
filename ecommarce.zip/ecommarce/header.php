<?php global $themesbazar; ?>

<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js no-svg">
  <head>
    <!-- Meta -->
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
	
   

	<?php wp_head(); ?>
  <?php
	/**
	 * Dynamic CSS
	 */
		require_once get_theme_file_path('/assets/css/dynamic-css.php');
	?>
  </head>
  <body <?php body_class();?>>
    <!--  HEADER  -->
    <header class="header-style-1">
      <div class="top-bar animate-dropdown">
        <div class="container">
          <div class="header-top-inner">
            <div class="cnt-account">
              <ul class="list-unstyled">
                <?php /* Top Menu */
		        wp_nav_menu( array(
		           'theme_location' => 'top-menu',
				   ));?>	
              </ul>
            </div>
            
            <div class="clearfix"></div>
          </div>
        </div>
      </div>
      <div class="main-header">
        <div class="container">
          <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-3 logo-holder">
              <div class="logo">
				<?php
					$e_store_logo_url =  $themesbazar['logo_upload']['url'];
					if( ! empty($e_store_logo_url)) {
				  ?>
					<a href="<?php echo home_url( '/' ) ?>"><img src="<?php echo $e_store_logo_url; ?>"/></a>
					<?php } else{ ?>
					<a href="<?php echo home_url( '/' ) ?>"><img src="<?php  echo get_template_directory_uri();?>/assets/images/logo.gif"/></a>	
					<?php } ?>
              </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-7 top-search-holder">
              <div class="search-area">
           
                  <div class="control-group">
							
					                <!---<form class="example" method="get" action="<?php echo home_url( '/' ); ?>">
										<input type="text" class="search-field" maxlength="64" placeholder="<?php echo $themesbazar['placeholder']?>" value="<?php the_search_query(); ?>" name="s" />
										<button type="submit" class="search-button"><?php// echo $themesbazar['search']?></button>
									  
									</form>--->
									

                    <?php //echo do_shortcode( '[smart_search id="1"]' ); ?>
                    <?php //echo do_shortcode( '[aws_search_form]' ); ?>
					<?php //if ( function_exists( 'aws_get_search_form' ) ) { aws_get_search_form(); } ?>
					<?php echo do_shortcode('[wcas-search-form]'); ?>
                    
                      
                  </div>
              
              </div>
              <!-- SEARCH AREA : END -->				
            </div>
            <div class="col-xs-12 col-sm-12 col-md-2 animate-dropdown top-cart-row">
              <!-- SHOPPING CART DROPDOWN -->
              <div class="dropdown dropdown-cart">
        

               
                  <div class="items-cart-inner">
                                <div class="total-price-basket">
                        <span class="total-price"> </br>
                     <span class="value_themes" style="color: white"><i class="glyphicon glyphicon-shopping-cart"></i> <a class="cart-customlocation" href="<?php echo wc_get_cart_url(); ?>" title="<?php _e( 'View your shopping cart' ); ?>">
                      <?php echo sprintf ( _n( '%d item', '%d items', WC()->cart->get_cart_contents_count() ), WC()->cart->get_cart_contents_count() ); ?> - <?php echo WC()->cart->get_cart_total(); ?></a></span>
                      </span>
                    </div>
                  </div>
              
                <ul class="dropdown-menu">
                  <li>
                    <div class="cart-item product-summary">
                      <div class="row">
                        <div class="col-xs-4">
                          <div class="image">
                            <a href="detail.html"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/cart.jpg" alt=""></a>
                          </div>
                        </div>
                        <div class="col-xs-7">
                          <h3 class="name"><a href="index8a95.html?page-detail">Simple Product</a></h3>
                          <div class="price">$600.00</div>
                        </div>
                        <div class="col-xs-1 action">
                          <a href="#"><i class="fa fa-trash"></i></a>
                        </div>
                      </div>
                    </div>
                    <div class="clearfix"></div>
                    <hr>
                    <div class="clearfix cart-total">
                      <div class="pull-right">
                        <span class="text">Sub Total :</span><span class='price'>$600.00</span>
                      </div>
                      <div class="clearfix"></div>
                      <a href="checkout.html" class="btn btn-upper btn-primary btn-block m-t-20">Checkout</a>	
                    </div>
                  </li>
                </ul>
              </div>
              <!-- SHOPPING CART DROPDOWN : END -->				
            </div>
          </div>
        </div>
      </div>
      <!--  NAVBAR -->
		<div class="main-menu">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						
					
   
    
                  <?php /* Primary navigation */
						/****wp_nav_menu( array(
						   'theme_location' => 'main-menu',
						   'menu_class'    => 'nav navbar-nav',
						   'fallback_cb' => 'default_main_menu',
						   'walker' => new wp_bootstrap_navwalker())
							  ); ***/
							?>
							      <?php /* Primary navigation */
						wp_nav_menu( array(
						   'theme_location' => 'main-menu',
						   'container' => 'div',
						   'container_class' => 'stellarnav',
						   'depth' => 0,
						   'fallback_cb' => 'default_main_menu',
						   )); 
							?>
					
				
					</div>
					</div>
					</div>
				</div>
			</div>
							
          </div>
        </div>

    </header>