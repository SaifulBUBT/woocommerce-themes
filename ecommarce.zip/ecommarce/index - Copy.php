<?php
//show_category_list();
 get_header(); 
 global $themesbazar; 
?>

    <!--  HEADER : END  -->
    <div class="body-content outer-top-xs" id="top-banner-and-menu">
      <div class="container">
        <div class="row">
       
          <!-- CONTENT -->
          <div class="col-xs-12 col-sm-12 col-md-9 homebanner-holder pull-right">

			<!-- SECTION – HERO -->
			<div id="hero">
			<div id="owl-main" class="owl-carousel owl-inner-nav owl-ui-sm">
				
				<?php 
							$how_post= $themesbazar['how_many_slide'];
							$gallary = new WP_Query(array(
								'post_type' => 'slides',
								'posts_per_page' => $how_post,
								'orderby'     => 'DESC',
							));
							while($gallary->have_posts()) : $gallary->the_post(); ?>	
								<?php $backgroundImg = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'full' ); ?>
							
				<div class="item" style="background: url(<?php echo $backgroundImg[0] ?>) no-repeat;
			background-position:center;" width="100%">
				<div class="container-fluid">
					<div class="caption bg-color vertical-center text-left">
					<div class="big-text fadeInDown-1">
						<?php the_title();?>
					</div>
					<div class="excerpt fadeInDown-2 hidden-xs">
						<span><?php the_content(); ?></span>
					</div>

					</div>
				</div>
				</div>
				<?php 
					endwhile;
					wp_reset_query();

				?>
			</div>
			</div>
			<!-- INFO BOXES  -->

			<!--========= Money back section start =========--->
			<div class="info-boxes wow fadeInUp hidden-xs">
				<div class="info-boxes-inner">
					<div class="row">
					
					<div class="col-md-6 col-sm-4 col-lg-4">
						<div class="info-box">
						<div class="row">
							<div class="col-xs-12">
							<h4 class="info-box-heading green"><?php echo $themesbazar['money_title'] ?></h4>
							</div>
						</div>
						<h6 class="text"><?php echo $themesbazar['money_desc'] ?></h6>
						</div>
					</div>

					<div class="hidden-md col-sm-4 col-lg-4">
						<div class="info-box">
						<div class="row">
							<div class="col-xs-12">
							<h4 class="info-box-heading green"><?php echo $themesbazar['free_title'] ?></h4>
							</div>
						</div>
						<h6 class="text"><?php echo $themesbazar['free_desc'] ?></h6>
						</div>
					</div>

					<div class="col-md-6 col-sm-4 col-lg-4">
						<div class="info-box">
						<div class="row">
							<div class="col-xs-12">
							<h4 class="info-box-heading green"><?php echo $themesbazar['special_title'] ?></h4>
							</div>
						</div>
						<h6 class="text"><?php echo $themesbazar['special_desc'] ?> </h6>
						</div>
					</div>

					</div>
				</div>
			</div>
			<!--========= Money back section end =========--->

			<!--======= Category gallery section start =======-->
			<section class="justified_product_category">
				<div id="mygallery" >
				
					<?php
					$p_categories = (!empty($themesbazar['justified_category_gallery'])) ? $themesbazar['justified_category_gallery'] : 'empty';
					
						if($p_categories != 'empty'){ 

						foreach($p_categories as $product_cat){
						$term = get_term_by( 'id', $product_cat, 'product_cat' );
					
					//print_r($term);
						$pcat_name = $term->name;
						$pcat_slug = $term->slug;
						$pcategory_name_link = get_category_link($product_cat);
						// $pcat_id = $term->term_id;

				?>

						<?php
						$args = array( 'post_type' => 'product', 'posts_per_page' => 1, 'orderby' => 'DESC' );
						$loop = new WP_Query( $args );
				
						while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>

							<div>
									<?php
										$pcat_thumbnail_id = get_term_meta( $term->term_id, 'thumbnail_id', true );
										$pcat_thumb_url = wp_get_attachment_url( $pcat_thumbnail_id );
									
									?>
								<a href="<?php echo $pcategory_name_link; ?>">
									<img alt="Title 1" src="<?php echo $pcat_thumb_url; ?>"/>
								</a>	
								<div class="caption"> <a href="<?php echo $pcategory_name_link; ?>"><?php echo $pcat_name; ?> </a></div>
							</div>
							
					<?php
							endwhile; wp_reset_query();
						
							?>
						<?php } ?>
							
					<?php  } else{
							echo '<h4 class="category-missing-message">Please select categories from Theme Options => Homepage Settings => Product Category Gallery</h4>';
						}
						?>
					
					<!---
					<div>
						<a href="<?php echo get_template_directory_uri(); ?>/assets/images/products/p3.jpg">
						<img alt="Title 1" src="<?php echo get_template_directory_uri(); ?>/assets/images/category-img/post1.jpg"/>
						</a>	
						<div class="caption"> <a href="#">my custom caption</a></div>
					</div>

					--->
				<!-- other images... -->
				</div>
			</section>
			<!--======= Category gallery section end =======-->

			<!--======= Product Category one start =======-->
			<section class="section featured-product wow fadeInUp">
				<?php
				$id = (!empty($themesbazar['product_one'])) ? $themesbazar['product_one'] : 'empty';
				if($id != 'empty'){ 
					
				if( $term = get_term_by( 'id', $id, 'product_cat' ) ){
					$pcategory_name = $term->name;}
					$pcategory_name_link = get_category_link($id);

				?>
				<h3 class="section-title"><a href="<?php echo esc_url($pcategory_name_link);?>"> <?php echo $pcategory_name;?></a></h3>
				<div class="owl-carousel home-owl-carousel custom-carousel owl-theme outer-top-xs">
						<?php
				$args = array( 'post_type' => 'product', 'posts_per_page' => -1, 'product_cat' => $pcategory_name, 'orderby' => 'DESC'  );
				$loop = new WP_Query( $args );
				while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
						
						<div class="item item-carousel">
					<div class="products">
					<div class="product">
						<div class="product-image">
						<div class="image">
							<a href="<?php the_permalink()?>">
							<?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?>
							</a>
										</div>
							<?php if ( $product->is_on_sale() ) : ?>
								<div class="tag new"><span><?php woocommerce_show_product_sale_flash( $post, $product ); ?></span></div>
						<?php endif; ?>
						</div>
						<div class="product-info text-left">
						<h3 class="name"><a href="<?php the_permalink()?>"><?php the_title(); ?></a></h3>
				
						<div class="description"></div>
						<div class="product-price">		
							<span class="price">
							<?php echo $product->get_price_html(); ?>				</span>
							
						</div>
						</div>
						
					</div>
					</div>
				</div>
				
				<?php endwhile; wp_reset_query(); ?>
				
			</div>

			<?php  } else{
				echo '<h4 class="category-missing-message">Please select category from Theme Options => Homepage Product Category Settings => Product Category One</h4>';
				}
				?>
			</section>

			<!--  Widget Area One -->
			<?php if ( is_active_sidebar( 'widget_01' ) ) : ?>

			<div class="wide-banners wow fadeInUp outer-bottom-xs">
				<div class="row">
				<div class="col-md-12">
					<div class="wide-banner cnt-strip">
					<div class="image">
						<?php dynamic_sidebar('widget_01'); ?>
					</div>
					</div>
				</div>
				</div>
			</div>
			<?php endif; ?>
			<!--======= Product Category one end =======-->

			<!--======= Product Category two start =======-->
			<div class="best-deal wow fadeInUp outer-bottom-xs">
				<?php
				$id = (!empty($themesbazar['product_two'])) ? $themesbazar['product_two'] : 'empty';
					
					if($id != 'empty'){ 

						if( $term = get_term_by( 'id', $id, 'product_cat' ) ){
						$pcategory_name = $term->name;}
						$pcategory_name_link = get_category_link($id);
						?>

				<h3 class="section-title"><a href="<?php echo esc_url($pcategory_name_link);?>"> <?php echo $pcategory_name;?></a></h3>
					<div class="sidebar-widget-body outer-top-xs">
						<div class="owl-carousel best-seller custom-carousel owl-theme outer-top-xs">
									
							<div class="item">
								<div class="products best-product">
							<?php
									$args = array( 'post_type' => 'product', 'posts_per_page' => 2, 'product_cat' => $pcategory_name, 'orderby' => 'DESC' );
									$loop = new WP_Query( $args );
									while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
								
										<div class="product">
													<div class="product-micro">
														<div class="row product-micro-row">
														<div class="col col-xs-5">
															<div class="product-image">
															<div class="image">
																<a href="<?php the_permalink()?>">
											<?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?>
												</a>					
															</div>
															</div>
														</div>
														<div class="col col-xs-7">
															<div class="product-info">
															<h3 class="name"><a href="<?php the_permalink()?>"><?php the_title(); ?></a></h3>
															<div class="product-price">	
																<span class="price">
																<?php echo $product->get_price_html(); ?>					</span>
															</div>
															</div>
														</div>
														</div>
													</div>
										</div>
										
										<?php endwhile; wp_reset_query(); ?>
													
								</div>
							</div>

							<div class="item">
								<div class="products best-product">
								<?php
									$args = array( 'post_type' => 'product', 'posts_per_page' => 2, 'product_cat' => $pcategory_name, 'orderby' => 'DESC' ,'offset'     =>2 );
									$loop = new WP_Query( $args );
									while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
								
										<div class="product">
										<div class="product-micro">
											<div class="row product-micro-row">
											<div class="col col-xs-5">
												<div class="product-image">
												<div class="image">
													<a href="<?php the_permalink()?>">
								<?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?>
								</a>					
												</div>
												</div>
											</div>
											<div class="col col-xs-7">
												<div class="product-info">
												<h3 class="name"><a href="<?php the_permalink()?>"><?php the_title(); ?></a></h3>
												<div class="product-price">	
													<span class="price">
													<?php echo $product->get_price_html(); ?>					</span>
												</div>
												</div>
											</div>
											</div>
										</div>
										</div>
							
							<?php endwhile; wp_reset_query(); ?>
										
								</div>
							</div>

							<div class="item">
							<div class="products best-product">
								<?php
										$args = array( 'post_type' => 'product', 'posts_per_page' => 2, 'product_cat' => $pcategory_name, 'orderby' => 'DESC' ,'offset'     =>4 );
										$loop = new WP_Query( $args );
										while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
									
									<div class="product">
										<div class="product-micro">
											<div class="row product-micro-row">
											<div class="col col-xs-5">
												<div class="product-image">
												<div class="image">
													<a href="<?php the_permalink()?>">
								<?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?>
								</a>					
												</div>
												</div>
											</div>
											<div class="col col-xs-7">
												<div class="product-info">
												<h3 class="name"><a href="<?php the_permalink()?>"><?php the_title(); ?></a></h3>
												<div class="product-price">	
													<span class="price">
													<?php echo $product->get_price_html(); ?>					</span>
												</div>
												</div>
											</div>
											</div>
										</div>
										</div>
							
							<?php endwhile; wp_reset_query(); ?>
										
								</div>
							</div>

							<div class="item">
								<div class="products best-product">
								<?php
										$args = array( 'post_type' => 'product', 'posts_per_page' => 2, 'product_cat' => $pcategory_name, 'orderby' => 'DESC' ,'offset'     =>6 );
										$loop = new WP_Query( $args );
										while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
									
									<div class="product">
										<div class="product-micro">
											<div class="row product-micro-row">
											<div class="col col-xs-5">
												<div class="product-image">
												<div class="image">
													<a href="<?php the_permalink()?>">
								<?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?>
								</a>					
												</div>
												</div>
											</div>
											<div class="col col-xs-7">
												<div class="product-info">
												<h3 class="name"><a href="<?php the_permalink()?>"><?php the_title(); ?></a></h3>
												<div class="product-price">	
													<span class="price">
													<?php echo $product->get_price_html(); ?>					</span>
												</div>
												</div>
											</div>
											</div>
										</div>
										</div>
							
							<?php endwhile; wp_reset_query(); ?>
										
							</div>
						</div>

							<div class="item">
							<div class="products best-product">
								<?php
										$args = array( 'post_type' => 'product', 'posts_per_page' => 2, 'product_cat' => $pcategory_name, 'orderby' => 'DESC' ,'offset'     =>8);
										$loop = new WP_Query( $args );
										while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
									
									<div class="product">
										<div class="product-micro">
											<div class="row product-micro-row">
											<div class="col col-xs-5">
												<div class="product-image">
												<div class="image">
													<a href="<?php the_permalink()?>">
								<?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?>
								</a>					
												</div>
												</div>
											</div>
											<div class="col col-xs-7">
												<div class="product-info">
												<h3 class="name"><a href="<?php the_permalink()?>"><?php the_title(); ?></a></h3>
												<div class="product-price">	
													<span class="price">
													<?php echo $product->get_price_html(); ?>					</span>
												</div>
												</div>
											</div>
											</div>
										</div>
										</div>
							
							<?php endwhile; wp_reset_query(); ?>
										
							</div>
							</div>

			
						</div>
					</div>

					<?php  } else{
								echo '<h4 class="category-missing-message">Please select category from Theme Options => Homepage Product Category Settings => Product Category Two</h4>';
							}
							?>

				</div>

					<!-- Product Category Two 3 Column Close -->
					
					
					<!--  Widget Area Two -->
				<?php if ( is_active_sidebar( 'widget_02' ) ) : ?>

					<div class="wide-banners wow fadeInUp outer-bottom-xs">
						<div class="row">
						<div class="col-md-12">
							<div class="wide-banner cnt-strip">
							<div class="image">
								<?php dynamic_sidebar('widget_02'); ?>
							</div>
							</div>
						</div>
						</div>
					</div>
				<?php endif; ?>
	  
			<!--======= Product Category two end =======-->



			
          </div> <!-- col-md-9 end-->
		  
		     <!-- SIDEBAR  -->	
          
		  
		  <?php get_template_part('left-sideber');?>
		  
          <!-- SIDEBAR : END  -->
		  
        </div>
        
		
		
		
      </div>
    </div>
<?php get_footer();?>