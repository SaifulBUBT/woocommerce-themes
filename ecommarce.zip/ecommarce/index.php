<?php
//show_category_list();
 get_header(); 
 global $themesbazar; 
?>

    <!--  HEADER : END  -->
    <div class="body-content outer-top-xs" id="top-banner-and-menu">
      <div class="container">
        <div class="row">
       
          <!-- CONTENT -->
          <div class="col-xs-12 col-sm-12 col-md-9 homebanner-holder pull-right">


			<?php
				$homepage_layout = $themesbazar['homepage-section']['Show'];
				if ($homepage_layout): foreach ($homepage_layout as $key=>$value) {
					switch($key) {
						case 'slider': get_template_part( '/template-parts/home-page/slider' );
						break;
				
						case 'money-back-section': get_template_part( '/template-parts/home-page/money-back' );
						break;
				
						case 'category-gallery': get_template_part('/template-parts/home-page/category-gallery');
						break;
				
						case 'product-category-one': get_template_part('/template-parts/home-page/product-category-one');   
						break;  
						
						case 'product-category-two': get_template_part('/template-parts/home-page/product-category-two');   
						break; 
						
						case 'product-category-three': get_template_part('/template-parts/home-page/product-category-three');   
						break; 
								
						case 'product-category-four': get_template_part('/template-parts/home-page/product-category-four');   
						break; 
						
						case 'product-category-five': get_template_part('/template-parts/home-page/product-category-five');   
						break; 
						
						case 'product-category-six': get_template_part('/template-parts/home-page/product-category-six');   
						break;
						
						case 'product-category-seven': get_template_part('/template-parts/home-page/product-category-seven');   
						break; 
						
						case 'product-category-eight': get_template_part('/template-parts/home-page/product-category-eight');   
						break; 
						
						case 'product-category-nine': get_template_part('/template-parts/home-page/product-category-nine');   
						break;
						
						case 'product-category-ten': get_template_part('/template-parts/home-page/product-category-ten');   
						break; 
						
						case 'latest-blog': get_template_part('/template-parts/home-page/latest-blog');   
						break; 
					}
				}
				endif;
			?>

			
          </div>
		  
		     <!-- SIDEBAR  -->	
          
		  
		  <?php get_template_part('left-sideber');?>
		  
          <!-- SIDEBAR : END  -->
		  
        </div>
        
		
		
		
      </div>
    </div>
<?php get_footer();?>