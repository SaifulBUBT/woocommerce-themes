<?php global $themesbazar; ?>
<div class="col-xs-12 col-sm-12 col-md-3 sidebar pull-left">
      <!--  TOP NAVIGATION  -->
      <div class="side-menu animate-dropdown outer-bottom-xs">
        <div class="head"><i class="icon fa fa-align-justify fa-fw"></i> <?php echo $themesbazar['sidebar_menu']; ?></div>
        <nav class="yamm megamenu-horizontal" role="navigation">
              <?php /* Primary navigation */
                wp_nav_menu( array(
                    'theme_location' => 'sidebar-menu',
                'menu_class'    => 'nav navbar-nav',
                'fallback_cb' => 'default_main_menu',
                    'walker' => new wp_bootstrap_navwalker())
                );
                ?>
          </nav>
      </div>
			
	<!-- Sidebar Area Widget Top -->
    <div class="home-banner">
	
      <?php 
		if(is_shop()){
			dynamic_sidebar('left_sidebar_top'); 
		}
		?>
	  
    </div>

			
			<?php if($themesbazar['sidebar-one-show'] == 1 ): ?>
			<?php
        $id = (!empty($themesbazar['sidebar_one'])) ? $themesbazar['sidebar_one'] : 'empty';
        if($id != 'empty'){ 

				if( $term = get_term_by( 'id', $id, 'product_cat' ) ){
            $pcategory_name = $term->name;}
          $pcategory_name_link = get_category_link($id);
           $how_cat= $themesbazar['how_sidebar_one'];
				?>
            <div class="sidebar-widget hot-deals wow fadeInUp outer-bottom-xs">
              <h3 class="section-title"><a href="<?php echo esc_url($pcategory_name_link);?>"> <?php echo $pcategory_name;?></a></h3>
              <div class="owl-carousel sidebar-carousel custom-carousel owl-theme outer-top-ss">
                
				<?php
        $args = array( 'post_type' => 'product', 'posts_per_page' => $how_cat, 'product_cat' => $pcategory_name, 'orderby' => 'DESC'  );
        $loop = new WP_Query( $args );
        while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
		
				<div class="item">
                  <div class="products">
                    <div class="hot-deal-wrapper">
                      <div class="image">
                        <a href="<?php the_permalink()?>">
						  <?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?>
						  </a>
                      </div>
					  <?php if ( $product->is_on_sale() ) : ?>
                      <div class="sale-offer-tag"><span><?php woocommerce_show_product_sale_flash( $post, $product ); ?></span></div>
					  <?php endif; ?> 
                    </div>
                    <div class="product-info text-left m-t-20">
                      <h3 class="name"><a href="<?php the_permalink()?>"><?php the_title(); ?></a></h3>
                      <div class="product-price">	
                        <span class="price">
                        <?php echo $product->get_price_html(); ?>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
				<?php endwhile; wp_reset_query(); ?>
              </div>
            </div>

            <?php  } else{
              echo '<h4 class="category-missing-message">Please select category from Theme Options => Sidebar Content Settings => Sidebar Product Category One</h4>';
              }
              ?>

			<?php endif; ?>   

		<?php if($themesbazar['sidebar-one-show'] == 2 ): ?>
			<?php endif; ?>
			


            <!--  SPECIAL OFFER -->
			<?php if($themesbazar['sidebar-two-show'] == 1 ): ?>
			<?php
        $id = (!empty($themesbazar['sidebar_two'])) ? $themesbazar['sidebar_two'] : 'empty';
        if($id != 'empty'){ 
            if( $term = get_term_by( 'id', $id, 'product_cat' ) ){
                $pcategory_name = $term->name;}
                $pcategory_name_link = get_category_link($id);
            ?>
            <div class="sidebar-widget outer-bottom-small wow fadeInUp">
              <h3 class="section-title"><a href="<?php echo esc_url($pcategory_name_link);?>"> <?php echo $pcategory_name;?></a></h3>
              <div class="sidebar-widget-body outer-top-xs">
                <div class="owl-carousel sidebar-carousel special-offer custom-carousel owl-theme outer-top-xs">
                  
				  <div class="item">
                    
                      <?php
        $args = array( 'post_type' => 'product', 'posts_per_page' => 4, 'product_cat' => $pcategory_name, 'orderby' => 'DESC'  );
        $loop = new WP_Query( $args );
        while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
		<div class="products special-product">
					  <div class="product">
                        <div class="product-micro">
                          <div class="row product-micro-row">
                            <div class="col col-xs-5">
                              <div class="product-image">
                                <div class="image">
                                  <a href="<?php the_permalink()?>">
						  <?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?>
						  </a>					
                                </div>
                              </div>
                            </div>
                            <div class="col col-xs-7">
                              <div class="product-info">
                                <h3 class="name"><a href="<?php the_permalink()?>"><?php the_title(); ?></a></h3>
                                <div class="product-price">	
                                  <span class="price">
                                  <?php echo $product->get_price_html(); ?>				</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      </div>
                       <?php endwhile; wp_reset_query(); ?>
                      

                  </div>
                  <div class="item">
                    
                      <?php
        $args = array( 'post_type' => 'product', 'posts_per_page' => 4, 'product_cat' => $pcategory_name, 'orderby' => 'DESC','offset'     =>4  );
        $loop = new WP_Query( $args );
        while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
		<div class="products special-product">
					  <div class="product">
                        <div class="product-micro">
                          <div class="row product-micro-row">
                            <div class="col col-xs-5">
                              <div class="product-image">
                                <div class="image">
                                  <a href="<?php the_permalink()?>">
						  <?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?>
						  </a>					
                                </div>
                              </div>
                            </div>
                            <div class="col col-xs-7">
                              <div class="product-info">
                                <h3 class="name"><a href="<?php the_permalink()?>"><?php the_title(); ?></a></h3>
                                <div class="product-price">	
                                  <span class="price">
                                  <?php echo $product->get_price_html(); ?>				</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      </div>
                       <?php endwhile; wp_reset_query(); ?>
                      
                  </div>
                  <div class="item">
                      <?php
        $args = array( 'post_type' => 'product', 'posts_per_page' => 4, 'product_cat' => $pcategory_name, 'orderby' => 'DESC','offset'     =>8  );
        $loop = new WP_Query( $args );
        while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
		              <div class="products special-product">
					  <div class="product">
                        <div class="product-micro">
                          <div class="row product-micro-row">
                            <div class="col col-xs-5">
                              <div class="product-image">
                                <div class="image">
                                  <a href="<?php the_permalink()?>">
						  <?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?>
						  </a>					
                                </div>
                              </div>
                            </div>
                            <div class="col col-xs-7">
                              <div class="product-info">
                                <h3 class="name"><a href="<?php the_permalink()?>"><?php the_title(); ?></a></h3>
                                <div class="product-price">	
                                  <span class="price">
                                  <?php echo $product->get_price_html(); ?>				</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      </div>
                       <?php endwhile; wp_reset_query(); ?>
                     
                  </div>
                  
                  
                </div>
              </div>
            </div>
            <?php  } else{
              echo '<h4 class="category-missing-message">Please select category from Theme Options => Sidebar Content Settings => Sidebar Product Category Two</h4>';
              }
              ?>

			<?php endif; ?>   
		<?php if($themesbazar['sidebar-two-show'] == 2 ): ?>
			<?php endif; ?>



            <!-- SPECIAL DEALS  -->
			<?php if($themesbazar['sidebar-three-show'] == 1 ): ?>
			<?php
        $id = (!empty($themesbazar['sidebar_three'])) ? $themesbazar['sidebar_three'] : 'empty';
        if($id != 'empty'){ 
			  	if( $term = get_term_by( 'id', $id, 'product_cat' ) ){
            $pcategory_name = $term->name;}
             $pcategory_name_link = get_category_link($id);
             $how_cat= $themesbazar['how_sidebar_three'];
                ?>
            <div class="sidebar-widget outer-bottom-small wow fadeInUp">
              <h3 class="section-title"><a href="<?php echo esc_url($pcategory_name_link);?>"> <?php echo $pcategory_name;?></a></h3>
              <div class="sidebar-widget-body outer-top-xs">
                <div class="owl-carousel sidebar-carousel special-offer custom-carousel owl-theme outer-top-xs">
                  
				  <div class="item">
                      <?php
        $args = array( 'post_type' => 'product', 'posts_per_page' => $how_cat, 'product_cat' => $pcategory_name, 'orderby' => 'DESC'  );
        $loop = new WP_Query( $args );
        while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
		<div class="products special-product">
					  <div class="product" >
                        <div class="product-micro">
                          <div class="row product-micro-row">
                            <div class="col col-xs-5">
                              <div class="product-image">
                                <div class="image">
                                  <a href="<?php the_permalink()?>">
						  <?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?>
						  </a>				
                                </div>
                              </div>
                            </div>
                            <div class="col col-xs-7">
                              <div class="product-info">
                                <h3 class="name"><a href="<?php the_permalink()?>"><?php the_title(); ?></a></h3>
                                <div class="product-price">	
                                  <span class="price">
                                  <?php echo $product->get_price_html(); ?>				</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      </div>
<?php endwhile; wp_reset_query(); ?>
                  </div>
                </div>
              </div>
            </div>

            <?php  } else{
              echo '<h4 class="category-missing-message">Please select category from Theme Options => Sidebar Content Settings => Sidebar Product Category Three</h4>';
              }
              ?>

			<?php endif; ?>   
		<?php if($themesbazar['sidebar-three-show'] == 2 ): ?>
			<?php endif; ?>
			
			<?php if($themesbazar['facebook'] ==1 ): ?>
            <!--  Facebook  -->
            <div class="sidebar-widget newsletter wow fadeInUp outer-bottom-small">
               <h3 class="section-title"><?php echo $themesbazar['facebook-title']?></h3>
                 <div class="sidebar-widget-body outer-top-xs">
                      
                    <div class="fb-root">
                    <script>(function(d, s, id) {
                      var js, fjs = d.getElementsByTagName(s)[0];
                      if (d.getElementById(id)) return;
                      js = d.createElement(s); js.id = id;
                      js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5";
                      fjs.parentNode.insertBefore(js, fjs);
                    }(document, 'script', 'facebook-jssdk'));</script>
                    <div class="fb-page" data-href="<?php echo $themesbazar['facebook-link']['face-url']; ?>" data-width="<?php echo $themesbazar['facebook-width']?>" data-height="<?php echo $themesbazar['facebook-height']?>" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"></div>
                    
                    </div>
                 </div>
            </div>
			
			<?php endif; ?>
				   <?php if($themesbazar['facebook'] == 2 ): ?>
				   <?php endif; ?>
				     

				   <!-- SPECIAL DEALS  -->
			<?php if($themesbazar['sidebar-four-show'] == 1 ): ?>
			<?php
        $id = (!empty($themesbazar['sidebar_four'])) ? $themesbazar['sidebar_four'] : 'empty';
        if($id != 'empty'){ 
            if( $term = get_term_by( 'id', $id, 'product_cat' ) ){
                  $pcategory_name = $term->name;}
              $pcategory_name_link = get_category_link($id);
              $how_cat= $themesbazar['how_sidebar_four'];
            ?>
            <div class="sidebar-widget outer-bottom-small wow fadeInUp">
              <h3 class="section-title"><a href="<?php echo esc_url($pcategory_name_link);?>"> <?php echo $pcategory_name;?></a></h3>
              <div class="sidebar-widget-body outer-top-xs">
                <div class="owl-carousel sidebar-carousel special-offer custom-carousel owl-theme outer-top-xs">
                        
                <div class="item">
                                <?php
                  $args = array( 'post_type' => 'product', 'posts_per_page' => $how_cat, 'product_cat' => $pcategory_name, 'orderby' => 'DESC'  );
                  $loop = new WP_Query( $args );
                  while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
              <div class="products special-product">
					      <div class="product">
                        <div class="product-micro">
                          <div class="row product-micro-row">
                            <div class="col col-xs-5">
                              <div class="product-image">
                                <div class="image">
                                  <a href="<?php the_permalink()?>">
						  <?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?>
						  </a>				
                                </div>
                              </div>
                            </div>
                            <div class="col col-xs-7">
                              <div class="product-info">
                                <h3 class="name"><a href="<?php the_permalink()?>"><?php the_title(); ?></a></h3>
                                <div class="product-price">	
                                  <span class="price">
                                  <?php echo $product->get_price_html(); ?>				</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      </div>
                  <?php endwhile; wp_reset_query(); ?>
                  </div>
                </div>
              </div>
            </div>


            <?php  } else{
              echo '<h4 class="category-missing-message">Please select category from Theme Options => Sidebar Content Settings => Sidebar Product Category Four</h4>';
              }
              ?>
			<?php endif; ?>   
		<?php if($themesbazar['sidebar-four-show'] == 2 ): ?>
			<?php endif; ?>
			
			
			
			  <!-- sidebar blog  -->
			<?php if($themesbazar['sblog_show'] == 1 ): ?>
			<?php
			$category_name = get_the_category_by_id($themesbazar['sidebar_blog']);
			$category_name_link = get_category_link($themesbazar['sidebar_blog']);
				?>
            <div class="sidebar-widget outer-bottom-small wow fadeInUp">
              <h3 class="section-title"><a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a></h3>
              <?php
				  $how = $themesbazar['how_sideblog'];
					$themes_bazar = new WP_Query(array(
						'post_type' => 'post',
						'posts_per_page' => $how,
						'offset' => 0,
						'category_name' => $category_name,
					));
					while ($themes_bazar->have_posts()) : $themes_bazar->the_post(); ?>
			  <h3 class="sidebar_blgo"><i class="fa fa-caret-square-o-right"></i> <a href="<?php the_permalink()?>"><?php the_title() ?></a> </h3>

			  <?php endwhile?>
			  
            </div>
			<?php endif; ?>   
		<?php if($themesbazar['sblog_show'] == 2 ): ?>
			<?php endif; ?>
				   
				   
            <!--  Testimonials -->
			<?php if($themesbazar['testim_show'] ==1 ): ?>
        <div class="sidebar-widget  wow fadeInUp outer-top-vs ">
          <div id="advertisement" class="advertisement">
                <?php 
              $how_post= $themesbazar['how_testim'];
              $gallary = new WP_Query(array(
                'post_type' => 'testimonial',
                'posts_per_page' => $how_post,
                'offset'     =>0,
                'orderby'     =>'DESC',
              ));
              while($gallary->have_posts()) : $gallary->the_post(); ?>
                 <div class="item">
                    <div class="avatar"><?php the_post_thumbnail(); ?></div>
                    <div class="testimonials"><em>"</em> <?php the_content(); ?><em>"</em></div>
                    <div class="clients_author"><?php the_title()?>	</div>
                </div>
            <?php endwhile; 
              wp_reset_query( );
            ?>
                
          </div>
        </div>
			<?php endif; ?>   


        <!-- Sidebar Widget Area Bottom -->
        <div class="home-banner">
          <?php dynamic_sidebar('left_sidebar_bottom'); ?>
        </div>
      </div>