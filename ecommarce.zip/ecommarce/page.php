<?php
show_category_list();
?>

    <div class="breadcrumb">
      <div class="container">
        <div class="breadcrumb-inner">
          <ul class="list-inline list-unstyled">
            <li><a href="<?php echo bloginfo('url')?>">Home</a></li>
            <li class='active'><?php the_title()?></li>
          </ul>
        </div>
        <!-- /.breadcrumb-inner -->
      </div>
      <!-- /.container -->
    </div>
    <!-- /.breadcrumb -->
    <div class="body-content">
      <div class="container">
        <div class="row">
          <div class="blog-page">
            <div class="col-md-9">

			<?php
			while ( have_posts() ) : the_post(); ?>

              <div class="blog-post  wow fadeInUp">
                <h1><a href="<?php the_permalink();?>"><?php the_title();?></a></h1>
                <?php the_content(); ?>
              </div>

			<?php endwhile; // End of the loop.
			?>		  
            </div>
			
			<?php get_template_part('right-sideber');?>
            
          </div>
        </div>
       	
      </div>
    </div>
<?php get_footer();?>