<?php global $themesbazar ?>
<div class="col-md-3 sidebar">
              <div class="sidebar-module-container">
                
               <?php if($themesbazar['facebook'] ==1 ): ?>
            <!--  Facebook  -->
            <div class="sidebar-widget newsletter wow fadeInUp outer-bottom-small">
              <h3 class="section-title"><?php echo $themesbazar['facebook-title']?></h3>
              <div class="sidebar-widget-body outer-top-xs">
               
			   <div class="fb-root">
				<script>(function(d, s, id) {
				  var js, fjs = d.getElementsByTagName(s)[0];
				  if (d.getElementById(id)) return;
				  js = d.createElement(s); js.id = id;
				  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5";
				  fjs.parentNode.insertBefore(js, fjs);
				}(document, 'script', 'facebook-jssdk'));</script>
				<div class="fb-page" data-href="<?php echo $themesbazar['facebook-link']['face-url']; ?>" data-width="<?php echo $themesbazar['facebook-width']?>" data-height="<?php echo $themesbazar['facebook-height']?>" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"></div>
			   
              </div>
            </div>
            </div>
			
			<?php endif; ?>
				   <?php if($themesbazar['facebook'] == 2 ): ?>
				   <?php endif; ?>
				   
				   
				  <?php dynamic_sidebar('right_sidebar'); ?> 
				   
                				
              </div>
            </div>