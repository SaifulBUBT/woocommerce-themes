<?php
show_category_list();
?>

    <div class="breadcrumb">
      <div class="container">
        <div class="breadcrumb-inner">
          <ul class="list-inline list-unstyled">
            <li><a href="<?php echo bloginfo('url')?>">Home</a></li>
            <li class='active'><?php the_title()?></li>
          </ul>
        </div>
        <!-- /.breadcrumb-inner -->
      </div>
      <!-- /.container -->
    </div>
    <!-- /.breadcrumb -->
    <div class="body-content">
      <div class="container">
        <div class="row">
          <div class="blog-page">
            <div class="col-md-9">

				<?php
					global $query_string;
					$query_args = explode("&", $query_string);
					$search_query = array();

					foreach($query_args as $key => $string) {
					  $query_split = explode("=", $string);
					  $search_query[$query_split[0]] = urldecode($query_split[1]);
					} // foreach

					$the_query = new WP_Query($search_query);
					if ( $the_query->have_posts() ) : 
					?>
					<!-- the loop -->

				   
					<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
									  <?php $word = $themesbazar['word-archive']; ?>
								
								
								<div class="archive_page archive_back">
							<div class="col-md-4 ">
								<!-- Post Image Code Start--> 
									<?php if(has_post_thumbnail()){ 
										the_post_thumbnail();}
									else{?>
									<img src="<?php echo get_template_directory_uri(); ?>/images/noimage.gif" width="100%" />
									<?php } ?>
									<!-- Post Image Code Close-->
									
							</div>
							<div class="col-md-8">
								<h3 class="archive_title01"><a href="<?php the_permalink(); ?>"><?php the_title();?> </a></h3>
											
									   <?php echo excerpt($word); ?> <h4 class="archvie_more"><a href="<?php the_permalink();?>"><?php echo $themesbazar['read-more-archive']?></a></h4>
									   
							</div>
						</div>
					<?php endwhile; ?>

					<!-- end of the loop -->

					<?php wp_reset_postdata(); ?>

				<?php else : ?>
					<p><?php _e( 'Sorry, no posts Found, Please Try Again.' ); ?></p>
				<?php endif; ?>   
								
								
						
						</br></br></br>
						
						
			
				  
            </div>
			
		
            
          </div>
        </div>
       	
      </div>
    </div>
<?php get_footer();?>