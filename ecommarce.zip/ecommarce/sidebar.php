<?php global $themesbazar; ?>

            <!--  TOP NAVIGATION  -->
            <div class="side-menu animate-dropdown outer-bottom-xs">
              <div class="head"><i class="icon fa fa-align-justify fa-fw"></i> <?php echo $themesbazar['sidebar_menu']; ?></div>
              <nav class="yamm megamenu-horizontal" role="navigation">
                <?php /* Primary navigation */
		        wp_nav_menu( array(
		           'theme_location' => 'sidebar-menu',
				   'menu_class'    => 'nav navbar-nav',
				   'fallback_cb' => 'default_main_menu',
		           'walker' => new wp_bootstrap_navwalker())
		              );
	               	?>
              </nav>
            </div>
			
	<!-- Sidebar Area Widget Top -->
            <div class="home-banner">
              <?php dynamic_sidebar('left_sidebar_top'); ?>
            </div>
			
			
			
			
			<?php if($themesbazar['facebook'] ==1 ): ?>
            <!--  Facebook  -->
            <div class="sidebar-widget newsletter wow fadeInUp outer-bottom-small">
              <h3 class="section-title"><?php echo $themesbazar['facebook-title']?></h3>
              <div class="sidebar-widget-body outer-top-xs">
               
			   <div class="fb-root">
				<script>(function(d, s, id) {
				  var js, fjs = d.getElementsByTagName(s)[0];
				  if (d.getElementById(id)) return;
				  js = d.createElement(s); js.id = id;
				  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5";
				  fjs.parentNode.insertBefore(js, fjs);
				}(document, 'script', 'facebook-jssdk'));</script>
				<div class="fb-page" data-href="<?php echo $themesbazar['facebook-link']['face-url']; ?>" data-width="<?php echo $themesbazar['facebook-width']?>" data-height="<?php echo $themesbazar['facebook-height']?>" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"></div>
			   
              </div>
            </div>
            </div>
			
			<?php endif; ?>
				   <?php if($themesbazar['facebook'] == 2 ): ?>
				   <?php endif; ?>
				   
				   
				   
				  
            <!--  Testimonials -->
			<?php if($themesbazar['testim_show'] ==1 ): ?>
            <div class="sidebar-widget  wow fadeInUp outer-top-vs ">
              <div id="advertisement" class="advertisement">
                <?php 
							$how_post= $themesbazar['how_testim'];
							$gallary = new WP_Query(array(
								'post_type' => 'testimonial',
								'posts_per_page' => $how_post,
								'offset'     =>0,
								'orderby'     =>'DESC',
							));
							while($gallary->have_posts()) : $gallary->the_post(); ?>
				<div class="item">
                  <div class="avatar"><?php the_post_thumbnail(); ?></div>
                  <div class="testimonials"><em>"</em> <?php the_content(); ?><em>"</em></div>
                  <div class="clients_author"><?php the_title()?>	</div>
                </div>
       <?php endwhile ?>
                
              </div>
            </div>
			<?php endif; ?>   
		<?php if($themesbazar['testim_show'] == 2 ): ?>
			<?php endif; ?>
