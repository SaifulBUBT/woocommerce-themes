<?php  global $themesbazar; ?>        
		<!--  BLOG SLIDER  -->

            <section class="section latest-blog outer-bottom-vs wow fadeInUp">
              <h3 class="section-title"><a href="#"> <?php esc_html_e( 'Latest Posts', 'ecommerce' ); ?> </a></h3>
              <div class="blog-slider-container outer-top-xs">
                <div class="owl-carousel blog-slider custom-carousel">
                  <?php
					$themes_bazar = new WP_Query(array(
						'post_type' => 'post',
						'posts_per_page' => -1,
						'offset' => 0,
						'category_name' => $category_name,
					));
					while ($themes_bazar->have_posts()) : $themes_bazar->the_post(); ?>
				  <div class="item">
                    <div class="blog-post">
                      <div class="blog-post-image">
                        <div class="image">
                          <a href="<?php the_permalink();?>"><?php the_post_thumbnail();?></a>
                        </div>
                      </div>
                      <div class="blog-post-info text-left">
                        <h3 class="name"><a href="<?php the_permalink()?>"><?php the_title() ?></a></h3>
                        <span class="info">
						
<?php 
$currentDate = get_the_time("l, j F, Y");
$engDATE = array(1,2,3,4,5,6,7,8,9,0,'january','February','March','April','May','June','July','August','September','October','November','December','Saturday','Sunday','Monday','Tuesday','Wednesday','Thursday','Friday');
$bangDATE = array('১','২','৩','৪','৫','৬','৭','৮','৯','০','জানুয়ারী','ফেব্রুয়ারী','মার্চ','এপ্রিল','মে','জুন','জুলাই','আগস্ট','সেপ্টেম্বর','অক্টোবর','নভেম্বর','ডিসেম্বর','শনিবার','রবিবার','সোমবার','মঙ্গলবার','
বুধবার','বৃহস্পতিবার','শুক্রবার' 
);
$convertedDATE = str_replace($engDATE, $bangDATE, $currentDate);
echo "$convertedDATE";
?>
<?php echo get_the_time("l, F j, Y"); ?>
							
							</span>
                        <p class="text"><?php the_excerpt(); ?></p>
                        <a href="<?php the_permalink();?>" class="lnk btn btn-primary"><?php esc_html_e( 'Read More', 'ecommerce' ); ?></a>
                      </div>
                    </div>
                  </div>
        <?php endwhile; 
          wp_reset_query( );
        ?>
                  
                </div>
              </div>
            </section>
			
