	<?php  global $themesbazar; ?>
	<div class="info-boxes wow fadeInUp hidden-xs">
	  <div class="info-boxes-inner">
		<div class="row">
		
		  <div class="col-md-6 col-sm-4 col-lg-4">
			<div class="info-box">
			  <div class="row">
				<div class="col-xs-12">
				  <h4 class="info-box-heading green"><?php echo $themesbazar['money_title'] ?></h4>
				</div>
			  </div>
			  <h6 class="text"><?php echo $themesbazar['money_desc'] ?></h6>
			</div>
		  </div>

		  <div class="hidden-md col-sm-4 col-lg-4">
			<div class="info-box">
			  <div class="row">
				<div class="col-xs-12">
				  <h4 class="info-box-heading green"><?php echo $themesbazar['free_title'] ?></h4>
				</div>
			  </div>
			  <h6 class="text"><?php echo $themesbazar['free_desc'] ?></h6>
			</div>
		  </div>

		  <div class="col-md-6 col-sm-4 col-lg-4">
			<div class="info-box">
			  <div class="row">
				<div class="col-xs-12">
				  <h4 class="info-box-heading green"><?php echo $themesbazar['special_title'] ?></h4>
				</div>
			  </div>
			  <h6 class="text"><?php echo $themesbazar['special_desc'] ?> </h6>
			</div>
		  </div>

		</div>
	  </div>
	</div>

