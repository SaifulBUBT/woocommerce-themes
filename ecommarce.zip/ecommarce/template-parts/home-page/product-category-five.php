			
<?php  global $themesbazar; ?>      
   <!-- Product Category Five  -->			
   <section class="section featured-product wow fadeInUp">
			<?php
        $id = (!empty($themesbazar['product_five'])) ? $themesbazar['product_five'] : 'empty';

        if($id != 'empty'){ 
          if( $term = get_term_by( 'id', $id, 'product_cat' ) ){
              $pcategory_name = $term->name;}
          $pcategory_name_link = get_category_link($id);

				?>
        <h3 class="section-title"><a href="<?php echo esc_url($pcategory_name_link);?>"> <?php echo $pcategory_name;?></a></h3>
        <div class="owl-carousel home-owl-carousel custom-carousel owl-theme outer-top-xs">
          <?php
          $args = array( 'post_type' => 'product', 'posts_per_page' => -1, 'product_cat' => $pcategory_name, 'orderby' => 'DESC'  );
          $loop = new WP_Query( $args );
          while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
          
			    	<div class="item item-carousel">
                <div class="products">
                    <div class="product">
                      <div class="product-image">
                        <div class="image">
                          <a href="<?php the_permalink()?>">
						  <?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?>
						  </a>
                        </div>
						<?php if ( $product->is_on_sale() ) : ?>
                 <div class="tag new"><span><?php woocommerce_show_product_sale_flash( $post, $product ); ?></span></div>
				 <?php endif; ?>
                      </div>
                      <div class="product-info text-left">
                        <h3 class="name"><a href="<?php the_permalink()?>"><?php the_title(); ?></a></h3>
						  
                        <div class="description"></div>
                        <div class="product-price">		
                          <span class="price">
                          <?php echo $product->get_price_html(); ?>				</span>
                          
                        </div>
                      </div>
                      
                    </div>
                  </div>
              </div>
                
               <?php endwhile; wp_reset_query(); ?>
                
              </div>

              <?php  } else{
              echo '<h4 class="category-missing-message">Please select category from Theme Options => Homepage Product Category Settings => Product Category Five</h4>';
              }
              ?>
    </section>
			
    <!--  Widget Area One -->
    <?php if ( is_active_sidebar( 'widget_05' ) ) : ?>

    <div class="wide-banners wow fadeInUp outer-bottom-xs">
      <div class="row">
        <div class="col-md-12">
          <div class="wide-banner cnt-strip">
            <div class="image">
              <?php dynamic_sidebar('widget_05'); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php endif; ?>