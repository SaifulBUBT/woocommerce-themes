<?php  global $themesbazar; ?>	
  <!-- Product Category Six 3 Column -->
    <div class="best-deal wow fadeInUp outer-bottom-xs">
			<?php
          $id = (!empty($themesbazar['product_six'])) ? $themesbazar['product_six'] : 'empty';  
          if($id != 'empty'){ 
          if( $term = get_term_by( 'id', $id, 'product_cat' ) ){
           $pcategory_name = $term->name;}
           $pcategory_name_link = get_category_link($id);
          ?>
          <h3 class="section-title"><a href="<?php echo esc_url($pcategory_name_link);?>"> <?php echo $pcategory_name;?></a></h3>
          <div class="sidebar-widget-body outer-top-xs">
            <div class="owl-carousel best-seller custom-carousel owl-theme outer-top-xs">
              
              <div class="item">
                  <div class="products best-product">
                  <?php
                    $args = array( 'post_type' => 'product', 'posts_per_page' => 2, 'product_cat' => $pcategory_name, 'orderby' => 'DESC' );
                    $loop = new WP_Query( $args );
                    while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
                
                    <div class="product">
                        <div class="product-micro">
                          <div class="row product-micro-row">
                            <div class="col col-xs-5">
                              <div class="product-image">
                                <div class="image">
                                  <a href="<?php the_permalink()?>">
              <?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?>
              </a>					
                                </div>
                              </div>
                            </div>
                            <div class="col2 col-xs-7">
                              <div class="product-info">
                                <h3 class="name"><a href="<?php the_permalink()?>"><?php the_title(); ?></a></h3>
                                <div class="product-price">	
                                  <span class="price">
                                    <?php echo $product->get_price_html(); ?>					</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    <?php endwhile; wp_reset_query(); ?>
                    
                  </div>
              </div>

              <div class="item">
                <div class="products best-product">
                  <?php
                  $args = array( 'post_type' => 'product', 'posts_per_page' => 2, 'product_cat' => $pcategory_name, 'orderby' => 'DESC' ,'offset'     =>2 );
                  $loop = new WP_Query( $args );
                  while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
              
					         <div class="product">
                      <div class="product-micro">
                        <div class="row product-micro-row">
                          <div class="col col-xs-5">
                            <div class="product-image">
                              <div class="image">
                                <a href="<?php the_permalink()?>">
            <?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?>
            </a>					
                              </div>
                            </div>
                          </div>
                          <div class="col2 col-xs-7">
                            <div class="product-info">
                              <h3 class="name"><a href="<?php the_permalink()?>"><?php the_title(); ?></a></h3>
                              <div class="product-price">	
                                <span class="price">
                                  <?php echo $product->get_price_html(); ?>					</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
					  
					         <?php endwhile; wp_reset_query(); ?>
                      
              </div>
            </div>
      
            <div class="item">
              <div class="products best-product">
                <?php
                  $args = array( 'post_type' => 'product', 'posts_per_page' => 2, 'product_cat' => $pcategory_name, 'orderby' => 'DESC' ,'offset'     =>4 );
                  $loop = new WP_Query( $args );
                  while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
              
					        <div class="product">
                    <div class="product-micro">
                      <div class="row product-micro-row">
                        <div class="col col-xs-5">
                          <div class="product-image">
                            <div class="image">
                              <a href="<?php the_permalink()?>">
          <?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?>
          </a>					
                            </div>
                          </div>
                        </div>
                        <div class="col2 col-xs-7">
                          <div class="product-info">
                            <h3 class="name"><a href="<?php the_permalink()?>"><?php the_title(); ?></a></h3>
                            <div class="product-price">	
                              <span class="price">
                                <?php echo $product->get_price_html(); ?>					</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
					  
					       <?php endwhile; wp_reset_query(); ?>
                      
              </div>
            </div>

            <div class="item">
              <div class="products best-product">
                <?php
              $args = array( 'post_type' => 'product', 'posts_per_page' => 2, 'product_cat' => $pcategory_name, 'orderby' => 'DESC' ,'offset'     =>6 );
              $loop = new WP_Query( $args );
              while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>

					      <div class="product">
                    <div class="product-micro">
                      <div class="row product-micro-row">
                        <div class="col col-xs-5">
                          <div class="product-image">
                            <div class="image">
                              <a href="<?php the_permalink()?>">
          <?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?>
          </a>					
                            </div>
                          </div>
                        </div>
                        <div class="col2 col-xs-7">
                          <div class="product-info">
                            <h3 class="name"><a href="<?php the_permalink()?>"><?php the_title(); ?></a></h3>
                            <div class="product-price">	
                              <span class="price">
                                <?php echo $product->get_price_html(); ?>					</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
					  
					        <?php endwhile; wp_reset_query(); ?>
                      
            </div>
          </div>

				  <div class="item">
             <div class="products best-product">
              <?php
              $args = array( 'post_type' => 'product', 'posts_per_page' => 2, 'product_cat' => $pcategory_name, 'orderby' => 'DESC' ,'offset'     =>8);
              $loop = new WP_Query( $args );
              while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
          
					     <div class="product">
                  <div class="product-micro">
                    <div class="row product-micro-row">
                      <div class="col col-xs-5">
                        <div class="product-image">
                          <div class="image">
                            <a href="<?php the_permalink()?>">
        <?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?>
        </a>					
                          </div>
                        </div>
                      </div>
                      <div class="col2 col-xs-7">
                        <div class="product-info">
                          <h3 class="name"><a href="<?php the_permalink()?>"><?php the_title(); ?></a></h3>
                          <div class="product-price">	
                            <span class="price">
                              <?php echo $product->get_price_html(); ?>					</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
					  
					       <?php endwhile; wp_reset_query(); ?>
                      
            </div>
          </div>
    </div>
  </div>

  <?php  } else{
      echo '<h4 class="category-missing-message">Please select category from Theme Options => Homepage Product Category Settings => Product Category Six</h4>';
    }
    ?>
</div>

			<!-- Product Category Two 3 Column Close -->
			
			
  <!--  Widget Area Two -->
  <?php if ( is_active_sidebar( 'widget_06' ) ) : ?>
  <div class="wide-banners wow fadeInUp outer-bottom-xs">
    <div class="row">
      <div class="col-md-12">
        <div class="wide-banner cnt-strip">
          <div class="image">
            <?php dynamic_sidebar('widget_06'); ?>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php endif; ?>
