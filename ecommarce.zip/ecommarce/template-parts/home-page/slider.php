<?php  global $themesbazar; ?>

<!-- SECTION – HERO -->
<div id="hero">
  <div id="owl-main" class="owl-carousel owl-inner-nav owl-ui-sm">
	
		<?php 
			$how_post= $themesbazar['how_many_slide'];
			$gallary = new WP_Query(array(
				'post_type' => 'slides',
				'posts_per_page' => $how_post,
				'orderby'     => 'DESC',
			));
			if($gallary->have_posts()):
			while($gallary->have_posts()) : $gallary->the_post(); ?>	
				<?php $backgroundImg = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'full' ); 
		?>
			
				<div class="item" style="background: url(<?php echo $backgroundImg[0] ?>) no-repeat;
			background-position:center;" width="100%">
				<div class="container-fluid">
					<div class="caption bg-color vertical-center text-left">
					<div class="big-text fadeInDown-1">
						<?php the_title();?>
					</div>
					<div class="excerpt fadeInDown-2 hidden-xs">
						<span><?php the_content(); ?></span>
					</div>

					</div>
				</div>
				</div>
		<?php 
			endwhile;
			wp_reset_query();
		else: ?>
		   <img src="<?php echo get_template_directory_uri( ); ?>/assets/images/cat-banner-1.jpg" />

		<?php endif; ?>
  </div>
</div>
<!-- INFO BOXES  -->