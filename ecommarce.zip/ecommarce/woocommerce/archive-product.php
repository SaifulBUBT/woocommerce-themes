<?php

/**
 * The Template for displaying product archives, including the main shop page which is a post type archive
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/archive-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce/Templates
 * @version 3.4.0
 */

defined('ABSPATH') || exit;

get_header('shop');

?>
<div class="breadcrumb">
  <div class="container">
    <div class="breadcrumb-inner">
      <!-- <ul class="list-inline list-unstyled">
        <li><a href="<?php echo home_url('/'); ?>">Home</a></li>
        <li class='active'>Shop</li>
      </ul> -->
      <?php woocommerce_breadcrumb(); ?>
    </div>
    <!-- /.breadcrumb-inner -->
  </div>
  <!-- /.container -->
</div>
<!-- /.breadcrumb -->

<div class="body-content outer-top-xs">
  <div class='container'>
    <div class='row'>


      <div class="col-md-9 pull-right">



        <div class="clearfix filters-container">
          <div class="row">
            <div class="col col-sm-4 col-md-2">
              <div class="filter-tabs">
                
                <ul id="filter-tabs" class="nav nav-tabs nav-tab-box nav-tab-fa-icon">
                  <li class="active">
                    <a href="#" id="grid" title="Grid view"><i class="icon fa fa-th-large"></i><?php esc_html_e( 'Grid', 'e_store' ); ?></a>
                  </li>
                  <li class="">
                  <a href="#" id="list" title="List view"><i class="icon fa fa-th-list"></i>List</a></li>
                </ul>

              </div>
              <!-- /.filter-tabs -->
            </div>
            <!-- /.col -->
            <div class="col col-sm-8 col-md-7">
              <div class="col col-sm-8 col-md-8 no-padding">
                <div class="lbl-cnt"> <span class="lbl">Sort by</span>
                  <div class="fld inline">
                    <?php woocommerce_catalog_ordering(); ?>
                  </div>
                  <!-- /.fld -->
                </div>
                <!-- /.lbl-cnt -->
              </div>
              <!-- /.col -->
              <div class="col col-sm-4 col-md-4 no-padding">

                <!-- <div class="lbl-cnt"> <span class="lbl">Show</span>
                  <div class="fld inline">
                    <div class="dropdown dropdown-small dropdown-med dropdown-white inline">
                      <button data-toggle="dropdown" type="button" class="btn dropdown-toggle"> 1 <span class="caret"></span> </button>
                      <ul role="menu" class="dropdown-menu">
                        <li role="presentation"><a href="#">1</a></li>
                        <li role="presentation"><a href="#">2</a></li>
                        <li role="presentation"><a href="#">3</a></li>
                        <li role="presentation"><a href="#">4</a></li>
                        <li role="presentation"><a href="#">5</a></li>
        
                    </div>
                  </div>
                </div> -->


                <?php e_store_woocommerce_catalog_page_ordering(); ?>
             
              </div>
              <!-- /.col -->
            </div>
            <!-- /.col -->
            <div class="col col-sm-6 col-md-3 text-right">
                <!-----
              <div class="pagination-container">
                <ul class="list-inline list-unstyled">
                  <li class="prev"><a href="#"><i class="fa fa-angle-left"></i></a></li>
                  <li><a href="#">1</a></li>
                  <li class="active"><a href="#">2</a></li>
                  <li><a href="#">3</a></li>
                  <li><a href="#">4</a></li>
                  <li class="next"><a href="#"><i class="fa fa-angle-right"></i></a></li>
                </ul>
              </div> --->

              <?php //woo_e_store_pagination(); ?>

              <!-- /.pagination-container -->
            </div>
            <!-- /.col -->
          </div>
          <!-- /.row -->
        </div>


        <div class="search-result-container ">
          <div id="myTabContent" class="tab-content category-list">
            <div class="tab-pane active " id="grid-container">
              <?php

              /**
               * Hook: woocommerce_before_main_content.
               *
               * @hooked woocommerce_output_content_wrapper - 10 (outputs opening divs for the content)
               * @hooked woocommerce_breadcrumb - 20
               * @hooked WC_Structured_Data::generate_website_data() - 30
               */
              do_action('woocommerce_before_main_content');

              ?>
              <header class="woocommerce-products-header">
                <?php if (apply_filters('woocommerce_show_page_title', false)) : ?>
                  <h1 class="woocommerce-products-header__title page-title"><?php woocommerce_page_title(); 
                                                                              ?></h1>
                <?php endif; ?>

                <?php
                /**
                 * Hook: woocommerce_archive_description.
                 *
                 * @hooked woocommerce_taxonomy_archive_description - 10
                 * @hooked woocommerce_product_archive_description - 10
                 */
                do_action('woocommerce_archive_description');
                ?>
              </header>
              <?php
              if (woocommerce_product_loop()) {

                /**
                 * Hook: woocommerce_before_shop_loop.
                 *
                 * @hooked woocommerce_output_all_notices - 10
                 * @hooked woocommerce_result_count - 20
                 * @hooked woocommerce_catalog_ordering - 30
                 */
                do_action('woocommerce_before_shop_loop');

                woocommerce_product_loop_start();

                if (wc_get_loop_prop('total')) {
                  while (have_posts()) {
                    the_post();

                    /**
                     * Hook: woocommerce_shop_loop.
                     *
                     * @hooked WC_Structured_Data::generate_product_data() - 10
                     */
                    do_action('woocommerce_shop_loop');

                    wc_get_template_part('content', 'product');
                  }
                }

                woocommerce_product_loop_end();

                /**
                 * Hook: woocommerce_after_shop_loop.
                 *
                 * @hooked woocommerce_pagination - 10
                 */
                do_action('woocommerce_after_shop_loop');
              } else {
                /**
                 * Hook: woocommerce_no_products_found.
                 *
                 * @hooked wc_no_products_found - 10
                 */
                do_action('woocommerce_no_products_found');
              }

              /**
               * Hook: woocommerce_after_main_content.
               *
               * @hooked woocommerce_output_content_wrapper_end - 10 (outputs closing divs for the content)
               */
              do_action('woocommerce_after_main_content');

              ?>
           
                <div class="text-right">
                  <?php woo_e_store_pagination(); ?>
               </div>

        
              <?php
              /**
               * Hook: woocommerce_sidebar.
               *
               * @hooked woocommerce_get_sidebar - 10
               */



               
              ?>
            </div>
          </div>
        </div>
      </div>

      <div class="col-md-3 col-xs-12 col-sm-12 sidebar pull-left">
        <?php do_action('woocommerce_sidebar');
        ?>
        <? php // get_sidebar(); 
        ?>
      </div>
      
    </div>
  </div>
</div>
<?php
get_footer('shop');
