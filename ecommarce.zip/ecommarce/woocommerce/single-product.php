<?php

/**
 * The Template for displaying all single products
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */

if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

get_header('shop'); ?>
	<div class="breadcrumb">
	  <div class="container">
		<div class="breadcrumb-inner">
		  <!-- <ul class="list-inline list-unstyled">
			<li><a href="<?php echo home_url('/'); ?>">Home</a></li>
			<li class='active'>Shop</li>
		  </ul> -->
		  <?php woocommerce_breadcrumb(); ?>
		</div>
		<!-- /.breadcrumb-inner -->
	  </div>
	  <!-- /.container -->
	</div>
	<!-- /.breadcrumb -->
	
<div class="body-content outer-top-xs">
	<div class='container'>
		<div class='row single-product'>


			<div class="col-md-9 pull-right">
				<div class="detail-block">

					<?php
					/**
					 * woocommerce_before_main_content hook.
					 *
					 * @hooked woocommerce_output_content_wrapper - 10 (outputs opening divs for the content)
					 * @hooked woocommerce_breadcrumb - 20
					 */
					do_action('woocommerce_before_main_content');
					?>

					<?php while (have_posts()) : the_post(); ?>

						<?php wc_get_template_part('content', 'single-product'); ?>

					<?php endwhile; // end of the loop. 
					?>

					<?php
					/**
					 * woocommerce_after_main_content hook.
					 *
					 * @hooked woocommerce_output_content_wrapper_end - 10 (outputs closing divs for the content)
					 */
					do_action('woocommerce_after_main_content');
					?>

				</div>

				<div class="product-tabs inner-bottom-xs  wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">
					<?php woocommerce_output_product_data_tabs(); ?>
				</div>

				<div class="section featured-product wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">
					<?php woocommerce_output_related_products(); ?>
				</div>

			</div>

			<div class="col-md-3 col-xs-12 col-sm-12 sidebar pull-left">
				<?php do_action('woocommerce_sidebar');?>
			
			</div>

		</div>
	</div>
</div>

<?php get_footer('shop');

/* Omit closing PHP tag at the end of PHP files to avoid "headers already sent" issues. */
