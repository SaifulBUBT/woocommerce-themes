<?php
/**
 * Template Name: Contact Us  Template
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package e_store
 */

get_header();
?>
<?php  global $themesbazar; ?>



    <!-- /.breadcrumb -->
<div class="contact-page-content">
	<div class="container">
		<div class="row">
				    <div class="col-md-12">
                        <?php
                        while ( have_posts() ) :
                            the_post();

                            the_content();

                        endwhile; // End of the loop.
                        ?>

                    </div>
                    
                    <div class="col-md-12 contact-map">
                           <!-- <iframe src="<?php echo $themesbazar['google-map']; ?>" width="600" height="450"  style="border:0"></iframe> -->
                           <?php echo $themesbazar['google-map']; ?>
                     </div>

                     <div class="col-md-9 contact-form">
                
                            <h4><?php esc_html_e( 'Contact Form', 'e_store' ); ?></h4>
                        
                        
                        <?php
                        if ( is_plugin_active( 'contact-form-7/wp-contact-form-7.php' ) ):

                                if(!empty($themesbazar['contact-form-shortcode'])):
                                echo do_shortcode($themesbazar['contact-form-shortcode']);
                                else:
                                    echo 'copy shortcode from contact form and paste into theme options contact page settings';
                                    endif;  
                            else:
                            echo '<h4>Contact form 7 is not active. please active the plugin and paste the following codes. </h4>
<xmp>
    <div class="col-md-4 ">                        
        <div class="form-group">
            <label class="info-title" for="exampleInputName">Your Name <span>*</span></label>
            [text* text-448 id:exampleInputName class:form-control class:unicase-form-control class:text-input]                      
        </div>                              
    </div>

    <div class="col-md-4 ">                        
        <div class="form-group">
            <label class="info-title" for="exampleInputEmail1">Email Address <span>*</span></label>
        [email* email-50 id:exampleInputEmail1 class:form-control class:unicase-form-control class:text-input]                     
        </div>                              
    </div>

    <div class="col-md-4 ">                        
        <div class="form-group">
            <label class="info-title" for="exampleInputTitle">Subject <span>*</span></label>
            [text* text-449 id:exampleInputName class:form-control class:unicase-form-control class:text-input]                
        </div>                              
    </div>

    <div class="col-md-12 ">                        
        <div class="form-group">
            <label class="info-title" for="exampleInputComments">Your Message <span>*</span></label>
            [textarea* textarea-844 id:exampleInputComments class:form-control class:unicase-form-control]                
        </div>                              
    </div>

    [submit class:btn-upper class:btn class:btn-primary class:checkout-page-button "Send Message"]
</xmp>
                            '; 
                         
                        endif;
                        ?>

                        <!-- <form class="register-form" role="form">
                            <div class="col-md-4 ">
                                
                                    <div class="form-group">
                                    <label class="info-title" for="exampleInputName">Your Name <span>*</span></label>
                                    <input type="email" class="form-control unicase-form-control text-input" id="exampleInputName" placeholder="">
                                </div>
                                
                            </div>
                            <div class="col-md-4">
                                    <div class="form-group">
                                    <label class="info-title" for="exampleInputEmail1">Email Address <span>*</span></label>
                                    <input type="email" class="form-control unicase-form-control text-input" id="exampleInputEmail1" placeholder="">
                                </div>
                            </div>
                            <div class="col-md-4">
                                    <div class="form-group">
                                    <label class="info-title" for="exampleInputTitle">Title <span>*</span></label>
                                    <input type="email" class="form-control unicase-form-control text-input" id="exampleInputTitle" placeholder="Title">
                                </div>
                            </div>
                            <div class="col-md-12">
                                    <div class="form-group">
                                    <label class="info-title" for="exampleInputComments">Your Comments <span>*</span></label>
                                    <textarea class="form-control unicase-form-control" id="exampleInputComments"></textarea>
                                </div>
                            </div>
                            <div class="col-md-12 outer-bottom-small m-t-20">
                                <button type="submit" class="btn-upper btn btn-primary checkout-page-button">Send Message</button>
                            </div>
                        </form> -->

                    </div>

                    <div class="col-md-3 contact-info">
                        <div class="contact-title">
                            <h4><?php esc_html_e( 'Contact Information', 'e_store' ); ?></h4>
                        </div>

                        <?php if (($themesbazar['address'])) :?>
                            <div class="clearfix address">
                                <span class="contact-i"><i class="fa fa-map-marker"></i></span>
                                <span class="contact-span"><?php echo $themesbazar['address']; ?></span>
                            </div>
                        <?php endif; ?>   

                        <?php if (($themesbazar['phone'])) :?>
                            <div class="clearfix phone-no">
                                <span class="contact-i"><i class="fa fa-mobile"></i></span>
                                <span class="contact-span"><?php echo $themesbazar['phone']; ?></span>
                            </div>
                        <?php endif; ?>

                        <?php if (($themesbazar['email'])) :?>
                            <div class="clearfix email">
                                <span class="contact-i"><i class="fa fa-envelope"></i></span>
                                <span class="contact-span"><a href="mailto: <?php echo $themesbazar['email']; ?>"><?php echo $themesbazar['email']; ?></a></span>
                            </div>
                        <?php endif; ?>
                    </div>
			
				
			</div>
	
	</div>
</div>
<?php

get_footer();
