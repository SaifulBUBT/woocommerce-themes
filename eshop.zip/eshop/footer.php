<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package eshop
 */

?>
<?php  global $themesbazar; ?>

  <footer class="footer-section">
      <div class="footer-top">
        <div class="container">
          <div class="row">
            <div class="col-xs-12 col-sm-6 col-md-3">
              <div class="module-heading">
                <?php if (($themesbazar['contact_title'])) :?>
                  <h4 class="module-title"><?php echo $themesbazar['contact_title']; ?></h4>

                <?php endif; ?>

              </div>
              <div class="module-body">
                <ul class="toggle-footer" style="">
                  <?php if($themesbazar['address']): ?>
                    <li class="media">
                      <div class="pull-left">
                        <span class="icon fa-stack fa-lg">
                        <i class="fa fa-map-marker fa-stack-1x fa-inverse"></i>
                        </span>
                      </div>
                      <div class="media-body">
                        <p><?php echo $themesbazar['address']; ?></p>              
                      </div>
                    </li>
                  <?php endif; ?>

                    <?php if($themesbazar['phone']): ?>
                    <li class="media">
                      <div class="pull-left">
                        <span class="icon fa-stack fa-lg">
                        <i class="fa fa-mobile fa-stack-1x fa-inverse"></i>
                        </span>
                      </div>
                      <div class="media-body">
                        <p><?php echo $themesbazar['phone']; ?></p>              
                      </div>
                    </li>
                    <?php endif; ?>

                    <?php if($themesbazar['email']): ?>
                      <li class="media">
                        <div class="pull-left">
                          <span class="icon fa-stack fa-lg">
                          <i class="fa fa-envelope fa-stack-1x fa-inverse"></i>
                          </span>
                        </div>
                        <div class="media-body">
                          <span><a href="mailto:<?php echo $themesbazar['email']; ?>"><?php echo $themesbazar['email']; ?></a></span>
                        </div>
                      </li>
                    <?php endif; ?>
                </ul>
              </div>
            </div>
			
            <div class="col-xs-12 col-sm-6 col-md-3">
              <div class="module-heading">
                  <?php if($themesbazar['footer_menu_one']): ?>
                <h4 class="module-title"><?php echo $themesbazar['footer_menu_one']; ?></h4>
                    <?php endif; ?>
              </div>
              <div class="module-body">
                <ul class="list-unstyled">
                  <div class="menu-footer-menu-1-container">
                    <?php 
                      wp_nav_menu( array(
                        'theme_location' => 'footer-one',
                        'menu_id' => 'menu-footer-menu-1',
                        'menu_class' => 'menu'
              
                      ));
                    ?>

                  </div>               
                </ul>
               </div>
            </div>
			
            <div class="col-xs-12 col-sm-6 col-md-3">
              <div class="module-heading">
               <?php if($themesbazar['footer_menu_two']): ?>
                <h4 class="module-title"><?php echo $themesbazar['footer_menu_two']; ?></h4>
                  <?php endif; ?>
              </div>
              <div class="module-body">
                <ul class="list-unstyled">
                  <div class="menu-footer-menu-1-container">
                  <?php 
                      wp_nav_menu( array(
                        'theme_location' => 'footer-two',
                        'menu_id' => 'menu-footer-menu-1',
                        'menu_class' => 'menu'
              
                      ));
                    ?>
					        </div>               
			        	</ul>
              </div>
            </div>
			
            <div class="col-xs-12 col-sm-6 col-md-3">
              <div class="module-heading">
              <?php if($themesbazar['fb_like_page_title']): ?>
                <h4 class="module-title"><?php echo $themesbazar['fb_like_page_title']; ?></h4>
                  <?php endif; ?>
              </div>
              <div class="module-body">
                <script>(function(d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id)) return;
                js = d.createElement(s); js.id = id;
                js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5";
                fjs.parentNode.insertBefore(js, fjs);
                }(document, 'script', 'facebook-jssdk'));</script>
              <div class="fb-page" data-href="<?php echo $themesbazar['facebook-page-link']['face-url']; ?>" data-width="<?php echo $themesbazar['facebook-page-width']?>" data-height="<?php echo $themesbazar['facebook-page-height']?>" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"></div>
                
              </div>
            </div>
			
    
          </div>
        </div>
      </div>
	  
	  <div class="footer-bottom">
		<div class="container">
			<div class="row">
				<div class="col-md-4">
					<div class="footer-social-links">
						<ul class="social-sharing">
               <?php if(!empty($themesbazar['ftr-social-link']['facebook-url'])): ?>
									<li><a href="<?php echo esc_url($themesbazar['ftr-social-link']['facebook-url']); ?>"><i class="fab fa-facebook-f"></i></a></li>
              	<?php endif; ?>

               <?php if(!empty($themesbazar['ftr-social-link']['twitter-url'])): ?>
									<li><a href="<?php echo esc_url($themesbazar['ftr-social-link']['twitter-url']); ?>"><i class="fab fa-twitter"></i></a></li>
              	<?php endif; ?>

               <?php if(!empty($themesbazar['ftr-social-link']['pinterest-url'])): ?>
									<li><a href="<?php echo esc_url($themesbazar['ftr-social-link']['pinterest-url']); ?>"><i class="fab fa-pinterest"></i></a></li>
              	<?php endif; ?>

               <?php if(!empty($themesbazar['ftr-social-link']['linkedin-url'])): ?>
									<li><a href="<?php echo esc_url($themesbazar['ftr-social-link']['linkedin-url']); ?>"><i class="fab fa-linkedin-in"></i></a></li>
              	<?php endif; ?>

               <?php if(!empty($themesbazar['ftr-social-link']['googleplus-url'])): ?>
									<li><a href="<?php echo esc_url($themesbazar['ftr-social-link']['googleplus-url']); ?>"><i class="fab fa-google-plus"></i></a></li>
              	<?php endif; ?>

               <?php if(!empty($themesbazar['ftr-social-link']['youtube-url'])): ?>
									<li><a href="<?php echo esc_url($themesbazar['ftr-social-link']['youtube-url']); ?>"><i class="fab fa-youtube"></i></a></li>
              	<?php endif; ?>
					
						</ul>
					</div>
				</div>
				<div class="col-md-4">
					<div class="payment-methods">
					  <ul>
						<li><img src="<?php echo $themesbazar['payment-imgage-one']['url'] ?>" alt=""></li>
						<li><img src="<?php echo $themesbazar['payment-imgage-two']['url'] ?>" alt=""></li>
						<li><img src="<?php echo $themesbazar['payment-imgage-three']['url'] ?>" alt=""></li>
						<li><img src="<?php echo $themesbazar['payment-imgage-four']['url'] ?>" alt=""></li>
						<li><img src="<?php echo $themesbazar['payment-imgage-five']['url'] ?>" alt=""></li>
					  </ul>
					</div>
				</div>
				<div class="col-md-4">
					<div class="copyright-text">
						<p>Design & Developed By <a href="http://themesbazar.com/" style="color: #E33729; font-weight: 700;">ThemesBazar.Com</a></p>
					</div>
				</div>
				
			</div>
		</div>
	  </div>

    </footer>
<?php wp_footer(); ?>
</body>

</html>