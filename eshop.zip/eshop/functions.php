<?php
/**
 * eshop functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package eshop
 */

if ( ! function_exists( 'eshop_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function eshop_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on eshop, use a find and replace
		 * to change 'eshop' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'eshop', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus( array(
			'menu-1' => esc_html__( 'Primary', 'eshop' ),
		) );

		/******image size for slider*******/
		add_image_size( 'main-slider', 730, 333, true );
		add_image_size( 'right-slider', 350, 333, true );
		
		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

		// Set up the WordPress core custom background feature.
		add_theme_support( 'custom-background', apply_filters( 'eshop_custom_background_args', array(
			'default-color' => 'ffffff',
			'default-image' => '',
		) ) );

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support( 'custom-logo', array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		) );
		
	
	}
endif;
add_action( 'after_setup_theme', 'eshop_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function eshop_content_width() {
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters( 'eshop_content_width', 640 );
}
add_action( 'after_setup_theme', 'eshop_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function eshop_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'eshop' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'eshop' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );

	register_sidebar( array(
        'name' => __( 'Widgets Aria One', 'eshop' ),
        'id' => 'widget_01',
        'description' => __( 'Widgets area for Ad image.', 'eshop' ),
        'before_widget' => '<div class="sidebar-widget">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="section-title">',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
        'name' => __( 'Widgets Aria Two', 'eshop' ),
        'id' => 'widget_02',
        'description' => __( 'Widgets area for Ad image.', 'eshop' ),
        'before_widget' => '<div class="sidebar-widget">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="section-title">',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
        'name' => __( 'Widgets Aria Three', 'eshop' ),
        'id' => 'widget_03',
        'description' => __( 'Widgets area for Ad image.', 'eshop' ),
        'before_widget' => '<div class="sidebar-widget">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="section-title">',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
        'name' => __( 'Widgets Aria Four', 'eshop' ),
        'id' => 'widget_04',
        'description' => __( 'Widgets area for Ad image.', 'eshop' ),
        'before_widget' => '<div class="sidebar-widget">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="section-title">',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
        'name' => __( 'Widgets Aria Five', 'eshop' ),
        'id' => 'widget_05',
        'description' => __( 'Widgets area for Ad image.', 'eshop' ),
        'before_widget' => '<div class="sidebar-widget">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="section-title">',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
        'name' => __( 'Widgets Aria Six', 'eshop' ),
        'id' => 'widget_06',
        'description' => __( 'Widgets area for Ad image.', 'eshop' ),
        'before_widget' => '<div class="sidebar-widget">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="section-title">',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
        'name' => __( 'Widgets Aria Seven', 'eshop' ),
        'id' => 'widget_07',
        'description' => __( 'Widgets area for Ad image.', 'eshop' ),
        'before_widget' => '<div class="sidebar-widget">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="section-title">',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
        'name' => __( 'Widgets Aria Eight', 'eshop' ),
        'id' => 'widget_08',
        'description' => __( 'Widgets area for Ad image.', 'eshop' ),
        'before_widget' => '<div class="sidebar-widget">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="section-title">',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
        'name' => __( 'Widgets Aria Nine', 'eshop' ),
        'id' => 'widget_09',
        'description' => __( 'Widgets area for Ad image.', 'eshop' ),
        'before_widget' => '<div class="sidebar-widget">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="section-title">',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
        'name' => __( 'Widgets Aria Ten', 'eshop' ),
        'id' => 'widget_10',
        'description' => __( 'Widgets area for Ad image.', 'eshop' ),
        'before_widget' => '<div class="sidebar-widget">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="section-title">',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
        'name' => __( 'Widgets Aria Eleven', 'eshop' ),
        'id' => 'widget_11',
        'description' => __( 'Widgets area for Ad image.', 'eshop' ),
        'before_widget' => '<div class="sidebar-widget">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="section-title">',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
        'name' => __( 'Widgets Aria Twelve', 'eshop' ),
        'id' => 'widget_12',
        'description' => __( 'Widgets area for Ad image.', 'eshop' ),
        'before_widget' => '<div class="sidebar-widget">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="section-title">',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
        'name' => __( 'Widgets Aria Thireen', 'eshop' ),
        'id' => 'widget_13',
        'description' => __( 'Widgets area for Ad image.', 'eshop' ),
        'before_widget' => '<div class="sidebar-widget">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="section-title">',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
        'name' => __( 'Widgets Aria Fourteen', 'eshop' ),
        'id' => 'widget_14',
        'description' => __( 'Widgets area for Ad image.', 'eshop' ),
        'before_widget' => '<div class="sidebar-widget">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="section-title">',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
        'name' => __( 'Widgets Aria Fifteen', 'eshop' ),
        'id' => 'widget_15',
        'description' => __( 'Widgets area for Ad image.', 'eshop' ),
        'before_widget' => '<div class="sidebar-widget">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="section-title">',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
        'name' => __( 'Widgets Aria Sixteen', 'eshop' ),
        'id' => 'widget_16',
        'description' => __( 'Widgets area for Ad image.', 'eshop' ),
        'before_widget' => '<div class="sidebar-widget">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="section-title">',
		'after_title'   => '</h3>',
    ) );
}
add_action( 'widgets_init', 'eshop_widgets_init' );

/**
 * Load WooCommerce compatibility file.
 */
if ( class_exists( 'WooCommerce' ) ) {
	require get_template_directory() . '/inc/woocommerce.php';
}


/**
 * Enqueue scripts and styles.
 */
function eshop_scripts() {
	wp_enqueue_style( 'normalize', get_template_directory_uri().'/css/normalize.css', array(), '1.0' );
	wp_enqueue_style( 'bootstrap', get_template_directory_uri().'/css/bootstrap.min.css', array(), '4.0' );
		
	wp_enqueue_style( 'all-min', get_template_directory_uri().'/css/all.min.css', array(), '1.0' );
	wp_enqueue_style( 'stellarnav', get_template_directory_uri().'/css/stellarnav.css', array(), time() );
	wp_enqueue_style( 'justified-gallery', get_template_directory_uri().'/css/justifiedGallery.css', array(), time() );

	
	wp_enqueue_style( 'slick-css', get_template_directory_uri().'/css/slick.css', array(), time() );
	
	wp_enqueue_style( 'slick-theme', get_template_directory_uri().'/css/slick-theme.css', array(), time() );

	
	wp_enqueue_style('google-roboto-font', '//fonts.googleapis.com/css?family=Roboto:300,400,500,700');
    wp_enqueue_style('google-open-sens-font', '//fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,600,600italic,700,700italic,800');
    wp_enqueue_style('google-montserrat-font', '//fonts.googleapis.com/css?family=Montserrat:400,700');
	
	wp_enqueue_style( 'main-css', get_template_directory_uri().'/css/main.css', array(), time() );
	wp_enqueue_style( 'responsive-css', get_template_directory_uri().'/css/responsive.css', array(), time() );
	wp_enqueue_style( 'eshop-style', get_stylesheet_uri() );


	// include js files
	wp_enqueue_script( 'eshop-modernizr', get_template_directory_uri() . '/js/vendor/modernizr-3.7.1.min.js', array(), '9999999', true );
	wp_enqueue_script( 'eshop-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20151215', true );
	wp_enqueue_script( 'proper-js', '//cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js', true );
	wp_enqueue_script('bootstrap-js', get_theme_file_uri('/js/bootstrap.min.js'), array('jquery'), '4.0', true);
	wp_enqueue_script('stellarnav-js', get_theme_file_uri('/js/stellarnav.min.js'), array('jquery'), '1.0', true);
	wp_enqueue_script('slick-js', get_theme_file_uri('/js/slick.js'), array('jquery'), '1.0', true);
	wp_enqueue_script('all-js', get_theme_file_uri('/js/all.min.js'), array(), '1.0', true);
	wp_enqueue_script( 'justified-gallery-js', get_template_directory_uri() . '/js/jquery.justifiedGallery.js', array('jquery'), time(), true );
	
	wp_enqueue_script( 'main-js', get_template_directory_uri() . '/js/main.js', array('jquery'), time(), true );



	wp_enqueue_script( 'eshop-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20151215', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'eshop_scripts' );

/**
 * enque admin scripts
 */
function eshop_load_custom_wp_admin_style() {
	wp_enqueue_style( 'admin-dashboard', get_template_directory_uri().'/css/dashboard.css', array(), time() );

}
add_action( 'admin_enqueue_scripts', 'eshop_load_custom_wp_admin_style' );


/**
 * Implement the Custom Header feature.
 */
//require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
//require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
//require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	//require get_template_directory() . '/inc/jetpack.php';
}


/**
 * Menu includes.
 */
require_once get_template_directory() . '/inc/menu.php';
require_once get_template_directory() . '/inc/wp-bootstrap-navwalker.php';

/**
 * Custom post types.
 */
require_once get_template_directory() . '/inc/custom-post-types.php';


/**
 * TGM Activation.
 */
require_once get_template_directory() . '/lib/tgm/example.php';

/**
 * Implement Redux Framework
 */
require_once get_template_directory() . '/lib/redux-framework/ReduxCore/framework.php';
require_once get_template_directory() . '/lib/redux-framework/ReduxCore/templates/panel/config.php';
require_once get_template_directory() . '/lib/redux-framework/sample/config.php';

/**
 * CMB2 metabox field crete
 */
require_once get_theme_file_path('/metabox/init.php');
require_once get_theme_file_path('/metabox/functions.php');
