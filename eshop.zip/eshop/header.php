<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package eshop
 */

?>
<?php global $themesbazar; ?>

<!doctype html>
<html <?php language_attributes(); ?>>

<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">



<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

	<header>
		<div class="header-top">
			<div class="container">
				<div class="row">
					<div class="col-md-4">
						<div class="header-top-desc">
							<p><?php echo $themesbazar['header-top-slogan']; ?></p>
						</div>
					</div>
					<div class="col-md-3">
						<div class="cell-no-section">
							<span><i class="fas fa-phone-square"></i><?php echo $themesbazar['contact-no']; ?></span>
						</div>
					</div>
					<div class="col-md-5">
						<div class="header-top-right-menu">
					
							<?php /* top navigation */
							wp_nav_menu( array(
							   'theme_location' => 'top-menu',
							   'fallback_cb' => 'default_main_menu',
							   )); 
							?>
							
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="header-middle">
			<div class="container">
				<div class="row">
					<div class="col-md-3">
						<div class="header-logo">
							<?php
								$eshop_logo_url =  $themesbazar['logo_upload']['url'];
								if( ! empty($eshop_logo_url)) {
							?>
								<a href="<?php echo home_url( '/' ) ?>"><img src="<?php echo $eshop_logo_url; ?>"/></a>
								<?php } else{ ?>
									<a href="<?php echo home_url('/'); ?>"><img src="<?php echo get_template_directory_uri(); ?>/img/logo-main.jpg" /></a>
								<?php } ?>
						</div>
					</div>
					
					<div class="col-md-7">
						<form class="form form-search"  method="get" action="<?php echo home_url( '/' ); ?>">
							<div class="custom-search-form input-group md-form form-sm form-2">
							  <input class="form-control" type="text" placeholder="Search" aria-label="Search" value="<?php the_search_query(); ?>" name="s" />
								<button type="submit" class="search-button">Search</button>

							</div>
						</form>
						           <!---<form class="example" method="get" action="<?php echo home_url( '/' ); ?>">
										<input type="text" class="search-field" maxlength="64" placeholder="<?php echo $themesbazar['placeholder']?>" value="<?php the_search_query(); ?>" name="s" />
										<button type="submit" class="search-button"><?php// echo $themesbazar['search']?></button>
									  
									</form>--->
					</div>
					<div class="col-md-2">
				
					</div>
				</div>
			</div>
		</div>
		<div class="main-menu">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						
						<?php /* Primary navigation */
						wp_nav_menu( array(
						   'theme_location' => 'main-menu',
						   'container' => 'div',
						   'container_class' => 'stellarnav',
						   'depth' => 0,
						   'fallback_cb' => 'default_main_menu',
						   )); 
						?>
					</div>
				</div>
			</div>
		</div>	
	</header>