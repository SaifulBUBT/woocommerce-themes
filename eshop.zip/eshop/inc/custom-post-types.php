<?php 
function cptui_register_my_cpts() {

	/**
	 * Post Type: Main Slides.
	 */

	$labels = [
		"name" => __( "Main Slides", "eshop" ),
		"singular_name" => __( "Main Slide", "eshop" ),
		"menu_name" => __( "Main Slider", "eshop" ),
		"all_items" => __( "All Slides", "eshop" ),
		"add_new" => __( "Add New Slide", "eshop" ),
		"add_new_item" => __( "Add New Slide", "eshop" ),
		"edit_item" => __( "Edit Slide", "eshop" ),
		"new_item" => __( "New Slide", "eshop" ),
		"view_item" => __( "View Slide", "eshop" ),
		"view_items" => __( "View Slides", "eshop" ),
		"search_items" => __( "Search Slide", "eshop" ),
		"not_found" => __( "No Slide Found", "eshop" ),
		"featured_image" => __( "Main Slide Image", "eshop" ),
		"set_featured_image" => __( "Set Main Slide Image", "eshop" ),
		"remove_featured_image" => __( "Remove Main Slide Image", "eshop" ),
	];

	$args = [
		"label" => __( "Main Slides", "eshop" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"delete_with_user" => false,
		"show_in_rest" => false,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => true,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"delete_with_user" => false,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => [ "slug" => "main_slide", "with_front" => true ],
		"query_var" => true,
		"menu_icon" => "dashicons-align-center",
		"supports" => [ "title", "editor", "thumbnail" ],
		"taxonomies" => [ "category" ],
	];

	register_post_type( "main_slide", $args );

	/**
	 * Post Type: Right Slides.
	 */

	$labels = [
		"name" => __( "Right Slides", "eshop" ),
		"singular_name" => __( "Right Slide", "eshop" ),
		"menu_name" => __( "Right Slider", "eshop" ),
		"featured_image" => __( "Right Slide Image", "eshop" ),
		"set_featured_image" => __( "Set Right Slide Image", "eshop" ),
		"remove_featured_image" => __( "Remove Right Slide Image", "eshop" ),
	];

	$args = [
		"label" => __( "Right Slides", "eshop" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"delete_with_user" => false,
		"show_in_rest" => false,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => true,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"delete_with_user" => false,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => [ "slug" => "right_slide", "with_front" => true ],
		"query_var" => true,
		"menu_icon" => "dashicons-editor-alignright",
		"supports" => [ "title", "editor", "thumbnail" ],
		"taxonomies" => [ "category" ],
	];

	register_post_type( "right_slide", $args );

	/**
	 * Post Type: Brand Slides.
	 */

	$labels = [
		"name" => __( "Brand Slides", "eshop" ),
		"singular_name" => __( "Brand Slide", "eshop" ),
		"menu_name" => __( "Brand Logo", "eshop" ),
		"all_items" => __( "All Logos", "eshop" ),
		"add_new" => __( "Add New Logo", "eshop" ),
		"add_new_item" => __( "Add New Logo", "eshop" ),
		"edit_item" => __( "Edit Logo", "eshop" ),
	];

	$args = [
		"label" => __( "Brand Slides", "eshop" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"delete_with_user" => false,
		"show_in_rest" => false,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => true,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"delete_with_user" => false,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => [ "slug" => "brand_slide", "with_front" => true ],
		"query_var" => true,
		"menu_icon" => "dashicons-buddicons-buddypress-logo",
		"supports" => [ "title", "thumbnail" ],
	];

	register_post_type( "brand_slide", $args );
}

add_action( 'init', 'cptui_register_my_cpts' );
