<?php
/**
 * WooCommerce Compatibility File
 *
 * @link https://woocommerce.com/
 *
 * @package eshop
 */

/**
 * WooCommerce setup function.
 *
 * @link https://docs.woocommerce.com/document/third-party-custom-theme-compatibility/
 * @link https://github.com/woocommerce/woocommerce/wiki/Enabling-product-gallery-features-(zoom,-swipe,-lightbox)-in-3.0.0
 *
 * @return void
 */
function eshop_woocommerce_setup() {
	add_theme_support( 'woocommerce' );
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );
}
add_action( 'after_setup_theme', 'eshop_woocommerce_setup' );

/**
 * WooCommerce specific scripts & stylesheets.
 *
 * @return void
 */
function eshop_woocommerce_scripts() {
	wp_enqueue_style( 'eshop-woocommerce-style', get_template_directory_uri() . '/woocommerce.css', array(), time() );

	$font_path   = WC()->plugin_url() . '/assets/fonts/';
	$inline_font = '@font-face {
			font-family: "star";
			src: url("' . $font_path . 'star.eot");
			src: url("' . $font_path . 'star.eot?#iefix") format("embedded-opentype"),
				url("' . $font_path . 'star.woff") format("woff"),
				url("' . $font_path . 'star.ttf") format("truetype"),
				url("' . $font_path . 'star.svg#star") format("svg");
			font-weight: normal;
			font-style: normal;
		}';

	wp_add_inline_style( 'eshop-woocommerce-style', $inline_font );
}
add_action( 'wp_enqueue_scripts', 'eshop_woocommerce_scripts' );

/**
 * Disable the default WooCommerce stylesheet.
 *
 * Removing the default WooCommerce stylesheet and enqueing your own will
 * protect you during WooCommerce core updates.
 *
 * @link https://docs.woocommerce.com/document/disable-the-default-stylesheet/
 */
//add_filter( 'woocommerce_enqueue_styles', '__return_empty_array' );

/**
 * Add 'woocommerce-active' class to the body tag.
 *
 * @param  array $classes CSS classes applied to the body tag.
 * @return array $classes modified to include 'woocommerce-active' class.
 */
function eshop_woocommerce_active_body_class( $classes ) {
	$classes[] = 'woocommerce-active';

	return $classes;
}
add_filter( 'body_class', 'eshop_woocommerce_active_body_class' );

/**
 * Products per page.
 *
 * @return integer number of products.
 */
function eshop_woocommerce_products_per_page() {
	return 12;
}
add_filter( 'loop_shop_per_page', 'eshop_woocommerce_products_per_page' );

/**
 * Product gallery thumnbail columns.
 *
 * @return integer number of columns.
 */
// function eshop_woocommerce_thumbnail_columns() {
// 	return 4;
// }
// add_filter( 'woocommerce_product_thumbnails_columns', 'eshop_woocommerce_thumbnail_columns' );

/**
 * Default loop columns on product archives.
 *
 * @return integer products per row.
 */
// function eshop_woocommerce_loop_columns() {
// 	return 3;
// }
// add_filter( 'loop_shop_columns', 'eshop_woocommerce_loop_columns' );

/**
 * Related Products Args.
 *
 * @param array $args related products args.
 * @return array $args related products args.
 */
function eshop_woocommerce_related_products_args( $args ) {
	$defaults = array(
		'posts_per_page' => 3,
		'columns'        => 3,
	);

	$args = wp_parse_args( $defaults, $args );

	return $args;
}
add_filter( 'woocommerce_output_related_products_args', 'eshop_woocommerce_related_products_args' );




/****
 * code for product markup
 * ****** */

add_filter('wp_calculate_image_sizes','__return_empty_array');
add_filter('wp_calculate_image_srcset','__return_empty_array');


//remove_action('woocommerce_before_shop_loop_item_title','woocommerce_show_product_loop_sale_flash',10);
//remove_action('woocommerce_shop_loop_item_title','woocommerce_template_loop_product_title',10);
//remove_action('woocommerce_after_shop_loop_item_title','woocommerce_template_loop_rating',5);
//remove_action('woocommerce_after_shop_loop_item_title','woocommerce_template_loop_price',10);
//remove_action('woocommerce_after_shop_loop_item','woocommerce_template_loop_add_to_cart',10);


function eshop_before_shop_loop_item(){
	echo '<div class="item-holder">';
}
add_action('woocommerce_before_shop_loop_item','eshop_before_shop_loop_item');


function eshop_after_shop_loop_item(){
	echo '</div>';
}
add_action('woocommerce_after_shop_loop_item','eshop_after_shop_loop_item');

function eshop_before_shop_loop_item_title(){
	echo '<div class="item-info">';
}
add_action('woocommerce_before_shop_loop_item_title','eshop_before_shop_loop_item_title');

function eshop_after_shop_loop_item_title(){
	echo '</div>';
}
add_action('woocommerce_after_shop_loop_item_title','eshop_after_shop_loop_item_title');



/******* single product page*********** */
remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20);



  /**
   *  Customized checkout fields
   * ** */

// Our hooked in function - $fields is passed via the filter!
function e_store_custom_override_checkout_fields( $fields ) {
	$fields['billing']['billing_first_name']['input_class'] = array('form-control unicase-form-control text-input');
	$fields['billing']['billing_last_name']['input_class'] = array('form-control unicase-form-control text-input');
	$fields['billing']['billing_company']['input_class'] = array('form-control unicase-form-control text-input');
	$fields['billing']['billing_address_1']['input_class'] = array('form-control unicase-form-control text-input');
	$fields['billing']['billing_address_2']['input_class'] = array('form-control unicase-form-control text-input');
	$fields['billing']['billing_city']['input_class'] = array('form-control unicase-form-control text-input');
	$fields['billing']['billing_postcode']['input_class'] = array('form-control unicase-form-control text-input');
	$fields['billing']['billing_phone']['input_class'] = array('form-control unicase-form-control text-input');
	$fields['billing']['billing_email']['input_class'] = array('form-control unicase-form-control text-input');
   
	$fields['shipping']['shipping_first_name']['input_class'] = array('form-control unicase-form-control text-input');
	$fields['shipping']['shipping_last_name']['input_class'] = array('form-control unicase-form-control text-input');
	$fields['shipping']['shipping_company']['input_class'] = array('form-control unicase-form-control text-input');
	$fields['shipping']['shipping_address_1']['input_class'] = array('form-control unicase-form-control text-input');
	$fields['shipping']['shipping_address_2']['input_class'] = array('form-control unicase-form-control text-input');
	$fields['shipping']['shipping_city']['input_class'] = array('form-control unicase-form-control text-input');
	$fields['shipping']['shipping_postcode']['input_class'] = array('form-control unicase-form-control text-input');

   
	return $fields;
}
add_filter( 'woocommerce_checkout_fields' , 'e_store_custom_override_checkout_fields' );



