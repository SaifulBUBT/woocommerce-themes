<?php get_header(); 
global $themesbazar; 
?>

	<?php
				$homepage_layout = $themesbazar['homepage-section']['Show'];
				if ($homepage_layout): foreach ($homepage_layout as $key=>$value) {
					switch($key) {
						case 'slider': get_template_part( '/template-parts/home-page/slider' );
						break;
				
						case 'category-gallery': get_template_part('/template-parts/home-page/category-gallery');
						break;
				
						case 'new-arrival-product': get_template_part('/template-parts/home-page/new-arrival-product');   
						break;  
				
						case 'featured-product': get_template_part('/template-parts/home-page/featured-product');   
						break;  
				
						case 'best-selling-product': get_template_part('/template-parts/home-page/best-selling-product');   
						break;  
				
						case 'top-rated-product': get_template_part('/template-parts/home-page/top-rated-product');   
						break;  
						
						case 'product-category-one': get_template_part('/template-parts/home-page/product-category-one');   
						break;  
						
						case 'product-category-two': get_template_part('/template-parts/home-page/product-category-two');   
						break; 
						
						case 'product-category-three': get_template_part('/template-parts/home-page/product-category-three');   
						break; 
								
						case 'product-category-four': get_template_part('/template-parts/home-page/product-category-four');   
						break; 
						
						case 'product-category-five': get_template_part('/template-parts/home-page/product-category-five');   
						break; 
						
						case 'product-category-six': get_template_part('/template-parts/home-page/product-category-six');   
						break;
						
						case 'product-category-seven': get_template_part('/template-parts/home-page/product-category-seven');   
						break; 
						
						case 'product-category-eight': get_template_part('/template-parts/home-page/product-category-eight');   
						break; 
						
						case 'product-category-nine': get_template_part('/template-parts/home-page/product-category-nine');   
						break;
						
						case 'product-category-ten': get_template_part('/template-parts/home-page/product-category-ten');   
						break; 

						case 'product-category-eleven': get_template_part('/template-parts/home-page/product-category-eleven');   
						break; 

						case 'product-category-twelve': get_template_part('/template-parts/home-page/product-category-twelve');   
						break; 

						case 'product-category-thirteen': get_template_part('/template-parts/home-page/product-category-thirteen');   
						break; 

						case 'product-category-fourteen': get_template_part('/template-parts/home-page/product-category-fourteen');   
						break; 

						case 'product-category-fifteen': get_template_part('/template-parts/home-page/product-category-fifteen');   
						break; 

						case 'product-category-sixteen': get_template_part('/template-parts/home-page/product-category-sixteen');   
						break; 
						
						case 'brand-logo': get_template_part('/template-parts/home-page/brand-logo');   
						break; 
					}
				}
				endif;
			?>

  
<?php get_footer(); ?>

