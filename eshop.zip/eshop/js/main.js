

    jQuery(document).ready(function($){


			$('.stellarnav').stellarNav({
				// adds default color to nav. (light, dark, plain)
				theme: 'dark',
				breakpoint: 768,
				position: 'right',
				phoneBtn: false,
				locationBtn: false,
				sticky     :true,
				showArrows:true,
				openingSpeed: 500,
				closingDelay: 500,

			});
			
			/****$(".owl-carousel").owlCarousel({
				items: 1,
				loop:true,
				nav: true,
				dots: true,
				responsive:{
					0:{
						items:1,
						nav:true
					},
					600:{
						items:1,
					},
					1000:{
						items:1,
					}
				}
			});
			****/
			
			// products carousel
			$('.home-page-product-carousel').slick({
			  dots: false,
			  infinite: false,
			  speed: 300,
			  arrows:true,
			  autoplay: true,
			  autoplaySpeed: 3000,
			    prevArrow:'<button type="button" data-role="none" class="slick-prev">Previous</button>',
				  nextArrow:'<button type="button" data-role="none" class="slick-next">Next</button>',
			  slidesToShow: 6,
			  slidesToScroll: 4,
			  responsive: [
				{
				  breakpoint: 1024,
				  settings: {
					slidesToShow: 3, 
					slidesToScroll: 3,
					infinite: true,
					dots: false
				  }
				},
				{
				  breakpoint: 600,
				  settings: {
					slidesToShow: 2,
					slidesToScroll: 2
				  }
				},
				{
				  breakpoint: 480,
				  settings: {
					slidesToShow: 1,
					slidesToScroll: 1
				  }
				}
			  ]		

			});
			
			
			// main slide
			$('.main-slide').slick({
			  dots: false,
			  arrows:true,
			  autoplay: true,
			  autoplaySpeed: 3000,
			  infinite: true,
			  speed: 500,
			  fade: true,
			  cssEase: 'ease-in-out',
			    prevArrow:'<button type="button" data-role="none" class="slick-prev">Previous</button>',
				  nextArrow:'<button type="button" data-role="none" class="slick-next">Next</button>',
			  slidesToShow: 1,
			  slidesToScroll: 1,
			  responsive: [
				{
				  breakpoint: 1024,
				  settings: {
					slidesToShow: 1, 
					slidesToScroll: 1,
					infinite: true,
					dots: false
				  }
				},
				{
				  breakpoint: 768,
				  settings: {
					slidesToShow: 1,
					slidesToScroll: 1
				  }
				},
				{
				  breakpoint: 480,
				  settings: {
					slidesToShow: 1,
					slidesToScroll: 1
				  }
				}
			  ]		

			});
			
			// right slide
			$('.right-slide-items').slick({
			  dots: false,
			  arrows:true,
			  autoplay: true,
			  autoplaySpeed: 3000,
			  infinite: true,
			  speed: 500,
			  fade: true,
			  cssEase: 'linear',
			    prevArrow:'<button type="button" data-role="none" class="slick-prev">Previous</button>',
				  nextArrow:'<button type="button" data-role="none" class="slick-next">Next</button>',
			  slidesToShow: 1,
			  slidesToScroll: 1,
			  responsive: [
				{
				  breakpoint: 1024,
				  settings: {
					slidesToShow: 1, 
					slidesToScroll: 1,
					infinite: true,
					dots: false
				  }
				},
				{
				  breakpoint: 768,
				  settings: {
					slidesToShow: 1,
					slidesToScroll: 1
				  }
				},
				{
				  breakpoint: 480,
				  settings: {
					slidesToShow: 1,
					slidesToScroll: 1
				  }
				}
			  ]		

			});
			
			// brand slide
		$('.brand-slide-items').slick({
			dots: false,
			  infinite: false,
			  speed: 300,
			  arrows:true,
			  autoplay: true,
			  autoplaySpeed: 3000,
			    prevArrow:'<button type="button" data-role="none" class="slick-prev">Previous</button>',
				  nextArrow:'<button type="button" data-role="none" class="slick-next">Next</button>',
			  slidesToShow: 6,
			  slidesToScroll: 4,
			  responsive: [
				{
				  breakpoint: 1024,
				  settings: {
					slidesToShow: 5, 
					slidesToScroll: 3,
					infinite: true,
					dots: false
				  }
				},
				{
				  breakpoint: 768,
				  settings: {
					slidesToShow: 3,
					slidesToScroll: 2
				  }
				},
				{
				  breakpoint: 480,
				  settings: {
					slidesToShow: 1,
					slidesToScroll: 1
				  }
				}
			  ]		

			
			});
			
			/*===================================================================================*/
			/*  justified gallery
			/*===================================================================================*/
			$("#mygallery").justifiedGallery({
				rowHeight : 130,
				lastRow : 'nojustify',
				margins : 3,
				randomize: true
			});
							
				
				
	});




