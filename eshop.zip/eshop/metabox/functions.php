<?php



//slider metaboxs
function eshop_slider_metaboxes(array $product_meta){
	
	$product_meta[] = array(
	
		'id'            => 'eshop_metabox',
		'title'         => __( 'Slider Metabox', 'e_store' ),
		'object_types'  => array( 'main_slide', 'right_slide' ), // Post type
		'context'       => 'normal',
		'priority'      => 'high',
		'show_names'    => true,
			'fields' => array(
					
					array(
						'name' => __( 'Product category link: ', 'e_store' ),
						'id'   => 'eshop_product_category_url',
						'type' => 'text_url',
						// 'protocols' => array('http', 'https', 'ftp', 'ftps', 'mailto', 'news', 'irc', 'gopher', 'nntp', 'feed', 'telnet'), // Array of allowed protocols
						// 'repeatable' => true,
						
					),			
			)
	);
	
	return $product_meta;	
}
add_filter('cmb2_meta_boxes','eshop_slider_metaboxes');



/*
Output=========
<?php echo get_post_meta(get_the_ID(),'developer', true); ?>

*/