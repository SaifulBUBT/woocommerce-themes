<?php
show_category_list();
?>

<div class="breadcrumbs-section">
		<div class="container">
			<div class="ecommerce-breadcrumb">
				<span><i class="fas fa-home"></i></span>
				<h5><?php printf( esc_html__( 'Search Results for: %s', 'eshop' ), '<span>' . get_search_query() . '</span>' );
 				?></h5>

			 </div>
		</div>
	</div>
<!-- /.breadcrumb -->
    <!-- /.breadcrumb -->
    <div class="search-page-content">
      <div class="container">
        <div class="row">
       
            <div class="col-md-12">

				<?php
					global $query_string;
					$query_args = explode("&", $query_string);
					$search_query = array();

					foreach($query_args as $key => $string) {
					  $query_split = explode("=", $string);
					  $search_query[$query_split[0]] = urldecode($query_split[1]);
					} // foreach

					$the_query = new WP_Query($search_query);
					if ( $the_query->have_posts() ) : 
					?>
					<!-- the loop -->

				   
					<?php while ( $the_query->have_posts() ) : $the_query->the_post(); global $product;?>
								
								
							<div class=" archive_back single-search-item">
								<!-- Post Image Code Start--> 
								<a href="<?php the_permalink();?>">
									<?php if(has_post_thumbnail()){ 
										the_post_thumbnail();}
									else{?>
									<img src="<?php echo get_template_directory_uri(); ?>/images/noimage.gif" width="100%" />
									<?php } ?>
								</a>
									<!-- Post Image Code Close-->
					
								<h3 class="archive_title01"><a href="<?php the_permalink(); ?>"><?php the_title();?> </a></h3>
										<p><?php echo $product->get_price_html(); ?></p>	
										<?php woocommerce_template_loop_add_to_cart(); ?>
									   
							</div>
					
					<?php endwhile; ?>

					<!-- end of the loop -->

					<?php wp_reset_postdata(); ?>

				<?php else : ?>
					<p><?php _e( 'Sorry, no posts Found, Please Try Again.' ); ?></p>
				<?php endif; ?>   
								
	  
            </div>
        </div>
       	
      </div>
    </div>
<?php get_footer();?>