<section class="shop-by-brand">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<h2 class="product-carousel-header">Shop by brand</h2>
					<div class="brand-slide-items">	

	
						<?php 
							$brandlogo = new WP_Query(array(
								'post_type' => 'brand_slide',
								'posts_per_page' => -1,
								'orderby'     => 'DESC',
							));
							if($brandlogo->have_posts()):
							while($brandlogo->have_posts()) : $brandlogo->the_post(); ?>	
								<?php $brandImg = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'thumbnail' ); 
						?>
							<div class="single-brand-item"> 
								<a href="#"><img src="<?php echo $brandImg[0]; ?>"/></a>
							</div>
					  									
						<?php 
						endwhile;
						wp_reset_query();
						else: ?>
						   <img src="<?php echo get_template_directory_uri( ); ?>/img/slide/slide-3.jpg" />

						<?php endif; ?>

		
	
					</div> 
				</div>
			</div>
		</div>
	</section>
