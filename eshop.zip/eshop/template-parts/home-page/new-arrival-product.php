<?php if (shortcode_exists( 'products' )): ?>
<section class="product-carousel"> <!--- product carousel start -->
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<h2 class="product-carousel-header">
						
						<?php esc_html_e( 'New Arrival', 'eshop' ); ?>

					</h2>
				</div>
				<div class="product-carousel-container">
						<?php echo do_shortcode( '[products orderby="id" order="DESC" visibility="visible"]' ); ?>
				</div>
			</div>
		</div>
	</section> <!--- product carousel end -->
	<?php
	 else :
		 echo "<div class='container'><h5 style='border: 1px solid #ddd; padding: 20px;'>Please Active Woocommerce Plugin to see New Arrival Products</h5></div>";
	 
	endif;
	 ?>