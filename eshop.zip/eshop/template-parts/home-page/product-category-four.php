<?php  global $themesbazar; ?> 
<section class="product-carousel"> <!--- product carousel start -->
		<div class="container">
			<div class="row">
				<div class="col-md-12">

					<?php
					$id = (!empty($themesbazar['product_category_four'])) ? $themesbazar['product_category_four'] : 'empty';
					if($id != 'empty'){ 
						
					if( $term = get_term_by( 'id', $id, 'product_cat' ) ){
						$pcategory_name = $term->name;}
						$pcategory_name_link = get_category_link($id);

					?>
					<h2 class="product-carousel-header">
						<a href="<?php echo esc_url($pcategory_name_link);?>"> <?php echo $pcategory_name;?></a>
					</h2>
				</div>
				<div class="product-carousel-container">
					<?php echo do_shortcode( '[products category="'.$pcategory_name.'"]' ); ?>
				</div>

				<?php  } else{
						echo '<h4 class="category-missing-message">Please select category from Theme Options => Homepage Product Category Settings => Product Category Four</h4>';
						}
						?>
			</div>
		</div>
	</section> <!--- product carousel end -->