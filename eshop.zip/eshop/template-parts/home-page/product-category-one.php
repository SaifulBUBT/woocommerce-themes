<?php  global $themesbazar; ?> 
<section class="product-carousel"> <!--- product carousel start -->
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<?php
					$id = (!empty($themesbazar['product_category_one'])) ? $themesbazar['product_category_one'] : 'empty';
					if($id != 'empty'){ 
						
					if( $term = get_term_by( 'id', $id, 'product_cat' ) ){
						$pcategory_name = $term->name;}
						$pcategory_name_link = get_category_link($id);

					?>
					<h2 class="product-carousel-header">
						<a href="<?php echo esc_url($pcategory_name_link);?>"> <?php echo $pcategory_name;?></a>
					</h2>
				</div>

				<div class="product-carousel-container">
					<ul class="products products-item home-page-product-carousel">
					
						<?php
						$args = array( 'post_type' => 'product', 'posts_per_page' => -1, 'product_cat' => $pcategory_name, 'orderby' => 'DESC'  );
						$loop = new WP_Query( $args );
						while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
						<li class="product product-item">
							<div class="item-holder">
								<div class="item-picture">
									<a class="thumb-img" href="<?php the_permalink()?>">
									<?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?>
									</a>
								</div>
								<div class="item-info">
									<h3 class="jcarousel-product-title">
										<a class="jcarousel-product-name" href="<?php the_permalink()?>" >
											<?php the_title(); ?>
										</a>
									</h3>
									<div class="prices">
										<span class="price"> <?php echo $product->get_price_html(); ?>	</span>
									</div>
								</div>

								<?php woocommerce_template_loop_add_to_cart(); ?>									

							</div>
						</li><!---single product end--->
						
						<?php endwhile; wp_reset_query(); ?>

					</ul>
					<?php  } else{
						echo '<h4 class="category-missing-message">Please select category from Theme Options => Homepage Product Category Settings => Product Category One</h4>';
						}
						?>
				</div>
			</div>
		</div>
	</section> <!--- product carousel end -->