<section class="slider-section">
		<div class="container">
		<div class="row">
			<div class="col-md-8">
				<div class="main-slide">
				
						<?php 
							$mainSslide = new WP_Query(array(
								'post_type' => 'main_slide',
								'posts_per_page' => -1,
								'orderby'     => 'DESC',
							));
							if($mainSslide->have_posts()):
							while($mainSslide->have_posts()) : $mainSslide->the_post(); ?>	
								<?php $slideImg = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'main-slider' ); 
						?>
	
						  <div class="slide-item"> 
						  <?php $product_category_url = get_post_meta(get_the_ID(),'eshop_product_category_url', true);?>
							<a href="<?php echo (esc_url($product_category_url)); ?>"><img src="<?php echo $slideImg[0]; ?>" /></a>
						  </div>
									
						<?php 
							endwhile;
							wp_reset_query();
						else: ?>
						   <img src="<?php echo get_template_directory_uri( ); ?>/img/slide/slide-3.jpg" />

						<?php endif; ?>
	
					
				</div>
			</div>
			
			<div class="col-md-4">
				<div class="right-slide-items">	
						
					<?php 
						$rightSlide = new WP_Query(array(
							'post_type' => 'right_slide',
							'posts_per_page' => -1,
							'orderby'     => 'DESC',
						));
						if($rightSlide->have_posts()):
						while($rightSlide->have_posts()) : $rightSlide->the_post(); ?>	
							<?php $rightslideImg = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'right-slider' ); 
					?>

						<div class="right-slide-item"> 
							<?php $product_category_url = get_post_meta(get_the_ID(),'eshop_product_category_url', true);?>
							<a href="<?php echo (esc_url($product_category_url)); ?>"><img src="<?php echo $rightslideImg[0]; ?>" /></a>
					  	</div>
								
					<?php 
						endwhile;
						wp_reset_query();
					else: ?>
						<img src="<?php echo get_template_directory_uri( ); ?>/img/slide/slide-7.png" />

					<?php endif; ?>	

			
				
					
				
				</div> 
			</div>
		</div>
		</div>

	</section> 