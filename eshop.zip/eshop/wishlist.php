<?php
/**
 * Template Name: Wishlist Template
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package e_store
 */

get_header();
?>

<div class="body-content">
	<div class="container">
		<div class="row">
				<div class="col-md-12">
                    <div class="e_store_wishlist_page">
                        <?php
                        while ( have_posts() ) :
                            the_post(); ?>

                            <div id="post-<?php the_ID(); ?>" <?php post_class('blog-post  wow fadeInUp'); ?>>

                            <!-- <header class="entry-header">
                                <?php //the_title( '<h1 class="entry-title">', '</h1>' ); ?>
                            </header>.entry-header -->
                        
                            <?php echo get_the_post_thumbnail( null, 'post-thumbnail', $attr='' );?>
                        
                            <div class="entry-content">
                                <?php
                                the_content();
                        
                                wp_link_pages( array(
                                    'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'e_store' ),
                                    'after'  => '</div>',
                                ) );
                                ?>
                            </div><!-- .entry-content -->
                        
                            <?php if ( get_edit_post_link() ) : ?>
                                <footer class="entry-footer">
                                    <?php
                                    edit_post_link(
                                        sprintf(
                                            wp_kses(
                                                /* translators: %s: Name of current post. Only visible to screen readers */
                                                __( 'Edit <span class="screen-reader-text">%s</span>', 'e_store' ),
                                                array(
                                                    'span' => array(
                                                        'class' => array(),
                                                    ),
                                                )
                                            ),
                                            get_the_title()
                                        ),
                                        '<span class="edit-link">',
                                        '</span>'
                                    );
                                    ?>
                                </footer><!-- .entry-footer -->
                            <?php endif; ?>
                                </div><!-- #post-<?php the_ID(); ?> -->

                                <?php
                            // If comments are open or we have at least one comment, load up the comment template.
                            if ( comments_open() || get_comments_number() ) :
                                comments_template();
                            endif;

                        endwhile; // End of the loop.
                        ?>

				    </div>
			
				
			</div>
		</div>
	</div>
</div>
<?php

get_footer();
